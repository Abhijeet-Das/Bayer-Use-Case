# Skills Update Flow

Use this runbook when deploying updated skills data to a running environment.

## Update Order

1. Merge / deploy the updated **skills repo** .
2. Restart the **engine** and wait until it is healthy — it will pull the latest skills from the repo.
3. Restart the **backend** after the engine is up.

The backend must start last because it reads the current skills data from the engine at startup, then publishes the widget catalog refresh. Starting the backend before the engine is ready means it picks up stale skills.

## Manual Cleanup Step

Run this SQL before restarting the backend to remove stale engine-managed widget prefabs:

```sql
DELETE FROM widget_prefabs
WHERE digital_worker_id = 1;
```

Notes:

- Table name: `widget_prefabs`
- Column name: `digital_worker_id`

## What Happens Next

After the backend restarts, it will:

- reload startup state
- publish the widget catalog refresh
- resume the scheduled news refresh flow

That ensures the updated skills, widgets, and daily news flow are picked up together.
