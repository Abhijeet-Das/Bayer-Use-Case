# Zora AI - Client Deployment Guide

Welcome to the Zora AI deployment guide. This document will walk you through deploying Zora AI in your SAP BTP Kyma environment step by step.

---

## 1. Prerequisites

Before starting, ensure you have:

- **Terminal access** (macOS Terminal, Windows PowerShell, or Linux Terminal)
- **kubectl** installed ([Installation Guide](https://kubernetes.io/docs/tasks/tools/))
- **Helm** installed ([Installation Guide](https://helm.sh/docs/intro/install/))
- **VPN client** installed (GlobalProtect)
- **SAP BTP credentials** (username and password provided by your admin)

---

## 2. Connect to SAP BTP Cluster

### Step 2.1: Connect to VPN

1. Open **GlobalProtect VPN** client
2. Enter the VPN address:
   ```
   gpvpn.deloitteinnovation.us
   ```
3. Enter your credentials and connect
4. Wait for successful connection (green icon)

### Step 2.2: Download Cluster Configuration

Open your terminal and run:

```bash
curl -o ~/kubeconfig-kyma.yaml "https://kyma-env-broker.cp.kyma.cloud.sap/kubeconfig/XXXXXXX-xxxx-481D-864F-xxxxxxxxx"
```

### Step 2.3: Set Kubernetes Configuration

```bash
export KUBECONFIG=~/kubeconfig-kyma.yaml
```

> 💡 **Tip**: Add this line to your `~/.bashrc` or `~/.zshrc` file to make it permanent.

---

## 3. Verify Cluster Connection

### Step 3.1: Test Connection

```bash
kubectl cluster-info
```

You will be prompted to enter your **username** and **password**. Use your SAP BTP credentials.

### Step 3.2: Verify Namespace

After successful login, check if services are running:

```bash
kubectl get pods -n zora-ai-cfo
```

**Expected output for a fresh installation**: No resources found (this is normal for first-time deployment)

**Expected output for existing installation**:
```
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-backend-5677769455-cqght                1/1     Running     0          4d
zora-ai-configuration-server-5ccfb97b6b-gsgz7   1/1     Running     0          4d
zora-ai-frontend-6486b46f5d-rdf5d               1/1     Running     0          4d
zora-ai-postgres-0                              2/2     Running     0          4d
...
```

---

## 4. Configure Secrets

Secrets contain sensitive information like API keys and passwords. You **must** configure these before deployment.

### Step 4.1: Locate the Secrets File

Navigate to the secrets folder:
```
sap/dev/secrets/zora-ai-secrets.yaml
```

### Step 4.2: Values to Change

Open `zora-ai-secrets.yaml` and update the following sections:

#### 🔐 Container Registry Secret (Section 1: JFrog Image Pull Secret)

Update the registry credentials to match your container registry:

```yaml
# 1. JFrog Image Pull Secret
apiVersion: v1
kind: Secret
metadata:
  name: jfrog-registry-secret
type: kubernetes.io/dockerconfigjson
stringData:
  .dockerconfigjson: |
    {
      "auths": {
        "YOUR-REGISTRY.example.com": {                    # ← Change to your registry URL
          "username": "YOUR_REGISTRY_USERNAME",           # ← Change this
          "password": "YOUR_REGISTRY_PASSWORD_OR_TOKEN",  # ← Change this
          "auth": "BASE64_ENCODED_USERNAME_PASSWORD"      # ← Change this (base64 of username:password)
        }
      }
    }
```

> 💡 **Tip**: Generate the `auth` value by running: `echo -n "username:password" | base64`

#### 🐳 Update Docker Image Locations

After configuring your registry secret, you must also update the Docker image locations in **every values file** to point to your container registry.

**Files to update** (in `sap/dev/`):

| Values File | Service |
|-------------|---------|
| `values-zora-ai-backend.yaml` | Backend API |
| `values-zora-ai-frontend.yaml` | Frontend |
| `values-zora-ai-engine.yaml` | AI Engine |
| `values-zora-ai-configuration-server.yaml` | Configuration Server |
| `values-zora-ai-customer-data-server.yaml` | Customer Data Server |
| `values-zora-ai-rbac-backend.yaml` | RBAC Backend |
| `values-zora-ai-rbac-backend-ui.yaml` | RBAC Backend UI |
| `values-zora-ai-rbac-frontend.yaml` | RBAC Frontend |
| `values-zora-ai-postgres-init-db.yaml` | DB Init Job |
| `values-zora-agent-skills.yaml` | Agent Skills Job |

In each file, find and update the `image` section:

```yaml
image:
  repository: YOUR-REGISTRY.example.com/zora-ai/service-name  # ← Change to your registry
  tag: "latest"                                                # ← Update if needed
  pullPolicy: IfNotPresent
```

> ⚠️ **Important**: Make sure the registry URL matches what you configured in the JFrog Image Pull Secret above.

#### 🔐 LLM Model Configuration (Section 4: Engine Secrets)

```yaml
# 4. Engine Secrets (1 key: AZURE_LLM_API_KEY)
apiVersion: v1
kind: Secret
metadata:
  name: zora-ai-engine-secrets
type: Opaque
stringData:
  AZURE_LLM_API_KEY: "YOUR_AZURE_OPENAI_API_KEY_HERE"    # ← Change this
```

#### 🤖 Configure AI Model Settings

In addition to the API key secret, you must update the AI model configuration in `sap/dev/values-zora-ai-engine.yaml`:

```yaml
env:
  # Azure AI Foundry / OpenAI Configuration
  AZURE_LLM_ENDPOINT: "https://YOUR-AI-ENDPOINT.services.ai.azure.com/openai/v1/"  # ← Change this
  
  # Model Provider Settings
  DEF_MODEL_PROVIDER: "openai"           # Use 'openai' for Azure AI Foundry
  DB_AGENT_MODEL_DRIVER: "openai"        # Use 'openai' driver
  DB_AGENT_MODEL_NAME: "YOUR-MODEL-NAME" # ← Change to your deployed model name
  DEF_MODEL: "YOUR-MODEL-NAME"           # ← Change to your deployed model name
  DB_AGENT_STREAMING_ENABLED: "false"    # Set to "true" if streaming is supported
  
  # If using a reasoning model (like DeepSeek, o1, etc.)
  REASONING_MODELS: '["YOUR-MODEL-NAME"]'  # ← Add your reasoning model names
```

> 💡 **Tip**: Get the endpoint URL and model name from your Azure AI Foundry or OpenAI deployment.

#### 🔐 OIDC/SSO Configuration (Section 5: RBAC Backend Secrets)

```yaml
# 5. RBAC Backend Secrets (OIDC secrets)
apiVersion: v1
kind: Secret
metadata:
  name: zora-ai-rbac-secrets
type: Opaque
stringData:
  OIDC_CLIENTSECRET: "YOUR_AZURE_AD_CLIENT_SECRET_HERE"  # ← Change this
```

#### 🔐 Database Passwords (Optional - Section 2)

If you want custom database passwords, update:
```yaml
# 2. Postgres Secrets
stringData:
  postgres-password: "YOUR_STRONG_PASSWORD"
  postgres-read-password: "YOUR_STRONG_PASSWORD"
  developer-password: "YOUR_STRONG_PASSWORD"
```

### Step 4.3: Deploy Secrets

```bash
kubectl apply -f sap/dev/secrets/zora-ai-secrets.yaml -n zora-ai-cfo
```

### Step 4.4: Verify Secrets

```bash
kubectl get secrets -n zora-ai-cfo
```

You should see secrets like `zora-ai-postgres-secrets`, `zora-ai-engine-secrets`, etc.

---

## 5. Configure DNS/Ingress

Before deploying applications, you need to configure your DNS names.

### ❓ First, Ask Your SAP Admin

Contact your SAP BTP administrator and ask:
> "What ingress method does our cluster use - **Ingress** or **HTTPRoute (Gateway API)**?"

### 📝 Files to Update

Based on their answer, update DNS names in these files:

#### File 1: Frontend (`sap/dev/values-zora-ai-frontend.yaml`)

Find and update:
```yaml
ingress:
  enabled: true    # Set to 'true' for Ingress, 'false' for HTTPRoute
  hosts:
    - host: YOUR-FRONTEND-DOMAIN.example.com    # ← Change this
  tls:
    - hosts:
        - YOUR-FRONTEND-DOMAIN.example.com      # ← Change this

httpRoute:
  enabled: false   # Set to 'true' for HTTPRoute, 'false' for Ingress
  host: YOUR-FRONTEND-DOMAIN.example.com        # ← Change this
```

#### File 2: RBAC Frontend (`sap/dev/values-zora-ai-rbac-frontend.yaml`)

Find and update:
```yaml
ingress:
  enabled: true
  host: YOUR-RBAC-DOMAIN.example.com            # ← Change this

env:
  REACT_APP_API_URL: https://YOUR-RBAC-DOMAIN.example.com/api    # ← Change this
  REACT_CC_PROD_DOMAIN: YOUR-RBAC-DOMAIN.example.com             # ← Change this
```

#### File 3: RBAC Backend (`sap/dev/values-zora-ai-rbac-backend.yaml`)

Find and update:
```yaml
env:
  ISSUER: https://YOUR-RBAC-API-DOMAIN.example.com                                    # ← Change this
  JWT_ISSUER: https://YOUR-RBAC-API-DOMAIN.example.com                                # ← Change this
  LOCALHOST_ENDPOINT: https://YOUR-FRONTEND-DOMAIN.example.com/sso/callback           # ← Change this (CFO Frontend)
  ALLOWED_AUDIENCES: https://YOUR-RBAC-API-DOMAIN.example.com                         # ← Change this
  OIDC_CALLBACKURL: "https://YOUR-FRONTEND-DOMAIN.example.com/rbac/authentication/login/callback"  # ← Change this

ingress:
  host: YOUR-RBAC-API-DOMAIN.example.com                                              # ← Change this
  tls:
    - hosts:
        - YOUR-RBAC-API-DOMAIN.example.com                                            # ← Change this
```

#### File 4: RBAC Backend UI (`sap/dev/values-zora-ai-rbac-backend-ui.yaml`)

Find and update:
```yaml
env:
  ISSUER: https://YOUR-RBAC-API-UI-DOMAIN.example.com                                 # ← Change this
  JWT_ISSUER: https://YOUR-RBAC-API-UI-DOMAIN.example.com                             # ← Change this
  LOCALHOST_ENDPOINT: https://YOUR-RBAC-DOMAIN.example.com/sso/callback               # ← Change this (RBAC Frontend)
  ALLOWED_AUDIENCES: https://YOUR-RBAC-API-UI-DOMAIN.example.com                      # ← Change this
  OIDC_CALLBACKURL: "https://YOUR-RBAC-DOMAIN.example.com/api/authentication/login/callback"       # ← Change this

ingress:
  host: YOUR-RBAC-API-UI-DOMAIN.example.com                                           # ← Change this
  tls:
    - hosts:
        - YOUR-RBAC-API-UI-DOMAIN.example.com                                         # ← Change this
```

> 💡 **Note**: There are **two** RBAC Backend instances:
> - **RBAC Backend** (`values-zora-ai-rbac-backend.yaml`) - serves CFO Frontend SSO
> - **RBAC Backend UI** (`values-zora-ai-rbac-backend-ui.yaml`) - serves RBAC Frontend SSO

#### File 5: API Proxy (`sap/dev/rbac-api-proxy/ingress.yaml`)

Find and update:
```yaml
spec:
  tls:
    - hosts:
        - YOUR-RBAC-DOMAIN.example.com          # ← Change this
  rules:
    - host: YOUR-RBAC-DOMAIN.example.com        # ← Change this
```

---

## 6. Adjust Resource Limits (Optional)

The default resource limits in the values files are set conservatively (minimal CPU and memory). **You can increase these based on your environment's capacity and workload requirements.**

### Where to Find Resource Limits

Resource limits are defined in each service's values file under the `resources` section:

```yaml
resources:
  requests:
    memory: "256Mi"
    cpu: "100m"
  limits:
    memory: "512Mi"
    cpu: "500m"
```

### Recommended Adjustments

For production environments with higher workloads, consider increasing resources in these values files:

| Service | Values File | Recommended Memory Limit |
|---------|-------------|-------------------------|
| AI Engine | `values-zora-ai-engine.yaml` | 2Gi - 4Gi |
| Backend | `values-zora-ai-backend.yaml` | 1Gi - 2Gi |
| PostgreSQL | `values-zora-ai-postgres.yaml` | 2Gi - 4Gi |
| Redis | `values-zora-ai-redis.yaml` | 1Gi - 2Gi |
| Frontend | `values-zora-ai-frontend.yaml` | 512Mi - 1Gi |

> 💡 **Tip**: Monitor your pods after deployment using `kubectl top pods -n zora-ai-cfo` to understand actual resource usage and adjust accordingly.

---

## 7. Deploy Infrastructure

Deploy services in this order. Wait for each to be ready before proceeding.

### Step 7.1: PostgreSQL Database

```bash
helm upgrade --install zora-ai-postgres charts/zora-ai-postgres \
  -f sap/dev/values-zora-ai-postgres.yaml \
  -n zora-ai-cfo
```

**Wait for database to be ready:**
```bash
kubectl get pods -n zora-ai-cfo -w
```
Wait until `zora-ai-postgres-0` shows `2/2 Running`

### Step 7.2: Redis Cache

```bash
helm upgrade --install zora-ai-redis charts/zora-ai-redis \
  -f sap/dev/values-zora-ai-redis.yaml \
  -n zora-ai-cfo
```

**Wait for Redis to be ready:**
```bash
kubectl get pods -n zora-ai-cfo | grep redis
```
Wait until all Redis pods show `Running`

### Step 7.3: Initialize Database

```bash
helm upgrade --install zora-ai-postgres-init-db charts/zora-ai-jobs \
  -f sap/dev/values-zora-ai-postgres-init-db.yaml \
  -n zora-ai-cfo
```

### Step 7.4: Load Agent Skills

```bash
helm upgrade --install zora-agent-skills charts/zora-ai-jobs \
  -f sap/dev/values-zora-agent-skills.yaml \
  -n zora-ai-cfo
```

---

## 8. Deploy Applications

Deploy applications in this order:

### Step 8.1: Configuration Server

```bash
helm upgrade --install zora-ai-configuration-server charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-configuration-server.yaml \
  -n zora-ai-cfo
```

### Step 8.2: Customer Data Server

```bash
helm upgrade --install zora-ai-customer-data-server charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-customer-data-server.yaml \
  -n zora-ai-cfo
```

### Step 8.3: AI Engine

```bash
helm upgrade --install zora-ai-engine charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-engine.yaml \
  -n zora-ai-cfo
```

### Step 8.4: Backend API

```bash
helm upgrade --install zora-ai-backend charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-backend.yaml \
  -n zora-ai-cfo
```

### Step 8.5: Frontend

```bash
helm upgrade --install zora-ai-frontend charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-frontend.yaml \
  -n zora-ai-cfo
```

### Step 8.6: RBAC Services

```bash
# RBAC Backend
helm upgrade --install zora-ai-rbac-app charts/zora-ai-rbac-app \
  -f sap/dev/values-zora-ai-rbac-backend.yaml \
  -n zora-ai-cfo

# RBAC Backend UI
helm upgrade --install zora-ai-rbac-app-ui charts/zora-ai-rbac-app \
  -f sap/dev/values-zora-ai-rbac-backend-ui.yaml \
  -n zora-ai-cfo

# RBAC Frontend
helm upgrade --install zora-ai-rbac-ui charts/zora-ai-rbac-ui \
  -f sap/dev/values-zora-ai-rbac-frontend.yaml \
  -n zora-ai-cfo
```

### Step 8.7: Deploy API Proxy

```bash
kubectl apply -f sap/dev/rbac-api-proxy/ingress.yaml -n zora-ai-cfo
```

### Step 8.8: Backup Job (Optional)

```bash
helm upgrade --install zora-ai-postgres-backup charts/zora-ai-jobs \
  -f sap/dev/values-zora-ai-postgres-backup.yaml \
  -n zora-ai-cfo
```

---

## 9. Verify Deployment

### Check All Pods

```bash
kubectl get pods -n zora-ai-cfo
```

**Expected output** - All pods should show `Running` or `Completed`:
```
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-backend-xxxxx                           1/1     Running     0          5m
zora-ai-configuration-server-xxxxx              1/1     Running     0          10m
zora-ai-customer-data-server-xxxxx              1/1     Running     0          9m
zora-ai-engine-xxxxx                            1/1     Running     0          8m
zora-ai-frontend-xxxxx                          1/1     Running     0          6m
zora-ai-postgres-0                              2/2     Running     0          15m
zora-ai-rbac-app-xxxxx                          1/1     Running     0          4m
zora-ai-rbac-app-ui-xxxxx                       1/1     Running     0          3m
zora-ai-rbac-ui-xxxxx                           1/1     Running     0          2m
zora-ai-redis-0                                 2/2     Running     0          14m
zora-ai-redis-1                                 2/2     Running     0          13m
```

### Access Your Application

Open your browser and navigate to your configured frontend URL:
- **Main Application**: `https://YOUR-FRONTEND-DOMAIN.example.com`
- **RBAC Management**: `https://YOUR-RBAC-DOMAIN.example.com`

---

## 10. Configure Azure AD for SSO

After deployment is complete and pods are running, configure Azure AD for Single Sign-On.

### 🔑 Azure AD App Registration Setup

For SSO to work, you must register **both callback URLs** in your Azure AD App Registration:

| Callback URL | Purpose |
|--------------|---------|
| `https://YOUR-RBAC-DOMAIN.example.com/api/authentication/login/callback` | RBAC Backend direct login |
| `https://YOUR-FRONTEND-DOMAIN.example.com/rbac/authentication/login/callback` | CFO Frontend SSO redirect |

**Steps to configure in Azure Portal:**
1. Go to **Azure Portal** → **App Registrations** → Your App
2. Navigate to **Authentication** → **Platform configurations**
3. Under **Web** → **Redirect URIs**, add both callback URLs above
4. Save changes

**Example URLs:**
| URL Type | Example |
|----------|--------|
| CFO Frontend | `zora-ai.btpdev.aiops-d.cloud` |
| RBAC Frontend | `rbac-zora-ai.btpdev.aiops-d.cloud` (Digital Worker access management) |

> ⚠️ **Important**: The callback URLs must exactly match what you configured in `values-zora-ai-rbac-backend.yaml` and `values-zora-ai-rbac-backend-ui.yaml` for SSO to work properly.

---

## 11. Troubleshooting

### Pod Not Starting?

Check pod events:
```bash
kubectl describe pod <pod-name> -n zora-ai-cfo
```

### Check Logs

```bash
kubectl logs <pod-name> -n zora-ai-cfo --tail=100
```

### Restart a Deployment

```bash
kubectl rollout restart deployment <deployment-name> -n zora-ai-cfo
```

### Delete and Redeploy

```bash
helm uninstall <release-name> -n zora-ai-cfo
helm upgrade --install <release-name> <chart> -f <values-file> -n zora-ai-cfo
```

### Common Issues

| Issue | Solution |
|-------|----------|
| Pod stuck in `Pending` | Check if secrets are deployed: `kubectl get secrets -n zora-ai-cfo` |
| Pod in `CrashLoopBackOff` | Check logs: `kubectl logs <pod-name> -n zora-ai-cfo` |
| Cannot connect to database | Ensure PostgreSQL pod is running and secrets are correct |
| SSO not working | Verify OIDC settings and callback URLs match your DNS |

---


## Need Help?

Contact your deployment support team if you encounter any issues not covered in this guide.

---
