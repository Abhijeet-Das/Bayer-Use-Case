#!/usr/bin/env python3
"""Download and extract values archive from Edge Artifactory."""

import os
import subprocess
import sys
import tarfile
from pathlib import Path

EDGE_URL = "https://edge.engineeringplatforms.deloitte.com/artifactory"
EDGE_USER = "XXXXXXXXX"  # Use jfrog service account username.
EDGE_TOKEN = "XXXXXXXXX"  # Use jfrog service account token.
CLIENT_EDGE_NODE_PATH = "XXXXXXXXXX"  # example: zora-xxx-docker-release-local
ARTIFACT_PATH = f"{CLIENT_EDGE_NODE_PATH}/aiq-ext-client/zora-values-files.tgz"
OUTPUT_DIR = Path("./extracted-values")


def download_artifact() -> Path | None:
    print(f"\n{'=' * 60}")
    print("Downloading values archive from Edge...")
    print(f"{'=' * 60}\n")

    if not EDGE_TOKEN:
        print("ERROR: EDGE_TOKEN is not set")
        print("Set it with: export EDGE_TOKEN='your-token-here'")
        return None

    url = f"{EDGE_URL}/{ARTIFACT_PATH}"
    output_file = Path(Path(ARTIFACT_PATH).name)

    print(f"URL: {url}")
    print(f"Output: {output_file}")
    print("-" * 40)

    # Use curl with -L to follow redirects
    cmd = [
        "curl", "-L", "-f", "-s", "-S",
        "-u", f"{EDGE_USER}:{EDGE_TOKEN}",
        "-o", str(output_file),
        url
    ]

    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.returncode != 0:
        print(f"✗ Failed to download: {result.stderr}")
        return None

    print(f"✓ Downloaded {output_file}")
    return output_file


def is_safe_member(base_dir: Path, member_name: str) -> bool:
    member_path = (base_dir / member_name).resolve()
    return str(member_path).startswith(str(base_dir.resolve()) + os.sep) or member_path == base_dir.resolve()


def extract_artifact(archive_path: Path) -> bool:
    print(f"\n{'=' * 60}")
    print("Extracting archive...")
    print(f"{'=' * 60}\n")

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

    try:
        with tarfile.open(archive_path, "r:gz") as archive:
            members = archive.getmembers()
            for member in members:
                if not is_safe_member(OUTPUT_DIR, member.name):
                    print(f"✗ Unsafe archive member blocked: {member.name}")
                    return False
            archive.extractall(path=OUTPUT_DIR)
    except Exception as error:
        print(f"✗ Failed to extract: {error}")
        return False

    print(f"✓ Extracted to {OUTPUT_DIR}/")
    print("\nExtracted contents:")
    print("-" * 40)
    for root, _, files in os.walk(OUTPUT_DIR):
        level = root.replace(str(OUTPUT_DIR), "").count(os.sep)
        indent = "  " * level
        print(f"{indent}{Path(root).name}/")
        subindent = "  " * (level + 1)
        for file in files:
            print(f"{subindent}{file}")

    return True


def main() -> None:
    print("\n" + "=" * 60)
    print("Download and Extract Values Files")
    print("=" * 60)

    archive_path = download_artifact()
    if not archive_path:
        sys.exit(1)

    if not extract_artifact(archive_path):
        sys.exit(1)

    print(f"\n{'=' * 60}")
    print("SUCCESS")
    print(f"{'=' * 60}")
    print(f"Values files extracted to: {OUTPUT_DIR}/")


if __name__ == "__main__":
    main()
