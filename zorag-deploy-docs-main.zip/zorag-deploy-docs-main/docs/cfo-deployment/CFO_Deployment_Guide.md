﻿# CFO Application - Deployment Guide

---

## Prerequisites

- Python 3 installed
## STEP 1: Prerequisites

### Required Tools
- Python 3
- Kubernetes cluster (v1.19+)
- kubectl CLI (v1.19+)
- Helm CLI (v3+)
- JFrog credentials (username and token)

### Infrastructure Requirements
- **Ingress Controller / Application Gateway** - NGINX or cloud-native (Azure App Gateway, AWS ALB, GCP Cloud LB)
- **DNS Configuration** - A records pointing to Ingress Controller external IP
- **SSL/TLS Certificates** - Valid certificates for HTTPS endpoints
- **StorageClass** - Default storage class for PostgreSQL and Redis volumes

### RBAC & Authentication
- App Registration in Identity Provider (Azure AD, Okta, etc.)
- Redirect URI: `https://<your-domain>/rbac/authentication/login/callback`
- Required parameters: Client ID, Client Secret, OIDC endpoints

### Verify Prerequisites
```bash
kubectl get nodes
kubectl get storageclass
kubectl get pods -A | grep ingress
```
## STEP 2: Download and Extract Files

### Configure `download_and_extract_values.py`

Update the following variables:
```python
EDGE_USER = "XXXXXXXXXXXX"      # JFrog username
EDGE_TOKEN = "XXXXXXXXXXXX"     # JFrog token
ARTIFACT_PATH = "XXXXXXXXXXXX"  # Path to values archive
```

> **Note:** Obtain `EDGE_USER`, `EDGE_TOKEN`, and `ARTIFACT_PATH` values from your team's JFrog administrator.

### Run the Script
```bash
python3 download_and_extract_values.py
```

### Navigate to Extracted Directory
```bash
cd extracted-values/cfo-values
```

### Expected Output

```text
============================================================
Download and Extract Values Files
============================================================

Downloading values archive from Edge...
URL: https://edge.engineeringplatforms.deloitte.com/artifactory/XXXXXXXXXXXXXXXX/aiq-ext-client/zora-values-files.tgz
âœ“ Downloaded zora-values-files.tgz

Extracting archive...
âœ“ Extracted to extracted-values/

Extracted contents:
  cfo-values/
    cfo_end-to-end_deployment.py
    values-zora-agent-skills.yaml
    values-zora-ai-backend.yaml
    values-zora-ai-configuration-server.yaml
    values-zora-ai-customer-data-server.yaml
    values-zora-ai-engine.yaml
    values-zora-ai-frontend.yaml
    values-zora-ai-postgres-init-db.yaml
    values-zora-ai-postgres.yaml
    values-zora-ai-rbac-backend-ui.yaml
    values-zora-ai-rbac-backend.yaml
    values-zora-ai-rbac-frontend.yaml
    values-zora-ai-redis.yaml
    zora-ai-k8s-secrets.yaml.zip
    rbac-api-proxy/
      ingress.yaml

============================================================
SUCCESS
============================================================
Values files extracted to: extracted-values/
```

---

## STEP 3: Update Configuration Files

1. **Unzip and update secrets (`zora-ai-k8s-secrets.yaml`):**

   The following keys must be populated in `zora-ai-k8s-secrets.yaml` before deploying:

   | Secret Key | Description |
   |---|---|
   | `OIDC_CLIENTID` | Client ID of your Azure AD app registration |
   | `OIDC_CLIENTSECRET` | Client Secret of your Azure AD app registration |
   | `AZURE_LLM_API_KEY` | API key for your Azure OpenAI / LLM endpoint |
   | `LANGFUSE_PUBLIC_KEY` | Public key for Langfuse observability |
   | `LANGFUSE_SECRET_KEY` | Secret key for Langfuse observability |

   > These values are referenced in the Kubernetes deployments via `secretKeyRef` and will not work if left empty.

2. **Update RBAC values files â€” OIDC Client ID and Azure AD Tenant ID:**

   Update the following in **both** `values-zora-ai-rbac-backend.yaml` and `values-zora-ai-rbac-backend-ui.yaml`:

   **`OIDC_CLIENTID`** â€” replace with your Azure AD app registration Client ID:
   ```yaml
   OIDC_CLIENTID: "xxxxxxxxxxxxxxxxxxxxxxxxxxxx"  # â† Replace with your Azure AD Client ID
   ```

   **Azure AD Tenant ID** â€” the OIDC and CIAM URLs contain a hardcoded tenant ID that must be replaced with your own Azure AD tenant ID:
   ```yaml
   OIDC_ISSUER: "https://login.microsoftonline.com/<your-tenant-id>/v2.0"
   OIDC_AUTHURL: "https://login.microsoftonline.com/<your-tenant-id>/oauth2/v2.0/authorize"
   OIDC_TOKENURL: "https://login.microsoftonline.com/<your-tenant-id>/oauth2/v2.0/token"
   CIAM_TOKEN_ENDPOINT: "https://login.microsoftonline.com/<your-tenant-id>/oauth2/v2.0/token"
   ```

   > These URLs are not updated by the deployment script â€” they must be changed manually in both files.

3. **Update engine values file (`values-zora-ai-engine.yaml`):**

   The endpoint and model names are **for reference only** â€” update them to match your client's Azure AI resources:

   ```yaml
   # Azure LLM Configuration
   AZURE_LLM_ENDPOINT: "https://<your-azure-openai-endpoint>/openai/v1/"  # Your Azure AI endpoint

   # LLM Model Configuration
   DB_AGENT_MODEL_NAME: "<your-model-deployment-name>"  # Your model deployment name
   DEF_MODEL: "<your-model-deployment-name>"            # Your model deployment name

   # Langfuse Configuration
   LANGFUSE_HOST: "https://<your-langfuse-host>"        # Your Langfuse instance URL
   ```

   > `AZURE_LLM_API_KEY`, `LANGFUSE_PUBLIC_KEY`, and `LANGFUSE_SECRET_KEY` are pulled from `zora-ai-engine-secrets` (populated via `zora-ai-k8s-secrets.yaml` â€” see step 1 above).

4. **Update RBAC Frontend product URLs (`values-zora-ai-rbac-frontend.yaml`):**

   Update `REACT_APP_PRODUCT_URLS` to point to your client's deployed product endpoints:

   ```yaml
   REACT_APP_PRODUCT_URLS: "https://<your-product-url-1>,https://<your-product-url-2>"
   REACT_APP_PRODUCTS: "forecasting,agent"  # Comma-separated product keys matching the URLs above
   ```

5. **Update Load Balancer annotations for PostgreSQL and Redis:**

   `values-zora-ai-postgres.yaml` and `values-zora-ai-redis.yaml` have `service.annotations` set for Azure by default. Update to match your cloud provider:

   ```yaml
   # Azure (default):
   annotations:
     service.beta.kubernetes.io/azure-load-balancer-internal: "true"

   # AWS:
   annotations:
     service.beta.kubernetes.io/aws-load-balancer-internal: "true"

   # GCP:
   annotations:
     cloud.google.com/load-balancer-type: "Internal"
   ```

> **Note:** DNS, registry paths, and ingress/HTTPRoute settings are automatically updated by the deployment script. All items listed above must be updated manually before running the script.

---

## STEP 4: (Optional) AKS Azure Disk StorageClass (cluster-scoped)

### What This Step Does
Creates a custom Azure Disk StorageClass with Retain policy for persistent storage in AKS clusters.

**Note:** This step is **optional**. Only configure this custom StorageClass if you need specific storage requirements (Premium SSD, Retain policy, etc.). If you skip this step, Kubernetes will use the default StorageClass configured in your AKS cluster.

### Instructions

**4.1** Create `azuredisk-sc.yaml`:

```yaml
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: azuredisk-premium-milvus-retain
provisioner: disk.csi.azure.com
reclaimPolicy: Retain
volumeBindingMode: WaitForFirstConsumer
allowVolumeExpansion: true
parameters:
  skuName: Premium_LRS
  kind: Managed
```

**4.2** Apply and verify:

```bash
kubectl apply -f azuredisk-sc.yaml
kubectl get storageclass azuredisk-premium-milvus-retain
```

**4.3** Configure StorageClass in values files (if using custom StorageClass):

**For PostgreSQL (`values-zora-ai-postgres.yaml`):**
```yaml
persistence:
  enabled: true
  storageClass: "azuredisk-premium-milvus-retain"
  size: 50Gi
```

**For Redis (`values-zora-ai-redis.yaml`):**
```yaml
master:
  persistence:
    enabled: true
    storageClass: "azuredisk-premium-milvus-retain"
    size: 10Gi

replica:
  persistence:
    enabled: true
    storageClass: "azuredisk-premium-milvus-retain"
    size: 10Gi
```

---

## STEP 5: Deploy CFO Application (Automated End-to-End)

### What This Step Does
Deploys all 12 application components to Kubernetes using a single end-to-end deployment script. This script handles:
- Namespace and secrets creation
- Helm repository configuration
- Deployment of all 12 services in staged order with proper wait times
- **Reinstallation of postgres-init-db** (to ensure clean database initialization)

**Note:** This deployment creates fresh databases - no data migration is performed. If you need to restore data from backups, you must do so manually after deployment is complete.

### Instructions

**5.1** Configure `cfo_end-to-end_deployment.py`:

   Update the following variables:

   ```python
   EDGE_USER = "XXXXXXXXXXXX"           # JFrog username
   EDGE_TOKEN = "XXXXXXXXXXXX"          # JFrog token
   NAMESPACE = "<your-namespace>"          # Target namespace

   # Client/Region Configuration
   CLIENT_REGION = "XXXXXXXXXXXX"       # Update this to match your client/region's Docker registry path
   CLIENT_DNS = "XXXXXXXXXXXX"          # Update this to match your client's DNS domain (e.g., "client.zoraai.eng.deloitte.com")

   # Gateway Configuration: Set based on client's ingress preference
   # If using Ingress Gateway: INGRESS_ENABLED = "true", HTTP_ROUTE_ENABLED = "false"
   # If using App Gateway (HTTPRoute): INGRESS_ENABLED = "false", HTTP_ROUTE_ENABLED = "true"
   INGRESS_ENABLED = "false"
   HTTP_ROUTE_ENABLED = "true"
   ```

### What the Script Does Automatically

The deployment script will automatically update all values files based on your configuration:

1. **Docker Registry Path** - Updates the JFrog repository name in all values files based on `CLIENT_REGION`
2. **DNS Domain** - Updates ingress hostnames in all values files based on `CLIENT_DNS`
3. **Gateway Configuration** - Configures either Ingress or HTTPRoute in all applicable values files based on `INGRESS_ENABLED` and `HTTP_ROUTE_ENABLED` settings
4. **RBAC API Proxy** - Updates the `rbac-api-proxy/ingress.yaml` configuration accordingly

**5.2** Run the end-to-end deployment script:

```bash
python3 cfo_end-to-end_deployment.py
```

**5.3** The script will automatically:
  - **Update registry paths, DNS, and gateway settings in all values files**
   - Create namespace: `<your-namespace>` (value of `NAMESPACE` variable)
   - Create Docker registry secret: `jfrog-registry-secret`
   - Apply Kubernetes secrets from `zora-ai-k8s-secrets.yaml`
   - Configure Helm repository: `aiq-charts`
   - Deploy all 12 components in staged order
   - Reinstall postgres-init-db (to ensure clean database initialization)
   - Display deployment status

**Expected Script Output (beginning):**

```text
============================================================
JFrog Edge Values + Helm Deployment
============================================================

============================================================
Updating registry paths to: XXXXXXXXXXXXXXXX
============================================================

  âœ“ Updated: values-zora-ai-backend.yaml
  âœ“ Updated: values-zora-ai-frontend.yaml
  âœ“ Updated: values-zora-ai-configuration-server.yaml
  âœ“ Updated: values-zora-ai-customer-data-server.yaml
  âœ“ Updated: values-zora-ai-engine.yaml
  âœ“ Updated: values-zora-ai-postgres.yaml
  âœ“ Updated: values-zora-ai-postgres-init-db.yaml
  âœ“ Updated: values-zora-ai-redis.yaml
  âœ“ Updated: values-zora-ai-rbac-backend.yaml
  âœ“ Updated: values-zora-ai-rbac-backend-ui.yaml
  âœ“ Updated: values-zora-ai-rbac-frontend.yaml
  âœ“ Updated: values-zora-agent-skills.yaml


============================================================
Updating DNS domain to: XXXXXXXXXXXXXXXX
============================================================

  - No change: values-zora-ai-backend.yaml
  - No change: values-zora-ai-frontend.yaml
  - No change: values-zora-ai-configuration-server.yaml
  - No change: values-zora-ai-customer-data-server.yaml
  - No change: values-zora-ai-engine.yaml
  - No change: values-zora-ai-postgres.yaml
  - No change: values-zora-ai-postgres-init-db.yaml
  - No change: values-zora-ai-redis.yaml
  - No change: values-zora-ai-rbac-backend.yaml
  - No change: values-zora-ai-rbac-backend-ui.yaml
  - No change: values-zora-ai-rbac-frontend.yaml
  - No change: values-zora-agent-skills.yaml


============================================================
Updating gateway settings: ingress.enabled=false, httpRoute.enabled=true
============================================================

  âœ“ Updated: values-zora-ai-backend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-frontend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-configuration-server.yaml (2 changes)
  âœ“ Updated: values-zora-ai-customer-data-server.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-backend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-backend-ui.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-frontend.yaml (2 changes)


============================================================
Updating RBAC API Proxy ingress configuration
============================================================

  Using HTTPRoute (Gateway API)
  âœ“ Updated: rbac-api-proxy/ingress.yaml


============================================================
Ensuring namespace <your-namespace> exists...
============================================================
```

**5.4** Monitor the deployment progress in the terminal output.

### Deployment Stages
| Stage | Components | Wait Time |
|-------|------------|-----------|
| 1 | PostgreSQL | 180s |
| 2 | postgres-init-db | 120s |
| 3 | Agent Skills | 120s |
| 4 | Configuration Server, Customer Data Server, Redis | 120s |
| 5 | RBAC Backend UI | 120s |
| 6 | RBAC Backend | 120s |
| 7 | Backend, Engine, Frontend | 0s |
| 8 | RBAC Frontend | 0s |
| 9 | Reinstall postgres-init-db | 120s |

### Components Deployed
1. **zora-ai-postgres** - PostgreSQL Database
2. **zora-ai-postgres-init-db** - Database Initialization Job
3. **zora-agent-skills** - Agent Skills Initialization Job
4. **zora-ai-configuration-server** - Configuration Service
5. **zora-ai-customer-data-server** - Customer Data Service
6. **zora-ai-redis** - Redis Cache
7. **zora-ai-rbac-backend-ui** - RBAC Backend UI
8. **zora-ai-rbac-backend** - RBAC Backend Service
9. **zora-ai-backend** - Backend API Service
10. **zora-ai-engine** - AI Engine Service
11. **zora-ai-frontend** - Frontend Application
12. **zora-ai-rbac-frontend** - RBAC Frontend Application

### Standard Service Mapping

| Release | Chart | Chart Version | Values File |
|---------|-------|---------------|-------------|
| zora-ai-postgres | aiq-charts/zora-ai-postgres | `<CHART_VERSION>` | values-zora-ai-postgres.yaml |
| zora-ai-redis | aiq-charts/zora-ai-redis | `<CHART_VERSION>` | values-zora-ai-redis.yaml |
| zora-ai-postgres-init-db | aiq-charts/zora-ai-jobs | `<CHART_VERSION>` | values-zora-ai-postgres-init-db.yaml |
| zora-agent-skills | aiq-charts/zora-ai-jobs | `<CHART_VERSION>` | values-zora-agent-skills.yaml |
| zora-ai-configuration-server | aiq-charts/zora-ai-universal-chart | `<CHART_VERSION>` | values-zora-ai-configuration-server.yaml |
| zora-ai-customer-data-server | aiq-charts/zora-ai-universal-chart | `<CHART_VERSION>` | values-zora-ai-customer-data-server.yaml |
| zora-ai-backend | aiq-charts/zora-ai-universal-chart | `<CHART_VERSION>` | values-zora-ai-backend.yaml |
| zora-ai-engine | aiq-charts/zora-ai-universal-chart | `<CHART_VERSION>` | values-zora-ai-engine.yaml |
| zora-ai-frontend | aiq-charts/zora-ai-universal-chart | `<CHART_VERSION>` | values-zora-ai-frontend.yaml |
| zora-ai-rbac-backend-ui | aiq-charts/zora-ai-comserv-rbac-app | `<CHART_VERSION>` | values-zora-ai-rbac-backend-ui.yaml |
| zora-ai-rbac-backend | aiq-charts/zora-ai-comserv-rbac-app | `<CHART_VERSION>` | values-zora-ai-rbac-backend.yaml |
| zora-ai-rbac-frontend | aiq-charts/zora-ai-comserv-rbac-ui | `<CHART_VERSION>` | values-zora-ai-rbac-frontend.yaml |

### Expected Deployment Time
- **Full end-to-end deployment typically takes 15-20 minutes**
- Service deployment: ~10-15 minutes (all 11 services in staged order)
- Postgres-init-db reinstallation: ~4-5 minutes (clean database initialization)
- Wait times between stages ensure proper startup dependencies

### Expected Output

When you run the deployment script, you will see output similar to this:

```text
$ python3 cfo_end-to-end_deployment.py 

============================================================
JFrog Edge Values + Helm Deployment
============================================================

============================================================
Updating registry paths to: XXXXXXXXXXXXXXXX
============================================================

  âœ“ Updated: values-zora-ai-backend.yaml
  âœ“ Updated: values-zora-ai-frontend.yaml
  âœ“ Updated: values-zora-ai-configuration-server.yaml
  âœ“ Updated: values-zora-ai-customer-data-server.yaml
  âœ“ Updated: values-zora-ai-engine.yaml
  âœ“ Updated: values-zora-ai-postgres.yaml
  âœ“ Updated: values-zora-ai-postgres-init-db.yaml
  âœ“ Updated: values-zora-ai-redis.yaml
  âœ“ Updated: values-zora-ai-rbac-backend.yaml
  âœ“ Updated: values-zora-ai-rbac-backend-ui.yaml
  âœ“ Updated: values-zora-ai-rbac-frontend.yaml
  âœ“ Updated: values-zora-agent-skills.yaml


============================================================
Updating DNS domain to: XXXXXXXXXXXXXXXX
============================================================

  - No change: values-zora-ai-backend.yaml
  - No change: values-zora-ai-frontend.yaml
  - No change: values-zora-ai-configuration-server.yaml
  - No change: values-zora-ai-customer-data-server.yaml
  - No change: values-zora-ai-engine.yaml
  - No change: values-zora-ai-postgres.yaml
  - No change: values-zora-ai-postgres-init-db.yaml
  - No change: values-zora-ai-redis.yaml
  - No change: values-zora-ai-rbac-backend.yaml
  - No change: values-zora-ai-rbac-backend-ui.yaml
  - No change: values-zora-ai-rbac-frontend.yaml
  - No change: values-zora-agent-skills.yaml


============================================================
Updating gateway settings: ingress.enabled=false, httpRoute.enabled=true
============================================================

  âœ“ Updated: values-zora-ai-backend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-frontend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-configuration-server.yaml (2 changes)
  âœ“ Updated: values-zora-ai-customer-data-server.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-backend.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-backend-ui.yaml (2 changes)
  âœ“ Updated: values-zora-ai-rbac-frontend.yaml (2 changes)


============================================================
Updating RBAC API Proxy ingress configuration
============================================================

  Using HTTPRoute (Gateway API)
  âœ“ Updated: rbac-api-proxy/ingress.yaml


============================================================
Ensuring namespace <your-namespace> exists...
============================================================

$ kubectl create namespace <your-namespace> --dry-run=client -o yaml | kubectl apply -f -
namespace/<your-namespace> configured

============================================================
Ensuring docker-registry secret jfrog-registry-secret exists...
============================================================

$ kubectl create secret docker-registry jfrog-registry-secret --namespace <your-namespace> --docker-server edge.engineeringplatforms.deloitte.com --docker-username <service-account>@deloitte.com --docker-password **** --docker-email your-email@example.com --dry-run=client -o yaml | kubectl apply -f -
secret/jfrog-registry-secret configured

============================================================
Applying Kubernetes secrets manifest...
============================================================

$ kubectl apply -n <your-namespace> -f zora-ai-k8s-secrets.yaml
secret/zora-ai-postgres-secrets configured
secret/zora-ai-redis configured
secret/zora-ai-engine-secrets configured
secret/zora-ai-rbac-secrets configured

============================================================
Configuring Helm repository...
============================================================

$ helm repo add aiq-charts https://edge.engineeringplatforms.deloitte.com/artifactory/zora-ind-helm-release --force-update --pass-credentials --username <service-account>@deloitte.com --password ****
"aiq-charts" has been added to your repositories
$ helm repo update aiq-charts
Hang tight while we grab the latest from your chart repositories...
...Successfully got an update from the "aiq-charts" chart repository
Update Complete. âŽˆHappy Helming!âŽˆ
$ helm search repo aiq-charts
NAME                                CHART VERSION  APP VERSION  DESCRIPTION
aiq-charts/zora-ai-comserv-rbac-app <CHART_VERSION>   1.0.0        Common Services RBAC
aiq-charts/zora-ai-comserv-rbac-ui  <CHART_VERSION>   1.0.0        Common Services RBAC
aiq-charts/zora-ai-jobs             <CHART_VERSION>   1.0.0        Run any script as a Kubernetes Job (inline scri...
aiq-charts/zora-ai-postgres         <CHART_VERSION>   1.0.0        The World's Most Advanced Open Source Relationa...
aiq-charts/zora-ai-redis            <CHART_VERSION>   1.0.0        An open source, in-memory data structure store ...
aiq-charts/zora-ai-universal-chart  <CHART_VERSION>   1.0.0        A universal Helm chart for deploying Zora AI ap...
âœ“ Helm repository configured successfully

============================================================
Deploying charts in stages...
============================================================

============================================================
Stage 1: zora-ai-postgres
============================================================

--- Deploying zora-ai-postgres ---
$ helm upgrade --install zora-ai-postgres aiq-charts/zora-ai-postgres --version <CHART_VERSION> --namespace <your-namespace> --values values-zora-ai-postgres.yaml --create-namespace --pass-credentials
Release "zora-ai-postgres" has been upgraded. Happy Helming!
NAME: zora-ai-postgres
LAST DEPLOYED: Thu Mar 26 08:19:46 2026
NAMESPACE: <your-namespace>
STATUS: deployed
REVISION: 1
âœ“ zora-ai-postgres deployed

Waiting 180 seconds before next stage...

============================================================
Stage 2: zora-ai-postgres-init-db
============================================================

--- Deploying zora-ai-postgres-init-db ---
$ helm upgrade --install zora-ai-postgres-init-db aiq-charts/zora-ai-jobs --version <CHART_VERSION> --namespace <your-namespace> --values values-zora-ai-postgres-init-db.yaml --create-namespace --pass-credentials
Release "zora-ai-postgres-init-db" has been upgraded. Happy Helming!
NAME: zora-ai-postgres-init-db
LAST DEPLOYED: Thu Mar 26 08:23:12 2026
NAMESPACE: <your-namespace>
STATUS: deployed
REVISION: 1
âœ“ zora-ai-postgres-init-db deployed

Waiting 120 seconds before next stage...

============================================================
Stage 3: zora-agent-skills
============================================================

--- Deploying zora-agent-skills ---
$ helm upgrade --install zora-agent-skills aiq-charts/zora-ai-jobs --version <CHART_VERSION> --namespace <your-namespace> --values values-zora-agent-skills.yaml --create-namespace --pass-credentials
Release "zora-agent-skills" does not exist. Installing it now.
NAME: zora-agent-skills
LAST DEPLOYED: Thu Mar 26 08:25:25 2026
NAMESPACE: <your-namespace>
STATUS: deployed
REVISION: 1
âœ“ zora-agent-skills deployed

Waiting 120 seconds before next stage...

============================================================
Stage 4: zora-ai-configuration-server, zora-ai-customer-data-server, zora-ai-redis
============================================================

--- Deploying zora-ai-configuration-server ---
âœ“ zora-ai-configuration-server deployed

--- Deploying zora-ai-customer-data-server ---
âœ“ zora-ai-customer-data-server deployed

--- Deploying zora-ai-redis ---
âœ“ zora-ai-redis deployed

Waiting 120 seconds before next stage...

============================================================
Stage 5: zora-ai-rbac-backend-ui
============================================================

âœ“ zora-ai-rbac-backend-ui deployed

Waiting 120 seconds before next stage...

============================================================
Stage 6: zora-ai-rbac-backend
============================================================

âœ“ zora-ai-rbac-backend deployed

Waiting 120 seconds before next stage...

============================================================
Stage 7: zora-ai-backend, zora-ai-engine, zora-ai-frontend
============================================================

âœ“ zora-ai-backend deployed
âœ“ zora-ai-engine deployed
âœ“ zora-ai-frontend deployed

============================================================
Stage 8: zora-ai-rbac-frontend
============================================================

âœ“ zora-ai-rbac-frontend deployed

============================================================
Deployment Summary
============================================================
Successful: 12
  - zora-ai-postgres
  - zora-ai-postgres-init-db
  - zora-agent-skills
  - zora-ai-configuration-server
  - zora-ai-customer-data-server
  - zora-ai-redis
  - zora-ai-rbac-backend-ui
  - zora-ai-rbac-backend
  - zora-ai-backend
  - zora-ai-engine
  - zora-ai-frontend
  - zora-ai-rbac-frontend
Failed: 0

============================================================
SUCCESS - Deployment complete
============================================================

============================================================
Stage 9: Uninstall and reinstall zora-ai-postgres-init-db
============================================================

Uninstalling zora-ai-postgres-init-db...
$ helm uninstall zora-ai-postgres-init-db --namespace <your-namespace>
release "zora-ai-postgres-init-db" uninstalled

Waiting 120 seconds before reinstalling...

Reinstalling zora-ai-postgres-init-db...
NAME: zora-ai-postgres-init-db
LAST DEPLOYED: Thu Mar 26 08:38:19 2026
NAMESPACE: <your-namespace>
STATUS: deployed
REVISION: 1
âœ“ zora-ai-postgres-init-db reinstalled successfully

Waiting 120 seconds...

============================================================
Stage 9 complete
============================================================

============================================================
DEPLOYMENT STATUS
============================================================

--- Pods ---
$ kubectl get pods -n <your-namespace>
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-rbac-app-<hash>                         1/1     Running     0          6d21h
zora-ai-rbac-app-ui-<hash>                      1/1     Running     0          6d21h
zora-ai-backend-<hash>                          1/1     Running     0          5m8s
zora-ai-configuration-server-<hash>             1/1     Running     0          6d21h
zora-ai-customer-data-server-<hash>             1/1     Running     0          6d21h
zora-ai-engine-<hash>                           1/1     Running     0          6d21h
zora-ai-frontend-<hash>                         1/1     Running     0          6d21h
zora-ai-postgres-0                              2/2     Running     0          6d21h
zora-ai-postgres-jobs-<hash>                    0/1     Completed   0          2m3s
zora-ai-rbac-ui-<hash>                          1/1     Running     0          6d22h
zora-ai-redis-0                                 2/2     Running     0          6d21h
zora-ai-redis-1                                 2/2     Running     0          6d21h

--- Services ---
$ kubectl get svc -n <your-namespace>
NAME                           TYPE           CLUSTER-IP     EXTERNAL-IP     PORT(S)          AGE
zora-ai-rbac-app               ClusterIP      10.x.x.x       <none>          80/TCP           15d
zora-ai-rbac-app-ui            ClusterIP      10.x.x.x       <none>          80/TCP           15d
zora-ai-backend                ClusterIP      10.x.x.x       <none>          8000/TCP         10d
zora-ai-configuration-server   ClusterIP      10.x.x.x       <none>          8080/TCP         10d
zora-ai-customer-data-server   ClusterIP      10.x.x.x       <none>          8000/TCP         10d
zora-ai-engine                 ClusterIP      10.x.x.x       <none>          8000/TCP         10d
zora-ai-frontend               ClusterIP      10.x.x.x       <none>          80/TCP           14d
zora-ai-postgres               LoadBalancer   10.x.x.x       <external-ip>   5432:30433/TCP   13d
zora-ai-redis                  LoadBalancer   10.x.x.x       <external-ip>   6379:30976/TCP   13d

--- Ingresses ---
$ kubectl get ing -n <your-namespace>
NAME                                   CLASS            HOSTS                                              ADDRESS          PORTS     AGE
zora-ai-rbac-app-ui                    nginx-internal   zora-ai-rbac-api-ui.<your-dns-domain>              <external-ip>    80, 443   15d
zora-ai-backend-ingress                nginx-internal   zora-ai-backend.<your-dns-domain>                  <external-ip>    80, 443   10d
zora-ai-configuration-server-ingress   nginx-internal   zora-ai-configuration-server.<your-dns-domain>     <external-ip>    80, 443   10d
zora-ai-customer-data-server-ingress   nginx-internal   zora-ai-customer-data-server.<your-dns-domain>     <external-ip>    80, 443   10d
zora-ai-frontend-ingress               nginx-internal   zora-ai.<your-dns-domain>                          <external-ip>    80, 443   14d
zora-ai-rbac-api-proxy                 nginx-internal   zora-ai-rbac.<your-dns-domain>                     <external-ip>    80, 443   15d
zora-ai-rbac-ui                        nginx-internal   zora-ai-rbac.<your-dns-domain>                     <external-ip>    80, 443   15d
```

**5.5** Validate deployment status:

After the complete end-to-end deployment finishes, verify all resources are running properly:

**Check all pods are running:**
```bash
kubectl get pods -n <your-namespace>
```

All pods should show **"Running"** status (except the init job which shows **"Completed"**).

**Check all services are created:**
```bash
kubectl get services -n <your-namespace>
```

You should see services for postgres, redis, backend, frontend, engine, configuration-server, customer-data-server, and RBAC services.

**Check all Helm releases:**
```bash
helm list -n <your-namespace>
```

All 12 releases should show **"deployed"** status.

**If any pods are not running:**
- Check pod logs: `kubectl logs <pod-name> -n <your-namespace>`
- Check pod details: `kubectl describe pod <pod-name> -n <your-namespace>`
- Review the Troubleshooting section at the end of this guide

---

## STEP 6: Verify Deployment

### What This Step Does
Verifies that all components are deployed successfully and running properly.

### Instructions

**6.1** Check all pods are running:

```bash
kubectl get pods -n <your-namespace>
```

All pods should show **"Running"** status and **"1/1"** or **"2/2"** ready.

### Expected Output

```text
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-rbac-app-<hash>                         1/1     Running     0          6d21h
zora-ai-rbac-app-ui-<hash>                      1/1     Running     0          6d21h
zora-ai-backend-<hash>                          1/1     Running     0          5m8s
zora-ai-configuration-server-<hash>             1/1     Running     0          6d21h
zora-ai-customer-data-server-<hash>             1/1     Running     0          6d21h
zora-ai-engine-<hash>                           1/1     Running     0          6d21h
zora-ai-frontend-<hash>                         1/1     Running     0          6d21h
zora-ai-postgres-0                              2/2     Running     0          6d21h
zora-ai-postgres-jobs-<hash>                    0/1     Completed   0          2m3s
zora-ai-rbac-ui-<hash>                          1/1     Running     0          6d22h
zora-ai-redis-0                                 2/2     Running     0          6d21h
zora-ai-redis-1                                 2/2     Running     0          6d21h
```

**Note:** The `zora-ai-postgres-jobs` pod will show **"Completed"** status - this is expected as it's a job that ran to initialize the database.

**6.2** Check all services:

```bash
kubectl get services -n <your-namespace>
```

**6.3** Check Helm releases:

```bash
helm list -n <your-namespace>
```

You should see all 11 releases with status **"deployed"**.

**6.4** View recent events (troubleshooting):

```bash
kubectl get events -n <your-namespace> --sort-by=.lastTimestamp | tail -n 20
```

---

## STEP 7: Manual Helm Upgrades (Optional)

### When to Use
Use these commands to upgrade individual services after the initial deployment.

### Set Environment Variables (run once)

```bash
export NAMESPACE="<your-namespace>"
export HELM_REPO_NAME="aiq-charts"
export CHART_VERSION="<CHART_VERSION>"  # Set to the chart version for your release
export VALUES_ROOT="."  # Current directory with values files
```

### Upgrade Individual Services

**Upgrade PostgreSQL:**
```bash
helm upgrade --install zora-ai-postgres \
  "${HELM_REPO_NAME}/zora-ai-postgres" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-postgres.yaml" \
  --wait
```

**Upgrade Redis:**
```bash
helm upgrade --install zora-ai-redis \
  "${HELM_REPO_NAME}/zora-ai-redis" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-redis.yaml" \
  --wait
```

**Upgrade PostgreSQL Init Job:**
```bash
helm upgrade --install zora-ai-postgres-init-db \
  "${HELM_REPO_NAME}/zora-ai-jobs" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-postgres-init-db.yaml" \
  --wait
```

**Upgrade Agent Skills Job:**
```bash
helm upgrade --install zora-agent-skills \
  "${HELM_REPO_NAME}/zora-ai-jobs" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-agent-skills.yaml" \
  --wait
```

**Upgrade Backend Service:**
```bash
helm upgrade --install zora-ai-backend \
  "${HELM_REPO_NAME}/zora-ai-universal-chart" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-backend.yaml" \
  --wait
```

**Upgrade Engine Service:**
```bash
helm upgrade --install zora-ai-engine \
  "${HELM_REPO_NAME}/zora-ai-universal-chart" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-engine.yaml" \
  --wait
```

**Upgrade Frontend:**
```bash
helm upgrade --install zora-ai-frontend \
  "${HELM_REPO_NAME}/zora-ai-universal-chart" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-frontend.yaml" \
  --wait
```

**Upgrade Configuration Server:**
```bash
helm upgrade --install zora-ai-configuration-server \
  "${HELM_REPO_NAME}/zora-ai-universal-chart" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-configuration-server.yaml" \
  --wait
```

**Upgrade Customer Data Server:**
```bash
helm upgrade --install zora-ai-customer-data-server \
  "${HELM_REPO_NAME}/zora-ai-universal-chart" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-customer-data-server.yaml" \
  --wait
```

**Upgrade RBAC Services:**
```bash
# RBAC Backend UI
helm upgrade --install zora-ai-rbac-backend-ui \
  "${HELM_REPO_NAME}/zora-ai-comserv-rbac-app" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-rbac-backend-ui.yaml" \
  --wait

# RBAC Backend
helm upgrade --install zora-ai-rbac-backend \
  "${HELM_REPO_NAME}/zora-ai-comserv-rbac-app" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-rbac-backend.yaml" \
  --wait

# RBAC Frontend
helm upgrade --install zora-ai-rbac-frontend \
  "${HELM_REPO_NAME}/zora-ai-comserv-rbac-ui" \
  --version "${CHART_VERSION}" \
  --namespace "${NAMESPACE}" \
  --values "${VALUES_ROOT}/values-zora-ai-rbac-frontend.yaml" \
  --wait
```

---

## STEP 8: Uninstall Services (Cleanup)

### When to Use
Use these commands to remove services you don't need or to perform a complete cleanup.

### Set Environment Variable

```bash
export NAMESPACE="<your-namespace>"
```

### Uninstall Individual Services

**Remove specific service (example - Frontend):**
```bash
helm uninstall zora-ai-frontend -n "${NAMESPACE}"
```

### Uninstall (Cleanup)

```bash
# RBAC Services
helm uninstall zora-ai-rbac-frontend -n "${NAMESPACE}"
helm uninstall zora-ai-rbac-backend -n "${NAMESPACE}"
helm uninstall zora-ai-rbac-backend-ui -n "${NAMESPACE}"

# Core Application Services
helm uninstall zora-ai-frontend -n "${NAMESPACE}"
helm uninstall zora-ai-engine -n "${NAMESPACE}"
helm uninstall zora-ai-backend -n "${NAMESPACE}"
helm uninstall zora-agent-skills -n "${NAMESPACE}"
helm uninstall zora-ai-customer-data-server -n "${NAMESPACE}"
helm uninstall zora-ai-configuration-server -n "${NAMESPACE}"
helm uninstall zora-ai-postgres-init-db -n "${NAMESPACE}"

# Data Stores (CAUTION: This deletes all data)
helm uninstall zora-ai-redis -n "${NAMESPACE}"
helm uninstall zora-ai-postgres -n "${NAMESPACE}"
```

### Delete Namespace (Complete Cleanup)

**WARNING:** This deletes everything in the namespace including secrets, configmaps, and persistent data.

```bash
kubectl delete namespace "${NAMESPACE}"
```

### Verify Cleanup

```bash
# Check no Helm releases remain
helm list -n "${NAMESPACE}"

# Check no pods remain
kubectl get pods -n "${NAMESPACE}"

# Check namespace is deleted (should show "not found")
kubectl get namespace "${NAMESPACE}"
```

---

## Troubleshooting

### Issue: Script fails to download artifact
**Solution:**
- Verify `EDGE_TOKEN` is correct and not expired
- Check internet connectivity
- Ensure artifact archive exists in JFrog at the configured path

### Issue: Helm deployment fails
**Solution:**
- Check Helm repository is added: `helm repo list`
- Update Helm repo: `helm repo update`
- Verify values files are correctly updated
- Check namespace exists: `kubectl get namespace "${NAMESPACE}"`

### Issue: Pods not starting
**Solution:**
- Check pod logs: `kubectl logs <pod-name> -n "${NAMESPACE}"`
- Check events: `kubectl describe pod <pod-name> -n "${NAMESPACE}"`
- Verify secrets exist: `kubectl get secrets -n "${NAMESPACE}"`
- Check image pull secrets are configured

### Issue: Cannot access application via ingress/DNS
**Solution:**
- Verify Ingress Controller is running in your cluster
- Check Ingress resources are created: `kubectl get ingress -n "${NAMESPACE}"`
- Verify DNS resolution: `nslookup <your-hostname>` or `dig <your-hostname>`
- Ensure DNS records point to Ingress Controller's external IP
- Check ingress configuration in values files matches your domain
- Verify firewall rules allow traffic to Ingress Controller
- Contact your Kubernetes admin to troubleshoot Ingress Controller issues

### Issue: RBAC authentication fails
**Solution:**
- Verify OIDC_CLIENTSECRET is correctly set in `zora-ai-k8s-secrets.yaml`
- Check all redirect URIs are configured in your app registration (see Prerequisites section)
- Ensure redirect URIs exactly match your ingress hostnames
- Verify OIDC endpoints are accessible from the cluster
- Check RBAC pod logs: `kubectl logs <rbac-pod-name> -n "${NAMESPACE}"`
- Confirm client ID and authority/issuer URLs are correct

### Getting Help
Contact your administrator with:
- Step number where the issue occurred
- Complete error message
- Output of: `kubectl get pods -n "${NAMESPACE}"`
- Output of: `helm list -n "${NAMESPACE}"`

---

## Quick Reference

### Important Files
- `download_and_extract_values.py` - Downloads deployment files
- `cfo_end-to-end_deployment.py` - Automated deployment
- `zora-ai-k8s-secrets.yaml` - Kubernetes secrets
- `values-zora-agent-skills.yaml` - Agent skills job configuration
- `values-*.yaml` - Service configuration files

### Important Commands
- **Check pods:** `kubectl get pods -n "${NAMESPACE}"`
- **Check services:** `kubectl get svc -n "${NAMESPACE}"`
- **Check Helm releases:** `helm list -n "${NAMESPACE}"`
- **View logs:** `kubectl logs <pod-name> -n "${NAMESPACE}"`
- **Restart pod:** `kubectl delete pod <pod-name> -n "${NAMESPACE}"`

### Configuration Details
- **Namespace:** Set in `NAMESPACE` variable of `cfo_end-to-end_deployment.py`
- **Helm Repo:** `aiq-charts`
- **JFrog Registry:** `edge.engineeringplatforms.deloitte.com`
- **Helm Chart Version:** Set in `CHART_VERSION` variable of `cfo_end-to-end_deployment.py`

---

## Deployment Summary

âœ… **Step 1:** Download and extract files  
âœ… **Step 2:** Update configuration files  
âœ… **Step 3:** (Optional) Setup Azure Disk StorageClass  
âœ… **Step 4:** Deploy application (automated end-to-end)
   - Deploys all 12 services in staged order
   - Runs agent skills initialization job (`zora-agent-skills`)
   - Reinstalls postgres-init-db for clean database initialization
   - Creates fresh databases (`zora_app`, `rbac_db`, and other required databases)

âœ… **Step 5:** Verify deployment  
âœ… **Step 6:** Manual upgrades (optional)  
âœ… **Step 7:** Uninstall services (cleanup)  

**Your CFO Application is now deployed and ready to use!**

**Note:** If you need to restore data from database backups, you must perform the restoration manually after deployment.
