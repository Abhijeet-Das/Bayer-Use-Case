# PCAI Infrastructure Specification

This specification describes the minimum requirements to deploy Zora to a PCAI virtual machine. PCAI VMs are deployed to on-premise hardware, and are managed through HPE Greenlake VMWare/Kubernetes tooling.

## Minimum Hardware Reqiurements

| Component | Description |
|---|---|
| AI Worker Nodes | 2x DL380a Gen 11 AI optimized node |
| GPUs | 2 x H100 NVL (one node) *minimum* |
| Control Plane | 3x DL325 Gen 11 nodes |
| Network Switches | Client dependent |
| Storage | Client dependent | 

## AI Model Hosting

!!! note
    This deployment configuration isn't validated with OpenAI `GPT-OSS-120b`.

| Component | Description |
|---|---|
| Machine Family | Accelerator-optimized (A3 High) |
| Instance Type | a3-highgpu-8g (Google Compute Engine) |
| GPU | 8 x NVIDIA H100 80GB GPUs (nvidia-h100-80gb) |
| vCPUs | 208 |
| Memory | 1872 GiB |
| Storage | <ul><li>**Local SSD**: Up to 16 local SSDs (NVMe) as provided by the a3-highgpu-8g machine type for high-throughput scratch storage.</li><li>**Persistent Disk**: 1 x 1024 GiB Persistent Disk SSD (pd-ssd) for model weights, configuration, and logs.</li><ul> |
| Number of Instances | 1 (for pilot environment) |
| Key 3rd Party Software | NVIDIA NVAIE / NIM software stack for H100-optimized model serving. |