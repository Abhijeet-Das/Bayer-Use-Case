# AWS Infrastructure Specification

This specification describes the minimum requirements to deploy Zora to an Amazon Web Services (AWS) virtual machine.

## Primary Node Pool

**Zora Agent and Zora Platform**

| Component | Description |
|---|---|
| Machine Family | |
| Instance Type | |
| vCPUs | |
| Memory | |
| Storage | <ul><li>**Data Disk**: </li><li>**OS Disk**:  </li><ul> |
| Processor |  |
| Node Pool Image Version |  |
| Operating System |  |
| Kubernetes |  |
| Number of Instances |  |
| Key 3rd Party Software | |

## AI Model Hosting

When deploying OpenAI `GPT-OSS-120b` on AWS, model can either be self-hosted on a dedicated GPU instance (with NIM container).