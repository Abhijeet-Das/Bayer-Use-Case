# GCP Infrastructure Specification

This specification describes the minimum requirements to deploy Zora to a GCP (Google Compute Engine) virtual machine.

## Primary Node Pool

*Zora Agent and Zora Platform*

| Component | Description |
|---|---|
| Machine Family | General-purpose (N2 series)|
| Instance Type | n2-standard-64 (Google Compute Engine) |
| vCPUs | 64 |
| Memory | 256 GiB |
| Storage | <ul><li>*Data Disk*: 1 x 1024 GiB Persistent Disk SSD (pd-ssd) for Zora data and application workloads.</li><li>*OS Disk*: Up to 1024 GiB Persistent Disk (pd-balanced or pd-ssd) for the operating system and base tooling. </li><ul> |
| Processor | Intel-based N2 platform (for example, Intel Cascade Lake / Ice Lake underlying CPUs) |
| Node Pool Image Version | GKE Ubuntu 22.04 LTS (container-based node image) |
| Operating System | Ubuntu Linux 22.04 LTS |
| Kubernetes | Google Kubernetes Engine (GKE) cluster orchestrating Zora platform and agent workloads |
| Number of Instances | 1 (for demo environment) |
| Key 3rd Party Software | Kubernetes container service (GKE), plus Zora Platform components |

## AI Model Hosting

When deploying OpenAI `GPT-OSS-120b` on GCP, model can be hosted on Vertex AI, or on a dedicated GPU instance (with NIM container).