# Azure Infrastructure Specification

This specification describes the minimum requirements to deploy Zora to an Azure virtual machine.

## Primary Node Pool

**Zora Agent and Zora Platform**

| Component | Description |
|---|---|
| Machine Family | General-purpose (D series)|
| Instance Type | Standard_D64as_v6 |
| vCPUs | 64 |
| Memory | 256 GiB |
| Storage | <ul><li>**Data Disk**: 1 x 1024 GiB Persistent Disk SSD (premium ssd) for Zora data and application workloads.</li><li>**OS Disk**: Up to 1024 GiB Persistent Disk (premium ssd) for the operating system and base tooling. </li><ul> |
| Processor | AMD EPYC 9004 (Genoa) [x86-64] |
| Node Pool Image Version | AKSUbuntu-2204gen2containerd-202507.21.0 |
| Operating System | Ubuntu Linux 22.04 LTS |
| Kubernetes | Azure Kubernetes Service (AKS) cluster orchestrating Zora platform and agent workloads |
| Number of Instances | 1 (for demo environment) |
| Key 3rd Party Software | Azure Kubernetes Service (AKS), plus Zora Platform components |

## AI Model Hosting

When deploying OpenAI `GPT-OSS-120b` on Azure, model can either be self-hosted on a dedicated GPU instance (with NIM container), or hosted on Microsoft Foundry (formerly Azure AI Studio).