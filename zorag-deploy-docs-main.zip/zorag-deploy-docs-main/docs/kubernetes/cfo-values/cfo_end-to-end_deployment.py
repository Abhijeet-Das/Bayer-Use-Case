#!/usr/bin/env python3
"""Script to configure Helm repo and deploy all requested charts."""

import os
import subprocess
import sys
import time

JFROG_REGISTRY = "edge.engineeringplatforms.deloitte.com"
HELM_REPO_PATH = "zora-ind-helm-release"
HELM_REPO_NAME = "aiq-charts"

EDGE_USER = "XXXXXXXXXXXX"  # Use jfrog service account username.
EDGE_TOKEN = "XXXXXXXXXXX"  # Use jfrog service account token.

NAMESPACE = "<your-namespace>"  # Change to your target namespace (e.g., "zora-ai-prod")
SECRETS_FILE = "zora-ai-k8s-secrets.yaml"
CHART_VERSION = "<CHART_VERSION>" # Update to the chart version matching your release
DOCKER_SECRET_NAME = "jfrog-registry-secret"
DOCKER_EMAIL = "your-email@example.com"

# =============================================================================
# CLIENT/REGION CONFIGURATION
# =============================================================================
# Change this based on your client/region
# =============================================================================
CLIENT_REGION = "xxxxxxxxxxxxxxxxx" # Update this to match your client/region's Docker registry path
CLIENT_DNS = "xxxxxxxxxxxxxxxxxxxx"  # Update this to match your client's DNS domain (e.g., "client.zoraai.eng.deloitte.com")

# Gateway configuration: Set based on client's ingress preference
# If using Ingress Gateway: INGRESS_ENABLED = "true", HTTP_ROUTE_ENABLED = "false"
# If using App Gateway (httpRoute): INGRESS_ENABLED = "false", HTTP_ROUTE_ENABLED = "true"
INGRESS_ENABLED = "false"
HTTP_ROUTE_ENABLED = "true"

# Staged deployment: list of (charts, wait_seconds_after)
DEPLOYMENT_STAGES = [
    # Stage 1: PostgreSQL
    {
        "charts": [
            ("zora-ai-postgres", "zora-ai-postgres", "values-zora-ai-postgres.yaml"),
        ],
        "wait": 180,
    },
    # Stage 2: Init DB
    {
        "charts": [
            ("zora-ai-postgres-init-db", "zora-ai-jobs", "values-zora-ai-postgres-init-db.yaml"),
        ],
        "wait": 120,
    },
    # Stage 3: Agent Skills
    {
        "charts": [
            ("zora-agent-skills", "zora-ai-jobs", "values-zora-agent-skills.yaml"),
        ],
        "wait": 120,
    },
    # Stage 4: Configuration server, customer data server, Redis
    {
        "charts": [
            ("zora-ai-configuration-server", "zora-ai-universal-chart", "values-zora-ai-configuration-server.yaml"),
            ("zora-ai-customer-data-server", "zora-ai-universal-chart", "values-zora-ai-customer-data-server.yaml"),
            ("zora-ai-redis", "zora-ai-redis", "values-zora-ai-redis.yaml"),
        ],
        "wait": 120,
    },
    # Stage 5: RBAC backend UI
    {
        "charts": [
            ("zora-ai-rbac-backend-ui", "zora-ai-comserv-rbac-app", "values-zora-ai-rbac-backend-ui.yaml"),
        ],
        "wait": 120,
    },
    # Stage 6: RBAC backend
    {
        "charts": [
            ("zora-ai-rbac-backend", "zora-ai-comserv-rbac-app", "values-zora-ai-rbac-backend.yaml"),
        ],
        "wait": 120,
    },
    # Stage 7: Backend, engine, frontend
    {
        "charts": [
            ("zora-ai-backend", "zora-ai-universal-chart", "values-zora-ai-backend.yaml"),
            ("zora-ai-engine", "zora-ai-universal-chart", "values-zora-ai-engine.yaml"),
            ("zora-ai-frontend", "zora-ai-universal-chart", "values-zora-ai-frontend.yaml"),
        ],
        "wait": 0,
    },
    # Stage 8: RBAC frontend
    {
        "charts": [
            ("zora-ai-rbac-frontend", "zora-ai-comserv-rbac-ui", "values-zora-ai-rbac-frontend.yaml"),
        ],
        "wait": 0,
    },
]


def update_registry_paths_in_values():
    """Update Docker registry paths in all values files based on CLIENT_REGION."""
    import re
    
    # Pattern to match any zora-xxx-docker-release-local
    pattern = r"zora-[a-zA-Z0-9_-]+-docker-release-local"
    
    # Validate CLIENT_REGION matches the expected format
    if not re.match(pattern, CLIENT_REGION):
        print(f"ERROR: CLIENT_REGION '{CLIENT_REGION}' does not match expected format 'zora-xxx-docker-release-local'")
        return False
    
    target_path = CLIENT_REGION
    
    print(f"\n{'=' * 60}")
    print(f"Updating registry paths to: {target_path}")
    print(f"{'=' * 60}\n")
    
    values_files = [
        "values-zora-ai-backend.yaml",
        "values-zora-ai-frontend.yaml",
        "values-zora-ai-configuration-server.yaml",
        "values-zora-ai-customer-data-server.yaml",
        "values-zora-ai-engine.yaml",
        "values-zora-ai-postgres.yaml",
        "values-zora-ai-postgres-init-db.yaml",
        "values-zora-ai-redis.yaml",
        "values-zora-ai-rbac-backend.yaml",
        "values-zora-ai-rbac-backend-ui.yaml",
        "values-zora-ai-rbac-frontend.yaml",
        "values-zora-agent-skills.yaml",
    ]
    
    for vf in values_files:
        if not os.path.exists(vf):
            print(f"  ⚠ Skipped (not found): {vf}")
            continue
        
        with open(vf, "r") as f:
            content = f.read()
        
        # Replace any zora-xxx-docker-release-local with target_path
        updated, count = re.subn(pattern, target_path, content)
        changed = count > 0
        
        if changed:
            with open(vf, "w") as f:
                f.write(updated)
            print(f"  ✓ Updated: {vf}")
        else:
            print(f"  - No change: {vf}")
    
    print()
    return True


def update_dns_in_values():
    """Update DNS domain in all values files based on CLIENT_DNS."""
    import re
    
    # Pattern to match DNS domains preserving ALL prefixes before the base DNS
    # Examples: rbac-api.demo.zoraai.eng.deloitte.com -> rbac-api.{CLIENT_DNS}
    #           zora-ai.demo.zoraai.eng.deloitte.com -> zora-ai.{CLIENT_DNS}
    pattern = r"((?:[a-zA-Z0-9_-]+\.)*)demo\.zoraai\.eng\.deloitte\.com"
    
    print(f"\n{'=' * 60}")
    print(f"Updating DNS domain to: {CLIENT_DNS}")
    print(f"{'=' * 60}\n")
    
    values_files = [
        "values-zora-ai-backend.yaml",
        "values-zora-ai-frontend.yaml",
        "values-zora-ai-configuration-server.yaml",
        "values-zora-ai-customer-data-server.yaml",
        "values-zora-ai-engine.yaml",
        "values-zora-ai-postgres.yaml",
        "values-zora-ai-postgres-init-db.yaml",
        "values-zora-ai-redis.yaml",
        "values-zora-ai-rbac-backend.yaml",
        "values-zora-ai-rbac-backend-ui.yaml",
        "values-zora-ai-rbac-frontend.yaml",
        "values-zora-agent-skills.yaml",
    ]
    
    for vf in values_files:
        if not os.path.exists(vf):
            print(f"  ⚠ Skipped (not found): {vf}")
            continue
        
        with open(vf, "r") as f:
            content = f.read()
        
        # Replace only the base DNS domain, keeping all prefix subdomains intact
        def replace_dns(match):
            prefix = match.group(1)  # All prefixes like "cfo-rbac.zora-ai."
            return f"{prefix}{CLIENT_DNS}"
        
        updated, count = re.subn(pattern, replace_dns, content)
        changed = count > 0
        
        if changed:
            with open(vf, "w") as f:
                f.write(updated)
            print(f"  ✓ Updated: {vf} ({count} replacements)")
        else:
            print(f"  - No change: {vf}")
    
    print()
    return True


def update_gateway_settings_in_values():
    """Update ingress and httpRoute settings in values files based on INGRESS_ENABLED and HTTP_ROUTE_ENABLED."""
    import re
    
    print(f"\n{'=' * 60}")
    print(f"Updating gateway settings: ingress.enabled={INGRESS_ENABLED}, httpRoute.enabled={HTTP_ROUTE_ENABLED}")
    print(f"{'=' * 60}\n")
    
    # Only update these files (excluding postgres, redis, engine, agent-skills, postgres-init-db)
    values_files = [
        "values-zora-ai-backend.yaml",
        "values-zora-ai-frontend.yaml",
        "values-zora-ai-configuration-server.yaml",
        "values-zora-ai-customer-data-server.yaml",
        "values-zora-ai-rbac-backend.yaml",
        "values-zora-ai-rbac-backend-ui.yaml",
        "values-zora-ai-rbac-frontend.yaml",
    ]
    
    # Pattern to match ingress enabled setting (handles various indentation)
    ingress_pattern = r"(ingress:\s*\n\s+enabled:\s*)(true|false)"
    # Pattern to match httpRoute enabled setting
    httproute_pattern = r"(httpRoute:\s*\n\s+enabled:\s*)(true|false)"
    
    for vf in values_files:
        if not os.path.exists(vf):
            print(f"  ⚠ Skipped (not found): {vf}")
            continue
        
        with open(vf, "r") as f:
            content = f.read()
        
        changes = 0
        
        # Update ingress.enabled
        updated, count = re.subn(ingress_pattern, rf"\g<1>{INGRESS_ENABLED}", content)
        changes += count
        
        # Update httpRoute.enabled
        updated, count = re.subn(httproute_pattern, rf"\g<1>{HTTP_ROUTE_ENABLED}", updated)
        changes += count
        
        if changes > 0:
            with open(vf, "w") as f:
                f.write(updated)
            print(f"  ✓ Updated: {vf} ({changes} changes)")
        else:
            print(f"  - No change: {vf}")
    
    print()
    return True


def update_rbac_api_proxy_ingress():
    """Update rbac-api-proxy/ingress.yaml based on gateway preference and DNS settings."""
    import re
    
    ingress_file = "rbac-api-proxy/ingress.yaml"
    
    print(f"\n{'=' * 60}")
    print(f"Updating RBAC API Proxy ingress configuration")
    print(f"{'=' * 60}\n")
    
    if not os.path.exists(ingress_file):
        print(f"  ⚠ File not found: {ingress_file}")
        return True  # Not a critical error, continue deployment
    
    with open(ingress_file, "r") as f:
        content = f.read()
    
    # Update DNS in the file (both in HTTPRoute and Ingress sections)
    dns_pattern = r"((?:[a-zA-Z0-9_-]+\.)*)demo\.zoraai\.eng\.deloitte\.com"
    def replace_dns(match):
        prefix = match.group(1)
        return f"{prefix}{CLIENT_DNS}"
    content = re.sub(dns_pattern, replace_dns, content)
    
    lines = content.split('\n')
    
    # Find section boundaries
    httproute_content_start = None
    ingress_header_start = None
    ingress_content_start = None
    
    for i, line in enumerate(lines):
        if "# OPTION 1: Gateway API HTTPRoute" in line:
            httproute_content_start = i + 2  # Skip header and === line
        elif "# OPTION 2: Standard Kubernetes Ingress" in line:
            ingress_header_start = i
            ingress_content_start = i + 4  # Skip header, ===, description, ===
    
    if httproute_content_start is None or ingress_header_start is None:
        print(f"  ⚠ Could not find section markers in {ingress_file}")
        with open(ingress_file, "w") as f:
            f.write(content)
        print(f"  ✓ Updated DNS in: {ingress_file}")
        return True
    
    new_lines = []
    
    # Add header (before OPTION 1 content)
    for i in range(httproute_content_start):
        new_lines.append(lines[i])
    
    def uncomment_line(line):
        """Remove '# ' prefix from a line if present."""
        if line.startswith('# '):
            return line[2:]
        elif line == '#':
            return ''
        return line
    
    def comment_line(line):
        """Add '# ' prefix to a line if not already commented or empty."""
        if line.strip() == '' or line.startswith('#'):
            return line
        return '# ' + line
    
    if HTTP_ROUTE_ENABLED == "true":
        print(f"  Using HTTPRoute (Gateway API)")
        
        # HTTPRoute content - uncommented
        for i in range(httproute_content_start, ingress_header_start):
            new_lines.append(uncomment_line(lines[i]))
        
        # Ingress header lines
        for i in range(ingress_header_start, ingress_content_start):
            new_lines.append(lines[i])
        
        # Ingress content - commented
        for i in range(ingress_content_start, len(lines)):
            new_lines.append(comment_line(lines[i]))
    
    else:
        print(f"  Using Ingress (nginx)")
        
        # HTTPRoute content - commented
        for i in range(httproute_content_start, ingress_header_start):
            new_lines.append(comment_line(lines[i]))
        
        # Ingress header lines
        for i in range(ingress_header_start, ingress_content_start):
            new_lines.append(lines[i])
        
        # Ingress content - uncommented
        for i in range(ingress_content_start, len(lines)):
            new_lines.append(uncomment_line(lines[i]))
    
    # Write updated content
    with open(ingress_file, "w") as f:
        f.write('\n'.join(new_lines))
    
    print(f"  ✓ Updated: {ingress_file}")
    print()
    return True


def deploy_rbac_api_proxy_ingress():
    """Deploy the rbac-api-proxy ingress manifest."""
    ingress_file = "rbac-api-proxy/ingress.yaml"
    
    print(f"\n{'=' * 60}")
    print(f"Deploying RBAC API Proxy ingress")
    print(f"{'=' * 60}\n")
    
    if not os.path.exists(ingress_file):
        print(f"  ⚠ File not found: {ingress_file}, skipping")
        return True
    
    cmd = ["kubectl", "apply", "-n", NAMESPACE, "-f", ingress_file]
    if run_cmd(cmd):
        print(f"✓ RBAC API Proxy ingress deployed")
        return True
    else:
        print(f"✗ RBAC API Proxy ingress deployment failed")
        return False


def masked_command(cmd):
    masked = []
    skip_next = False
    for index, part in enumerate(cmd):
        if skip_next:
            skip_next = False
            continue
        if part == "--password" and index + 1 < len(cmd):
            masked.extend(["--password", "****"])
            skip_next = True
        else:
            masked.append(part)
    return " ".join(masked)


def run_cmd(cmd):
    print(f"$ {masked_command(cmd)}")
    result = subprocess.run(cmd, capture_output=True, text=True)
    if result.stdout:
        print(result.stdout.strip())
    if result.returncode != 0 and result.stderr:
        print(result.stderr.strip())
    return result.returncode == 0


def validate_credentials():
    if not EDGE_USER:
        print("ERROR: EDGE_USER is not set")
        return False
    if not EDGE_TOKEN:
        print("ERROR: EDGE_TOKEN is not set")
        return False
    return True


def setup_helm_repo():
    print(f"\n{'='*60}")
    print("Configuring Helm repository...")
    print(f"{'='*60}\n")

    repo_url = f"https://{JFROG_REGISTRY}/artifactory/{HELM_REPO_PATH}"

    commands = [
        [
            "helm",
            "repo",
            "add",
            HELM_REPO_NAME,
            repo_url,
            "--force-update",
            "--pass-credentials",
            "--username",
            EDGE_USER,
            "--password",
            EDGE_TOKEN,
        ],
        ["helm", "repo", "update", HELM_REPO_NAME],
        ["helm", "search", "repo", HELM_REPO_NAME],
    ]

    for cmd in commands:
        if not run_cmd(cmd):
            print("✗ Helm repo setup failed")
            return False

    print("✓ Helm repository configured successfully")
    return True


def create_namespace():
    print(f"\n{'='*60}")
    print(f"Ensuring namespace {NAMESPACE} exists...")
    print(f"{'='*60}\n")
    cmd = ["kubectl", "create", "namespace", NAMESPACE, "--dry-run=client", "-o", "yaml"]
    create_result = subprocess.run(cmd, capture_output=True, text=True)
    if create_result.returncode != 0:
        if create_result.stderr:
            print(create_result.stderr.strip())
        return False

    apply_cmd = ["kubectl", "apply", "-f", "-"]
    print(f"$ {' '.join(cmd)} | {' '.join(apply_cmd)}")
    apply_result = subprocess.run(apply_cmd, input=create_result.stdout, capture_output=True, text=True)
    if apply_result.stdout:
        print(apply_result.stdout.strip())
    if apply_result.returncode != 0:
        if apply_result.stderr:
            print(apply_result.stderr.strip())
        return False
    return True


def create_docker_registry_secret():
    print(f"\n{'='*60}")
    print(f"Ensuring docker-registry secret {DOCKER_SECRET_NAME} exists...")
    print(f"{'='*60}\n")

    cmd = [
        "kubectl",
        "create",
        "secret",
        "docker-registry",
        DOCKER_SECRET_NAME,
        "--namespace",
        NAMESPACE,
        "--docker-server",
        JFROG_REGISTRY,
        "--docker-username",
        EDGE_USER,
        "--docker-password",
        EDGE_TOKEN,
        "--docker-email",
        DOCKER_EMAIL,
        "--dry-run=client",
        "-o",
        "yaml",
    ]

    create_result = subprocess.run(cmd, capture_output=True, text=True)
    print(f"$ {masked_command(cmd)} | kubectl apply -f -")
    if create_result.returncode != 0:
        if create_result.stderr:
            print(create_result.stderr.strip())
        return False

    apply_cmd = ["kubectl", "apply", "-f", "-"]
    apply_result = subprocess.run(apply_cmd, input=create_result.stdout, capture_output=True, text=True)
    if apply_result.stdout:
        print(apply_result.stdout.strip())
    if apply_result.returncode != 0:
        if apply_result.stderr:
            print(apply_result.stderr.strip())
        return False
    return True


def apply_secrets_file():
    print(f"\n{'='*60}")
    print("Applying Kubernetes secrets manifest...")
    print(f"{'='*60}\n")

    if not os.path.exists(SECRETS_FILE):
        print(f"ERROR: Secrets file not found: {SECRETS_FILE}")
        return False

    cmd = ["kubectl", "apply", "-n", NAMESPACE, "-f", SECRETS_FILE]
    return run_cmd(cmd)


def deploy_chart(release, chart, values_file):
    """Deploy a single helm chart. Returns True on success."""
    if not os.path.exists(values_file):
        print(f"✗ Missing values file: {values_file}")
        return False

    chart_ref = f"{HELM_REPO_NAME}/{chart}"
    cmd = [
        "helm",
        "upgrade",
        "--install",
        release,
        chart_ref,
        "--version",
        CHART_VERSION,
        "--namespace",
        NAMESPACE,
        "--values",
        values_file,
        "--create-namespace",
        "--pass-credentials",
    ]

    print(f"\n--- Deploying {release} ---")
    if run_cmd(cmd):
        print(f"✓ {release} deployed")
        return True
    else:
        print(f"✗ {release} failed")
        return False


def deploy_all_charts():
    """Deploy charts in stages with waits between them."""
    print(f"\n{'='*60}")
    print("Deploying charts in stages...")
    print(f"{'='*60}")

    successes = []
    failures = []

    for stage_num, stage in enumerate(DEPLOYMENT_STAGES, 1):
        charts = stage["charts"]
        wait_secs = stage["wait"]
        chart_names = [c[0] for c in charts]

        print(f"\n{'='*60}")
        print(f"Stage {stage_num}: {', '.join(chart_names)}")
        print(f"{'='*60}")

        for release, chart, values_file in charts:
            if deploy_chart(release, chart, values_file):
                successes.append(release)
            else:
                failures.append((release, "helm upgrade/install failed"))

        if wait_secs > 0:
            print(f"\nWaiting {wait_secs} seconds before next stage...")
            time.sleep(wait_secs)

    print(f"\n{'='*60}")
    print("Deployment Summary")
    print(f"{'='*60}")
    print(f"Successful: {len(successes)}")
    for release in successes:
        print(f"  - {release}")

    print(f"Failed: {len(failures)}")
    for release, reason in failures:
        print(f"  - {release}: {reason}")

    return len(failures) == 0


def reinstall_postgres_init_db():
    """Stage 9: Uninstall and reinstall zora-ai-postgres-init-db."""
    release = "zora-ai-postgres-init-db"
    chart = "zora-ai-jobs"
    values_file = "values-zora-ai-postgres-init-db.yaml"

    print(f"\n{'='*60}")
    print(f"Stage 9: Uninstall and reinstall {release}")
    print(f"{'='*60}")

    # Uninstall
    print(f"\nUninstalling {release}...")
    cmd = ["helm", "uninstall", release, "--namespace", NAMESPACE]
    run_cmd(cmd)

    # Wait 120 seconds
    print(f"\nWaiting 120 seconds before reinstalling...")
    time.sleep(120)

    # Reinstall
    print(f"\nReinstalling {release}...")
    if deploy_chart(release, chart, values_file):
        print(f"\u2713 {release} reinstalled successfully")
    else:
        print(f"\u2717 {release} reinstall failed")

    # Wait 120 seconds after reinstall
    print(f"\nWaiting 120 seconds...")
    time.sleep(120)

    print(f"\n{'='*60}")
    print("Stage 9 complete")
    print(f"{'='*60}")


def show_deployment_status():
    """Show pods, services, and ingresses after deployment."""
    print(f"\n{'='*60}")
    print("DEPLOYMENT STATUS")
    print(f"{'='*60}")

    print("\n--- Pods ---")
    run_cmd(["kubectl", "get", "pods", "-n", NAMESPACE])

    print("\n--- Services ---")
    run_cmd(["kubectl", "get", "svc", "-n", NAMESPACE])

    print("\n--- Ingresses ---")
    run_cmd(["kubectl", "get", "ing", "-n", NAMESPACE])


def main():
    print("\n" + "=" * 60)
    print("JFrog Edge Values + Helm Deployment")
    print("=" * 60)

    if not validate_credentials():
        sys.exit(1)

    # Update registry paths based on client region
    if not update_registry_paths_in_values():
        sys.exit(1)

    # Update DNS domain based on client configuration
    if not update_dns_in_values():
        sys.exit(1)

    # Update ingress/httpRoute settings based on client gateway preference
    if not update_gateway_settings_in_values():
        sys.exit(1)

    # Update RBAC API Proxy ingress based on gateway preference
    if not update_rbac_api_proxy_ingress():
        sys.exit(1)

    if not create_namespace():
        sys.exit(1)

    if not create_docker_registry_secret():
        sys.exit(1)

    if not apply_secrets_file():
        sys.exit(1)

    if not setup_helm_repo():
        sys.exit(1)

    all_success = deploy_all_charts()

    if not all_success:
        print(f"\n{'='*60}")
        print("DEPLOYMENT FAILED")
        print(f"{'='*60}")
        sys.exit(1)

    print(f"\n{'='*60}")
    print("SUCCESS - Deployment complete")
    print(f"{'='*60}")

    # Stage 9: Uninstall and reinstall postgres-init-db
    reinstall_postgres_init_db()

    # Stage 10: Deploy RBAC API Proxy ingress
    deploy_rbac_api_proxy_ingress()

    # Show final deployment status
    show_deployment_status()


if __name__ == "__main__":
    main()