# Zora AI Helm Charts - Azure Deployment

This repository follows GitOps best practices for ArgoCD deployments with a centralized chart structure.

## Directory Structure

```
kubernetes/azure/
├── charts/                          # Shared Helm charts (no values.yaml)
│   ├── zora-ai-universal-chart/     # Universal chart for all apps (incl. frontend)
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── deployment.yaml
│   │       ├── service.yaml
│   │       ├── ingress.yaml
│   │       └── secrets.yaml
│   ├── zora-ai-frontend/            # Legacy: dedicated frontend chart (for compatibility)
│   │   ├── Chart.yaml
│   │   ├── values.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── deployment.yaml
│   │       ├── service.yaml
│   │       └── ingress.yaml
│   ├── zora-ai/                     # Legacy: Frontend + Backend chart (for compatibility)
│   │   ├── Chart.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── backend.yaml
│   │       └── frontend.yaml
│   ├── zora-ai-engine/              # Legacy: LLM Engine chart (for compatibility)
│   │   ├── Chart.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── engine.yaml
│   │       └── secrets.yaml
│   ├── zora-ai-postgres/            # Legacy PostgreSQL chart (postgresql-service)
│   │   ├── Chart.yaml
│   │   └── templates/
│   │       ├── _helpers.tpl
│   │       ├── postgres.yaml
│   │       └── secrets.yaml
│   ├── postgres/                    # CloudPirates PostgreSQL chart
│   │   └── ...
│   └── zora-ai-jobs/                # Run-once/sync-triggered Jobs (e.g. postgres init script)
│       ├── Chart.yaml
│       └── templates/
│           ├── _helpers.tpl
│           ├── job.yaml
│           └── configmap.yaml (when script.content is used)
│
└── {{deploy_env}}/                   # Environment-specific values files
    ├── values-zora-ai-configuration-server.yaml
    ├── values-zora-ai-customer-data-server.yaml
    ├── values-zora-ai-engine.yaml
    ├── values-zora-ai-backend.yaml
    ├── values-zora-ai-frontend.yaml
    ├── values-zora-ai-postgres.yaml
    ├── values-zora-ai-postgres-init-db.yaml
    ├── values-zora-ai-benchmarks.yaml
    └── values-zora-ai-redis.yaml
```

## Benefits of This Structure

| Benefit | Description |
|---------|-------------|
| **DRY Principle** | Single source of truth for chart templates |
| **Easy Maintenance** | Update templates once, apply to all environments |
| **Environment Parity** | Same chart logic, different configurations |
| **Clear Separation** | Charts vs Configuration clearly separated |
| **ArgoCD Native** | Works seamlessly with ArgoCD Applications |
| **GitOps Friendly** | Easy to review PRs - only values change per environment |

## ArgoCD Application Examples

### Single Application

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: 'zora-ai-{{deploy_env}}'
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/azure/charts/zora-ai
    helm:
      valueFiles:
        - '../../{{deploy_env}}/values-zora-ai.yaml'
  destination:
    server: https://kubernetes.default.svc
    namespace: 'zora-ai-{{deploy_env}}'
  syncPolicy:
    automated:
      prune: true
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### ApplicationSet for Deployed Environment

```yaml
apiVersion: argoproj.io/v1alpha1
kind: ApplicationSet
metadata:
  name: zora-ai
  namespace: argocd
spec:
  generators:
    - list:
        elements:
          - env: '{{deploy_env}}'
            namespace: 'zora-ai-{{deploy_env}}'
  template:
    metadata:
      name: 'zora-ai-{{env}}'
    spec:
      project: default
      source:
        repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
        targetRevision: main
        path: kubernetes/azure/charts/zora-ai
        helm:
          valueFiles:
            - '../../{{env}}/values-zora-ai.yaml'
      destination:
        server: https://kubernetes.default.svc
        namespace: '{{namespace}}'
      syncPolicy:
        automated:
          prune: true
          selfHeal: true
        syncOptions:
          - CreateNamespace=true
```

### App of Apps Pattern (All Components)

```yaml
# argocd/apps/{{deploy_env}}/zora-ai-app.yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: 'zora-ai-{{deploy_env}}'
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/azure/charts/zora-ai
    helm:
      valueFiles:
        - '../../{{deploy_env}}/values-zora-ai.yaml'
  destination:
    server: https://kubernetes.default.svc
    namespace: 'zora-ai-{{deploy_env}}'
---
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: 'zora-ai-engine-{{deploy_env}}'
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/azure/charts/zora-ai-engine
    helm:
      valueFiles:
        - '../../{{deploy_env}}/values-zora-ai-engine.yaml'
  destination:
    server: https://kubernetes.default.svc
    namespace: 'zora-ai-{{deploy_env}}'
---
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: 'zora-ai-postgres-{{deploy_env}}'
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/azure/charts/zora-ai-postgres
    helm:
      valueFiles:
        - '../../{{deploy_env}}/values-zora-ai-postgres.yaml'
  destination:
    server: https://kubernetes.default.svc
    namespace: 'zora-ai-{{deploy_env}}'
```

## Chart Structure

### Universal Chart (`zora-ai-universal-chart`)

The universal chart is used for all applications:
- `configuration-server`
- `customer-data-server`
- `engine`
- `backend`
- `frontend`

All use the same chart structure with different values files. See `zora-ai-universal-chart/README.md` for detailed documentation.

### PostgreSQL and init

The primary database is **zora-ai-postgres2**, deployed from the **CloudPirates `postgres`** chart (`kubernetes/azure/charts/postgres`) with `values-zora-ai-postgres2.yaml`. Apps connect to `zora-ai-postgres2:5432`. Database creation and read-only user setup are performed by a one-off Job from the **`zora-ai-jobs`** chart (`values-zora-ai-postgres-init-db.yaml`), deployed as the ArgoCD application `zora-ai-postgres-init-db`.

### Legacy Charts

The following charts are maintained for compatibility with existing environments:
- `zora-ai` - Combined frontend + backend
- `zora-ai-engine` - Individual engine chart
- `zora-ai-configuration-server` - Individual configuration server chart
- `zora-ai-customer-data-server` - Individual customer data server chart
- `zora-ai-postgres` - Legacy PostgreSQL (service name `postgresql-service`).

New deployments should use the universal chart for all applications (including frontend).

## Local Testing

You can test the charts locally before deploying:

```bash
# Universal chart example (configuration-server)
helm template configuration-server ./kubernetes/azure/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/{{deploy_env}}/values-zora-ai-configuration-server.yaml

# Universal chart example (frontend)
helm template frontend ./kubernetes/azure/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/{{deploy_env}}/values-zora-ai-frontend.yaml

# Legacy chart example (for compatibility)
helm template zora-ai ./kubernetes/azure/charts/zora-ai \
  -f ./kubernetes/azure/{{deploy_env}}/values-zora-ai.yaml

# Dry run install
helm install configuration-server ./kubernetes/azure/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/{{deploy_env}}/values-zora-ai-configuration-server.yaml \
  --dry-run --debug

# Lint the chart
helm lint ./kubernetes/azure/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/{{deploy_env}}/values-zora-ai-configuration-server.yaml
```

## Secret Management

⚠️ **IMPORTANT**: Never commit real secrets to Git!

For secrets management with ArgoCD, consider:

1. **Sealed Secrets**: Encrypt secrets that only the cluster can decrypt
2. **External Secrets Operator**: Fetch secrets from external stores (Azure Key Vault, AWS Secrets Manager)
3. **ArgoCD Vault Plugin**: Integrate with HashiCorp Vault
4. **SOPS**: Mozilla's Secrets OPerationS for encrypted files

## Adding a New Environment

1. Create a new folder for your environment:
   ```bash
   mkdir -p kubernetes/azure/{{deploy_env}}
   ```

2. Copy values files from an existing environment:
   ```bash
   cp kubernetes/azure/<existing-env>/values-*.yaml kubernetes/azure/{{deploy_env}}/
   ```

3. Update the values in the new environment files (hostnames, tags, etc.)

4. Create ArgoCD Application manifests for the new environment
