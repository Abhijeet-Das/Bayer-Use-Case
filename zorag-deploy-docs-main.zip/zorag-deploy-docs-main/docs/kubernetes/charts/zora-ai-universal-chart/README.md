# Zora AI Universal Application Chart

A universal Helm chart for deploying Zora AI applications: configuration-server, customer-data-server, engine, backend, and frontend. Also suitable for other similar applications (e.g. Spring Boot/Java or Node/frontend).

## Features

- Single universal chart for all applications
- Simple values file structure
- Support for health probes (liveness/readiness)
- Ingress configuration with TLS support
- Flexible environment variables (including secrets)
- Optional secrets management (or use External Secrets Operator)
- Optional persistent volume for StatefulSet (volumeClaimTemplates)
- Resource limits and requests configuration

## Installation

### Configuration Server Example

```bash
helm install configuration-server ./zora-ai-universal-chart -f values-configuration-server.yaml
```

**values-configuration-server.yaml:**
```yaml
app:
  replicaCount: 1
  image:
    repository: artifacts.engineeringplatforms.deloitte.com/aiq-docker-scratch-local/aiq-zora-ai-configuration-server
    tag: "2026.01.21-1224"
  service:
    type: ClusterIP
    port: 8000
  ingress:
    enabled: true
    className: nginx-internal
    secretName: zora-ai-configuration-server-demo-tls-secret
    host: zora-ai-configuration-server.demo.zoraai.eng.deloitte.com
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
      nginx.ingress.kubernetes.io/proxy-connect-timeout: "60"
      nginx.ingress.kubernetes.io/proxy-read-timeout: "600"
      nginx.ingress.kubernetes.io/proxy-send-timeout: "600"
  livenessProbe:
    enabled: false
    httpGet:
      path: /api/v1/health/liveness
      port: http
  readinessProbe:
    enabled: true
    httpGet:
      path: /api/v1/health/readiness
      port: http
  resources:
    limits:
      cpu: "2"
      memory: 32Gi
    requests:
      cpu: "1"
      memory: 8Gi
  env:
    ENV: "develop"
    LOG_LEVEL: "INFO"
    DATASOURCE_URL: "postgresql-service:5432"
    DATASOURCE_DB_NAME: "zora_config"
    DATASOURCE_USERNAME: "postgres"
    DATASOURCE_PASSWORD:
      secretKeyRef:
        name: zora-ai-postgres-secrets
        key: datasource-password
```

### Customer Data Server Example

```bash
helm install customer-data-server ./zora-ai-universal-chart -f values-customer-data-server.yaml
```

**values-customer-data-server.yaml:**
```yaml
app:
  replicaCount: 1
  image:
    repository: artifacts.engineeringplatforms.deloitte.com/aiq-docker-scratch-local/aiq-zora-ai-customer-data-server
    tag: "2026.01.21-1241"
  service:
    type: ClusterIP
    port: 8000
  ingress:
    enabled: true
    className: nginx-internal
    secretName: zora-ai-customer-data-server-demo-tls-secret
    host: zora-ai-customer-data-server.demo.zoraai.eng.deloitte.com
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
  resources:
    limits:
      cpu: "2"
      memory: 32Gi
    requests:
      cpu: "1"
      memory: 8Gi
  env:
    ENV: "develop"
    LOG_LEVEL: "INFO"
    DATASOURCE_URL: "postgresql-service:5432"
    DATASOURCE_DB_NAME: "customer_data"
    DATASOURCE_USERNAME: "postgres"
    DATASOURCE_PASSWORD:
      secretKeyRef:
        name: zora-ai-postgres-secrets
        key: datasource-password
```

### Engine Example

```bash
helm install engine ./zora-ai-universal-chart -f values-engine.yaml
```

**values-engine.yaml:**
```yaml
app:
  replicaCount: 1
  image:
    repository: artifacts.engineeringplatforms.deloitte.com/aiq-docker-scratch-local/aiq-zora-ai-engine
    tag: "2026.01.13-1537"
  service:
    type: ClusterIP
    port: 8000
  ingress:
    enabled: true
    className: nginx-internal
    secretName: zora-ai-engine-prod-tls-secret
    host: zora-ai-engine.demo.zoraai.eng.deloitte.com
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
  resources:
    limits:
      cpu: "4"
      memory: 32Gi
    requests:
      cpu: "2"
      memory: 8Gi
  env:
    AZURE_LLM_ENDPOINT: ""
    DB_AGENT_MODEL_DRIVER: "openai"
    DB_AGENT_MODEL_NAME: "openai/gpt-oss-120b"
    CUSTOMER_DATA_DB: "zora_ai_synthetic_customer_data_db"
    CONFIGS_DB: "zora_ai_configuration_db"
    DB_USERNAME_ZORA_AI_SYNTHETIC_CUSTOMER_DATA_DB: "postgres_read"
    DB_USERNAME_ZORA_AI_CONFIGURATION_DB: "postgres_read"
    REDIS_HOST: "zora-ai-redis-master"
    REDIS_PORT: "6379"
    REDIS_DB: "0"
    REDIS_SOCKET_CONNECT_TIMEOUT: "5"
    REDIS_HEALTH_CHECK_INTERVAL: "30"
    DEVELOPER_MODE: "false"
    AZURE_LLM_API_KEY:
      secretKeyRef:
        name: zora-ai-engine-secrets
        key: AZURE_LLM_API_KEY
    DB_PASSWORD_ZORA_AI_SYNTHETIC_CUSTOMER_DATA_DB:
      secretKeyRef:
        name: zora-ai-engine-secrets
        key: DB_PASSWORD_ZORA_AI_SYNTHETIC_CUSTOMER_DATA_DB
    DB_PASSWORD_ZORA_AI_CONFIGURATION_DB:
      secretKeyRef:
        name: zora-ai-engine-secrets
        key: DB_PASSWORD_ZORA_AI_CONFIGURATION_DB
    REDIS_PASSWORD:
      secretKeyRef:
        name: zora-ai-redis
        key: redis-password

externalSecrets:
  enabled: true
```

## Environment Variables

Environment variables can be set in two ways:

### Simple Key-Value

```yaml
env:
  ENV: "develop"
  LOG_LEVEL: "INFO"
```

### From Kubernetes Secrets

```yaml
env:
  DATASOURCE_PASSWORD:
    secretKeyRef:
      name: postgres-secrets
      key: datasource-password
```

## Health Probes

Enable health probes by setting `enabled: true`:

```yaml
livenessProbe:
  enabled: true
  httpGet:
    path: /api/v1/health/liveness
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10

readinessProbe:
  enabled: true
  httpGet:
    path: /api/v1/health/readiness
    port: http
  initialDelaySeconds: 10
  periodSeconds: 10
```

## Secrets Management

### Using External Secrets Operator (Recommended)

Set `externalSecrets.enabled: true` and reference secrets in your environment variables:

```yaml
externalSecrets:
  enabled: true

app:
  env:
    PASSWORD:
      secretKeyRef:
        name: my-secret
        key: password
```

### Creating Secrets with the Chart

```yaml
app:
  secrets:
    create: true
    name: my-app-secrets
    data:
      API_KEY: "your-api-key"
      DB_PASSWORD: "your-password"
```

## Deployment vs StatefulSet

- **Deployment** (default): Standard rolling update. Use for stateless apps or when persistence is not needed.
- **StatefulSet**: Use for stateful apps with a single replica and RWO storage (e.g. CloudBeaver). Rollout is ordered: the existing pod is terminated first, then the new pod starts and mounts the same PVC—no race and no two pods on the same volume. Set `app.kind: StatefulSet` and keep `app.replicaCount: 1`. With persistence, the chart uses a `volumeClaimTemplates`-based PVC (name: `data-<release>-0`).

## Persistence

Persistence is supported only when `app.kind: StatefulSet`. Enable `app.persistence` to attach a persistent volume (e.g. for CloudBeaver workspace):

```yaml
app:
  kind: StatefulSet
  replicaCount: 1
  persistence:
    enabled: true
    size: 5Gi
    storageClassName: ""   # omit for cluster default
    mountPath: /opt/cloudbeaver/workspace
```

The StatefulSet uses `volumeClaimTemplates`; the PVC is named `data-<release>-0` and mounted at the given `mountPath`.

## Values Reference

See `values.yaml` for the complete list of configurable parameters.
