{{/*
Expand the name of the chart.
*/}}
{{- define "zora-ai-universal-chart.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "zora-ai-universal-chart.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "zora-ai-universal-chart.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "zora-ai-universal-chart.labels" -}}
helm.sh/chart: {{ include "zora-ai-universal-chart.chart" . }}
{{ include "zora-ai-universal-chart.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "zora-ai-universal-chart.selectorLabels" -}}
app.kubernetes.io/name: {{ include "zora-ai-universal-chart.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Get container name - defaults to release name (stripping zora-ai- prefix if present) or can be overridden
*/}}
{{- define "zora-ai-universal-chart.containerName" -}}
{{- if .Values.containerName }}
{{- .Values.containerName }}
{{- else }}
{{- $releaseName := .Release.Name }}
{{- if hasPrefix "zora-ai-" $releaseName }}
{{- trimPrefix "zora-ai-" $releaseName }}
{{- else }}
{{- $releaseName }}
{{- end }}
{{- end }}
{{- end }}
