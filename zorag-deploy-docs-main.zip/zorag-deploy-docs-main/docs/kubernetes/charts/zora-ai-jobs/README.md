# zora-ai-jobs

Universal Helm chart to run **any script** as a Kubernetes Job. The script is provided as a parameter (inline or via ConfigMap).

## Script source

- **script.content**: Inline script (supports Helm `tpl` for templating). A ConfigMap is created and mounted.
- **script.configMapRef**: Use an existing ConfigMap: `{ name: "my-cm", key: "script.sh" }`. No ConfigMap is created.

## Usage

1. Set either `script.content` (inline script) or `script.configMapRef` (existing ConfigMap).
2. Set `job.image` to an image that can run the script (e.g. postgres, alpine, busybox).
3. Set `job.command` if the script filename/path differs from the default (`/scripts/script.sh`).
4. Set `job.env`, `job.initContainers` as needed (e.g. wait for a service, pass secrets).

**Re-run without manual delete:** The Job has a `checksum/script` annotation (hash of script content or configMapRef) and `argocd.argoproj.io/sync-options: Replace=true`. When you change the script in values (or the configMapRef), the Job spec changes; on sync ArgoCD replaces the Job (delete + create), so the new Job runs. If nothing changed, ArgoCD leaves the Job alone.

## Values (see values.yaml)

- **script.content**: Inline script (Helm-templated via `tpl`).
- **script.scriptKey**, **script.scriptMountPath**: Key and mount path when using inline script.
- **script.configMapRef**: `{ name, key }` to use an existing ConfigMap.
- **job.image**, **job.command**, **job.env**, **job.envFrom**, **job.initContainers**, **job.backoffLimit**, **job.ttlSecondsAfterFinished**.

## Examples

- Postgres init-db: see `dev2/values-postgres-init-db.yaml` (inline script with `tpl`, initContainer waits for postgres).
- Backup job: provide script.content or configMapRef, set image and env as needed.
