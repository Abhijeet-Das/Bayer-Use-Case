{{/*
zora-ai-jobs fullname
*/}}
{{- define "zora-ai-jobs.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-zora-ai-jobs" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "zora-ai-jobs.configmapName" -}}
{{- include "zora-ai-jobs.fullname" . }}-script
{{- end }}

{{/*
Job name includes short checksum so each script/params change produces a new name.
ArgoCD then deletes the old Job and creates the new one (no in-place replace), avoiding
immutable-field errors (selector, template labels).
*/}}
{{- define "zora-ai-jobs.jobName" -}}
{{- $sum := include "zora-ai-jobs.scriptChecksum" . | trim }}
{{- $short := $sum | trunc 8 }}
{{- printf "%s-%s" (include "zora-ai-jobs.fullname" .) $short | trunc 63 }}
{{- end }}

{{/*
Script checksum for Job annotation: changes when script content, script params (databases, readOnlyUser), or configMapRef changes.
Use with Replace=true so ArgoCD replaces the Job on sync when spec changes.
*/}}
{{- define "zora-ai-jobs.scriptChecksum" -}}
{{- if .Values.script.content }}
{{- $rendered := tpl .Values.script.content . }}
{{- $databases := .Values.script.databases | default list | sortAlpha | join "," }}
{{- $readOnlyUser := .Values.script.readOnlyUser | default "" }}
{{- printf "%s|databases:%s|readOnlyUser:%s" $rendered $databases $readOnlyUser | sha256sum }}
{{- else if and .Values.script.configMapRef .Values.script.configMapRef.name }}
{{- printf "external-%s-%s" .Values.script.configMapRef.name (.Values.script.configMapRef.key | default "script.sh") | sha256sum }}
{{- else }}
{{- "none" | sha256sum }}
{{- end }}
{{- end }}
