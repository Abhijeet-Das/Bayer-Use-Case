{{/*
============ Inlined from CloudPirates common chart (templates/_helpers.tpl) ============
Used by this chart; dependency on common subchart removed.
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "cloudpirates.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "cloudpirates.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- $name := default .Chart.Name .Values.nameOverride }}
{{- if contains $name .Release.Name }}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Return the namespace to use for resources.
*/}}
{{- define "cloudpirates.namespace" -}}
{{- default .Release.Namespace .Values.namespaceOverride | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Create a fully qualified app name adding the installation's namespace.
*/}}
{{- define "cloudpirates.fullname.namespace" -}}
{{- printf "%s-%s" (include "cloudpirates.fullname" .) (include "cloudpirates.namespace" .) | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "cloudpirates.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels
*/}}
{{- define "cloudpirates.labels" -}}
helm.sh/chart: {{ include "cloudpirates.chart" . }}
{{ include "cloudpirates.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- with .Values.commonLabels }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "cloudpirates.selectorLabels" -}}
{{- if and .Values.selectorLabels .Values.selectorLabels.name }}
app.kubernetes.io/name: {{ .Values.selectorLabels.name }}
{{- else -}}
app.kubernetes.io/name: {{ include "cloudpirates.name" . }}
{{ end -}}
{{- if and .Values.selectorLabels .Values.selectorLabels.instance }}
app.kubernetes.io/instance: {{ .Values.selectorLabels.instance }}
{{- else -}}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "cloudpirates.annotations" -}}
{{- with .Values.commonAnnotations }}
{{ toYaml . }}
{{- end }}
{{- end }}

{{/*
Return the proper image name with registry and tag (tag includes digest if present)
*/}}
{{- define "cloudpirates.image" -}}
{{- $registryName := .image.registry -}}
{{- $repositoryName := .image.repository -}}
{{- $tag := .image.tag | toString -}}
{{- if .global }}
 {{- if .global.imageRegistry }}
 {{- $registryName = .global.imageRegistry -}}
 {{- end -}}
{{- end -}}
{{- if $registryName }}
{{- printf "%s/%s:%s" $registryName $repositoryName $tag -}}
{{- else -}}
{{- printf "%s:%s" $repositoryName $tag -}}
{{- end -}}
{{- end }}

{{/*
Return the proper image pull policy
*/}}
{{- define "cloudpirates.imagePullPolicy" -}}
{{- .image.imagePullPolicy | default .image.pullPolicy | default "Always" -}}
{{- end }}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "cloudpirates.imagePullSecrets" -}}
{{- $pullSecrets := list }}

{{- if .global }}
 {{- range .global.imagePullSecrets -}}
 {{- $pullSecrets = append $pullSecrets . -}}
 {{- end -}}
{{- end -}}

{{- if and .image .image.pullSecrets }}
 {{- range .image.pullSecrets -}}
 {{- $pullSecrets = append $pullSecrets . -}}
 {{- end -}}
{{- end -}}

{{- if .Values.imagePullSecrets }}
 {{- range .Values.imagePullSecrets -}}
 {{- $pullSecrets = append $pullSecrets . -}}
 {{- end -}}
{{- end -}}

{{- if (not (empty $pullSecrets)) }}
imagePullSecrets:
{{- range $pullSecrets }}
{{- if kindIs "map" . }}
 - name: {{ .name }}
{{- else }}
 - name: {{ . }}
{{- end }}
{{- end }}
{{- end }}
{{- end }}

{{/*
Render a value that contains template perhaps
*/}}
{{- define "cloudpirates.tplvalues.render" -}}
 {{- $value := typeIs "string" .value | ternary .value (.value | toYaml) }}
 {{- if contains "{{" (toString $value) }}
 {{- tpl $value .context }}
 {{- else }}
 {{- $value }}
 {{- end }}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names evaluating values as templates
*/}}
{{- define "cloudpirates.images.renderPullSecrets" -}}
 {{- $pullSecrets := list }}
 {{- $context := .context }}
 {{- $global := default dict $context.Values.global }}

 {{- range $global.imagePullSecrets -}}
 {{- if kindIs "map" . -}}
 {{- $pullSecrets = append $pullSecrets (include "cloudpirates.tplvalues.render" (dict "value" .name "context" $context)) -}}
 {{- else -}}
 {{- $pullSecrets = append $pullSecrets (include "cloudpirates.tplvalues.render" (dict "value" . "context" $context)) -}}
 {{- end -}}
 {{- end -}}

 {{- range .images -}}
 {{- range .pullSecrets -}}
 {{- if kindIs "map" . -}}
 {{- $pullSecrets = append $pullSecrets (include "cloudpirates.tplvalues.render" (dict "value" .name "context" $context)) -}}
 {{- else -}}
 {{- $pullSecrets = append $pullSecrets (include "cloudpirates.tplvalues.render" (dict "value" . "context" $context)) -}}
 {{- end -}}
 {{- end -}}
 {{- end -}}

 {{- if (not (empty $pullSecrets)) -}}
imagePullSecrets:
 {{- range $pullSecrets | uniq }}
 - name: {{ . }}
 {{- end }}
 {{- end }}
{{- end -}}

{{/*
Detect if the target platform is OpenShift
*/}}
{{- define "cloudpirates.isOpenshift" -}}
{{- if or (eq (lower (default "" .Values.targetPlatform)) "openshift") (.Capabilities.APIVersions.Has "route.openshift.io/v1") -}}
true
{{- else -}}
false
{{- end -}}
{{- end }}

{{/*
Render podSecurityContext, omitting runAsUser, runAsGroup, fsGroup, and seLinuxOptions if OpenShift is detected.
*/}}
{{- define "cloudpirates.renderPodSecurityContext" -}}
{{- $isOpenshift := include "cloudpirates.isOpenshift" . | trim }}
{{- if eq $isOpenshift "true" }}
{{- omit .Values.podSecurityContext "runAsUser" "runAsGroup" "fsGroup" "seLinuxOptions" | toYaml }}
{{- else }}
{{- toYaml .Values.podSecurityContext }}
{{- end }}
{{- end }}

{{/*
Render containerSecurityContext, omitting runAsUser, runAsGroup, and seLinuxOptions if OpenShift is detected.
*/}}
{{- define "cloudpirates.renderContainerSecurityContext" -}}
{{- $isOpenshift := include "cloudpirates.isOpenshift" . | trim }}
{{- if eq $isOpenshift "true" }}
{{- omit .Values.containerSecurityContext "runAsUser" "runAsGroup" "seLinuxOptions" | toYaml }}
{{- else }}
{{- toYaml .Values.containerSecurityContext }}
{{- end }}
{{- end }}

{{/*
============ Postgres chart helpers ============
*/}}

{{/*
Expand the name of the chart.
*/}}
{{- define "postgres.name" -}}
{{- include "cloudpirates.name" . -}}
{{- end }}

{{/*
Create a default fully qualified app name.
*/}}
{{- define "postgres.fullname" -}}
{{- include "cloudpirates.fullname" . -}}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "postgres.chart" -}}
{{- include "cloudpirates.chart" . -}}
{{- end }}

{{/*
Common labels
*/}}
{{- define "postgres.labels" -}}
{{- include "cloudpirates.labels" . -}}
{{- end }}

{{/*
Common annotations
*/}}
{{- define "postgres.annotations" -}}
{{- with .Values.commonAnnotations }}
{{- toYaml . }}
{{- end }}
{{- end }}

{{/*
Selector labels
*/}}
{{- define "postgres.selectorLabels" -}}
{{- include "cloudpirates.selectorLabels" . -}}
{{- end }}

{{/*
Return the proper PostgreSQL image name
*/}}
{{- define "postgres.image" -}}
{{- include "cloudpirates.image" (dict "image" .Values.image "global" .Values.global) -}}
{{- end }}

{{/*
Return PostgreSQL credentials secret name
*/}}
{{- define "postgres.secretName" -}}
{{- if .Values.auth.existingSecret -}}
    {{- include "cloudpirates.tplvalues.render" (dict "value" .Values.auth.existingSecret "context" .) -}}
{{- else -}}
    {{- include "postgres.fullname" . -}}
{{- end -}}
{{- end }}

{{/*
Return PostgreSQL admin password key
*/}}
{{- define "postgres.adminPasswordKey" -}}
{{- if .Values.auth.existingSecret -}}
    {{- include "cloudpirates.tplvalues.render" (dict "value" .Values.auth.secretKeys.adminPasswordKey "context" .) | default "postgres-password" -}}
{{- else -}}
postgres-password
{{- end -}}
{{- end }}

{{/*
Return PostgreSQL user password key
*/}}
{{- define "postgres.userPasswordKey" -}}
{{- if .Values.auth.existingSecret -}}
    {{- .Values.auth.secretKeys.userPasswordKey -}}
{{- else -}}
password
{{- end -}}
{{- end }}

{{/*
Return PostgreSQL configuration ConfigMap name
*/}}
{{- define "postgres.configmapName" -}}
{{- if .Values.config.existingConfigmap -}}
    {{- .Values.config.existingConfigmap -}}
{{- else -}}
    {{- include "postgres.fullname" . -}}
{{- end -}}
{{- end }}

{{/*
Return PostgreSQL initialization scripts ConfigMap name
*/}}
{{- define "postgres.initdb.scriptsCM" -}}
{{- if .Values.initdb.scriptsConfigMap -}}
    {{- printf "%s" (tpl .Values.initdb.scriptsConfigMap $) -}}
{{- else -}}
    {{- printf "%s-init-scripts" (include "postgres.fullname" .) -}}
{{- end -}}
{{- end -}}

{{/*
Return PostgreSQL config directory
*/}}
{{- define "postgres.configDir" -}}
{{- printf "/etc/postgresql" -}}
{{- end }}

{{/*
Return PostgreSQL run directory
*/}}
{{- define "postgres.runDir" -}}
{{- printf "/var/run/postgresql" -}}
{{- end }}

{{/*
Get PostgreSQL database name
*/}}
{{- define "postgres.database" -}}
{{- if .Values.auth.database -}}
{{- .Values.auth.database -}}
{{- else -}}
postgres
{{- end -}}
{{- end }}

{{/*
Get PostgreSQL username
*/}}
{{- define "postgres.username" -}}
{{- if .Values.auth.username -}}
{{- include "cloudpirates.tplvalues.render" (dict "value" .Values.auth.username "context" .) -}}
{{- else -}}
postgres
{{- end -}}
{{- end }}

{{/*
Return the proper Docker Image Registry Secret Names
*/}}
{{- define "postgres.imagePullSecrets" -}}
{{ include "cloudpirates.images.renderPullSecrets" (dict "images" (list .Values.image) "context" .) }}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "postgres.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}
{{- default (include "postgres.fullname" .) .Values.serviceAccount.name }}
{{- else }}
{{- default "default" .Values.serviceAccount.name }}
{{- end }}
{{- end }}

{{- define "postgres.custom-user-configname" -}}
{{- printf "%s-custom-user-credentials" (include "postgres.fullname" .) -}}
{{- end }}

{{/*
Extract PostgreSQL major version from image tag
*/}}
{{- define "postgres.majorVersion" -}}
  {{- $tag := .Values.image.tag -}}
  {{- if contains "@" $tag -}}
    {{- $tag = (split "@" $tag)._0 -}}
  {{- end -}}

  {{- if regexMatch "pg[0-9]+" $tag -}}
    {{- regexReplaceAll ".*pg([0-9]+).*" $tag "${1}" -}}
  {{- else -}}
    {{- if contains "-" $tag -}}
      {{- $tag = (regexReplaceAll "-.*" $tag "") -}}
    {{- end -}}
    {{- if contains "." $tag -}}
      {{- (split "." $tag)._0 -}}
    {{- else -}}
      {{- $tag -}}
    {{- end -}}
  {{- end -}}
{{- end }}

{{/*
Return PostgreSQL data directory based on major version and image type
*/}}
{{- define "postgres.dataDir" -}}
{{- $majorVersion := include "postgres.majorVersion" . | int -}}
{{- if ge $majorVersion 18 -}}
{{- printf "/var/lib/postgresql" -}}
{{- else if .Values.image.useHardenedImage -}}
{{- printf "/var/lib/postgresql" -}}
{{- else -}}
{{- printf "/var/lib/postgresql/data" -}}
{{- end -}}
{{- end }}

{{/*
Return PGDATA path based on major version and image type
*/}}
{{- define "postgres.pgdataPath" -}}
{{- $majorVersion := include "postgres.majorVersion" . | int -}}
{{- if ge $majorVersion 18 -}}
{{- printf "/var/lib/postgresql/%d/docker" $majorVersion -}}
{{- else if .Values.image.useHardenedImage -}}
{{- printf "/var/lib/postgresql/%d/data" $majorVersion -}}
{{- else -}}
{{- printf "/var/lib/postgresql/data/pgdata" -}}
{{- end -}}
{{- end }}

{{- define "postgres.replicationEnv" -}}
- name: REPLICATION_USER
  value: {{ tpl .Values.replication.auth.username . | quote }}
- name: REPLICATION_PASSWORD
  {{- if .Values.replication.auth.existingSecret }}
  valueFrom:
    secretKeyRef:
      name: {{ tpl .Values.replication.auth.existingSecret . | quote }}
      key: {{ .Values.replication.auth.secretKeys.password }}
  {{- else }}
  value: {{ tpl .Values.replication.auth.password . | quote }}
  {{- end }}
{{- end }}
