# PostgreSQL Helm Chart (CloudPirates)

Copied from [CloudPirates-io/helm-charts](https://github.com/CloudPirates-io/helm-charts/tree/main/charts/postgres).

The `common` subchart dependency has been removed; its helper templates are inlined in `templates/_helpers.tpl`, so no `helm dependency update` or OCI registry is required.
