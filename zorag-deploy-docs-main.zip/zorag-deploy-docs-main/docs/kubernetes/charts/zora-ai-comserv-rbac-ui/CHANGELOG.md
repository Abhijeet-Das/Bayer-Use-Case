# Changelog

## [0.1.1](https://github.com/Deloitte-US-Engineering/comserv-rbac/compare/comserv-rbac-ui-chart-v0.1.0...comserv-rbac-ui-chart-v0.1.1) (2025-06-25)


### Bug Fixes

* Rename helm chart workflows to comserv-rbac ([86b9988](https://github.com/Deloitte-US-Engineering/comserv-rbac/commit/86b99887acf3bf1d04769a021f3982edb949511d))
* update all chart workflows ([d2e1a80](https://github.com/Deloitte-US-Engineering/comserv-rbac/commit/d2e1a80b42e6e1842a929a2cb4084946832f7d3f))

## Changelog
