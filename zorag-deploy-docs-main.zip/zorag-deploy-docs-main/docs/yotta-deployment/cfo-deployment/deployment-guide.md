# ZORA AI Platform — CFO Deployment Guide

Run the single automated script from the master node:

```bash
cd cfo-deployment/scripts
./service-deploy.sh
```

---

## Deployment Sequence

| Step | Phase | Service | Resource Type | Wait For |
|------|-------|---------|---------------|----------|
| 1 | SECRETS | Database Credentials | Secret | N/A |
| 1 | SECRETS | Platform Secrets | Secret | N/A |
| 2 | CORE | PostgreSQL | StatefulSet | Ready |
| 3 | CORE | PostgreSQL Init | Job | Complete |
| 4 | CORE | Redis | StatefulSet | Ready |
| 5 | CORE | Customer Data Server | Deployment | Ready |
| 6 | CORE | Configuration Server | Deployment | Ready |
| 7 | CORE | Agent Skills | Job | Complete |
| 8 | CORE | RBAC Backend | Deployment | Ready |
| 8 | CORE | RBAC Frontend | Deployment | Ready |
| 9 | CORE | Backend | Deployment | Ready |
| 10 | CORE | Frontend | Deployment | Ready |
| 11 | CORE | Engine | Deployment | Ready |
| 12 | PROXY | Traefik Middleware & Ingress | Kubernetes Objects | N/A |

**Total Duration:** 15–30 minutes

---

## Script Configuration

All defaults are overridable via environment variables:

```bash
NAMESPACE="<NAMESPACE>"
CHARTS_DIR="./charts"
VALUES_DIR="./values"
SECRETS_DIR="./secrets"
```

Override example:

```bash
NAMESPACE=my-ns IMAGE_TAG=v2.2.0 ./service-deploy.sh
```

| Log Prefix | Meaning |
|------------|---------|
| `[INFO]` | Informational |
| `[✓]` | Success |
| `[✗]` | Error — deployment stops |
| `[!]` | Warning |

---

## Verification

```bash
# Secrets
kubectl get secret -n <NAMESPACE> | grep zora-ai

# Pods
kubectl get pods -n <NAMESPACE>
kubectl get deployments -n <NAMESPACE> -o wide
kubectl get statefulsets -n <NAMESPACE> -o wide

# Ingress & middleware
kubectl get middleware -n <NAMESPACE>
kubectl get ingress -n <NAMESPACE>

# Smoke test (after DNS configured)
curl -k https://cfo-rbac.<YOUR_DOMAIN>/api/health
```

---

## Manual Deployment (selective)

```bash
# Secrets only
kubectl apply -f secrets/zora-ai-db-users-secrets.yaml -n <NAMESPACE>
kubectl apply -f secrets/zora-ai-k8s-secrets.yaml -n <NAMESPACE>

# Proxy only
kubectl apply -f secrets/proxy.yaml -n <NAMESPACE>
```

---

## Troubleshooting

**Secrets step fails:**

```bash
ls -la secrets/
kubectl apply -f secrets/zora-ai-db-users-secrets.yaml -n <NAMESPACE> --dry-run=client
```

**Service step fails:**

```bash
kubectl logs <pod-name> -n <NAMESPACE>
kubectl describe pod <pod-name> -n <NAMESPACE>
kubectl get events -n <NAMESPACE> --sort-by='.lastTimestamp'
```

**Pods pending** — check for insufficient resources, missing secrets, or PVC issues:

```bash
kubectl describe pod <pod-name> -n <NAMESPACE>
```

**Ingress not accessible:**

```bash
kubectl get ingress -n <NAMESPACE> -o yaml
kubectl logs -f -l app=traefik -n traefik
```

---

## Rollback

```bash
# All releases
helm list -n <NAMESPACE> | awk '{print $1}' | tail -n +2 | \
  xargs -I {} helm delete {} -n <NAMESPACE>
kubectl delete ingress cfo-rbac-api-proxy -n <NAMESPACE>
kubectl delete middleware cfo-rbac-api-strip -n <NAMESPACE>

# Proxy only
kubectl delete ingress cfo-rbac-api-proxy -n <NAMESPACE>
kubectl delete middleware cfo-rbac-api-strip -n <NAMESPACE>

# Single release
helm delete <release-name> -n <NAMESPACE>
```

---

## Deployment Timeline

| Component | Duration |
|-----------|----------|
| Secrets | < 1 min |
| PostgreSQL | 2–5 min |
| PostgreSQL Init | 1–3 min |
| Redis | 1–3 min |
| Data Services | 3–5 min |
| Agent Skills job | 2–5 min |
| RBAC services | 3–5 min |
| Backend / Frontend / Engine | 5–10 min |
| Proxy | < 1 min |
| **Total** | **15–30 min** |
