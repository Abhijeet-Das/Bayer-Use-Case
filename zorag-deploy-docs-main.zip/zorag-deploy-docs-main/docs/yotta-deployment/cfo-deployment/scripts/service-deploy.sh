#!/usr/bin/env bash
# Automated 12-step deployment for all ZORA AI services.
# Run from the CFO-Deployment directory with Helm and kubectl configured.
#
# Override defaults via environment variables:
#   NAMESPACE=my-ns IMAGE_TAG=v2.1.0 ./service-deploy.sh

set -euo pipefail

# ── Configuration — override via env vars ─────────────────────────────────────
NAMESPACE="${NAMESPACE:-<NAMESPACE>}"
IMAGE_TAG="${IMAGE_TAG:-<IMAGE_TAG>}"
RELEASE_PREFIX="${RELEASE_PREFIX:-zora}"
CHARTS_DIR="${CHARTS_DIR:-./charts}"
VALUES_DIR="${VALUES_DIR:-./values}"
SECRETS_DIR="${SECRETS_DIR:-./secrets}"

echo "========================================================"
echo "  ZORA AI Service Deployment"
echo "  Namespace : $NAMESPACE"
echo "  Image Tag : $IMAGE_TAG"
echo "========================================================"

# ── Helper ────────────────────────────────────────────────────────────────────
helm_upgrade() {
  local release="$1" chart="$2" values="$3"
  shift 3
  echo ""
  echo ">>> Deploying: $release"
  helm upgrade --install "$release" "$chart" \
    --namespace "$NAMESPACE" \
    --values "$values" \
    --set app.image.tag="$IMAGE_TAG" \
    --wait \
    "$@"
}

# ── Step 1: Apply Kubernetes secrets ─────────────────────────────────────────
echo ""
echo ">>> Step 1: Applying secrets"
kubectl apply -f "$SECRETS_DIR/" --namespace "$NAMESPACE"

# ── Step 2: Deploy PostgreSQL ─────────────────────────────────────────────────
helm_upgrade \
  zora-ai-postgres \
  "$CHARTS_DIR/zora-ai-postgres" \
  "$VALUES_DIR/values-zora-ai-postgres.yaml"

echo "Waiting for PostgreSQL to become ready..."
kubectl rollout status statefulset/zora-ai-postgres \
  --namespace "$NAMESPACE" --timeout=300s

# ── Step 3: Run PostgreSQL init job ──────────────────────────────────────────
echo ""
echo ">>> Step 3: Running PostgreSQL init job"
helm upgrade --install zora-ai-postgres-jobs \
  "$CHARTS_DIR/zora-ai-jobs" \
  --namespace "$NAMESPACE" \
  --values "$VALUES_DIR/values-zora-ai-postgres-init-db.yaml" \
  --wait --timeout=600s

# ── Step 4: Deploy Redis ──────────────────────────────────────────────────────
helm_upgrade \
  zora-ai-redis \
  "$CHARTS_DIR/zora-ai-redis" \
  "$VALUES_DIR/values-zora-ai-redis.yaml"

echo "Waiting for Redis to become ready..."
kubectl rollout status statefulset/zora-ai-redis-master \
  --namespace "$NAMESPACE" --timeout=300s

# ── Step 5: Deploy Customer Data Server ──────────────────────────────────────
helm_upgrade \
  zora-ai-customer-data-server \
  "$CHARTS_DIR/zora-ai-universal-chart" \
  "$VALUES_DIR/values-zora-ai-customer-data-server.yaml"

# ── Step 6: Deploy Configuration Server ──────────────────────────────────────
helm_upgrade \
  zora-ai-configuration-server \
  "$CHARTS_DIR/zora-ai-universal-chart" \
  "$VALUES_DIR/values-zora-ai-configuration-server.yaml"

# ── Step 7: Run Agent Skills job ──────────────────────────────────────────────
echo ""
echo ">>> Step 7: Running Agent Skills job"
helm upgrade --install zora-agent-skills-job \
  "$CHARTS_DIR/zora-ai-jobs" \
  --namespace "$NAMESPACE" \
  --values "$VALUES_DIR/values-zora-agent-skills.yaml" \
  --wait --timeout=600s

# ── Step 8: Deploy RBAC Backend (main app instance) ──────────────────────────
helm_upgrade \
  cfo-rbac-api \
  "$CHARTS_DIR/zora-ai-comserv-rbac-app" \
  "$VALUES_DIR/values-zora-ai-rbac-backend.yaml"

# ── Step 9: Deploy RBAC Frontend ─────────────────────────────────────────────
helm_upgrade \
  cfo-rbac \
  "$CHARTS_DIR/zora-ai-comserv-rbac-ui" \
  "$VALUES_DIR/values-zora-ai-rbac-frontend.yaml"

# ── Step 10: Deploy AI Backend ────────────────────────────────────────────────
helm_upgrade \
  zora-ai-backend \
  "$CHARTS_DIR/zora-ai-universal-chart" \
  "$VALUES_DIR/values-zora-ai-backend.yaml"

# ── Step 11: Deploy AI Frontend ──────────────────────────────────────────────
helm_upgrade \
  zora-ai-frontend \
  "$CHARTS_DIR/zora-ai-universal-chart" \
  "$VALUES_DIR/values-zora-ai-frontend.yaml"

# ── Step 12: Deploy AI Engine and RBAC Backend UI instance ───────────────────
helm_upgrade \
  zora-ai-engine \
  "$CHARTS_DIR/zora-ai-universal-chart" \
  "$VALUES_DIR/values-zora-ai-engine.yaml"

# Deploy second RBAC backend instance (for RBAC UI) + proxy ingress
helm_upgrade \
  cfo-rbac-api-ui \
  "$CHARTS_DIR/zora-ai-comserv-rbac-app" \
  "$VALUES_DIR/values-zora-ai-rbac-backend-ui.yaml"

echo ""
echo ">>> Applying Traefik proxy ingress for RBAC UI /api routing"
kubectl apply -f "$SECRETS_DIR/proxy.yaml" --namespace "$NAMESPACE"

# ── Summary ───────────────────────────────────────────────────────────────────
echo ""
echo "========================================================"
echo "  Deployment complete!"
echo ""
echo "  Verify pod status:"
echo "    kubectl get pods -n $NAMESPACE"
echo ""
echo "  Access the application (NodePort 32337 from jump server):"
echo "    AI Frontend : https://cfo-ai.<YOUR_DOMAIN>:32337"
echo "    RBAC UI     : https://cfo-rbac.<YOUR_DOMAIN>:32337"
echo "========================================================"
