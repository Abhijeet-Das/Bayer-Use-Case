#!/usr/bin/env bash
# Rolling-restart one or all ZORA AI deployments without redeploying.
# Useful after secret rotation or ConfigMap changes.
#
# Usage:
#   ./restart-service.sh                          # restart all deployments
#   ./restart-service.sh zora-ai-backend          # restart a specific deployment
#   NAMESPACE=my-ns ./restart-service.sh          # override namespace

set -euo pipefail

NAMESPACE="${NAMESPACE:-<NAMESPACE>}"

ALL_DEPLOYMENTS=(
  zora-ai-backend
  zora-ai-frontend
  zora-ai-engine
  zora-ai-configuration-server
  zora-ai-customer-data-server
  cfo-rbac-api
  cfo-rbac-api-ui
  cfo-rbac
)

restart_deployment() {
  local name="$1"
  echo "Restarting deployment: $name"
  kubectl rollout restart deployment/"$name" --namespace "$NAMESPACE"
  kubectl rollout status  deployment/"$name" --namespace "$NAMESPACE" --timeout=180s
}

if [[ $# -gt 0 ]]; then
  restart_deployment "$1"
else
  echo "Restarting all deployments in namespace: $NAMESPACE"
  echo ""
  for dep in "${ALL_DEPLOYMENTS[@]}"; do
    restart_deployment "$dep"
    echo ""
  done
  echo "All deployments restarted successfully."
fi
