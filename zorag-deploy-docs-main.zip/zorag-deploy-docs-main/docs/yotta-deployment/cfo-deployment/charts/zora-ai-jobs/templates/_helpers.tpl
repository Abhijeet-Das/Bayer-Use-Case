{{/*
zora-ai-jobs fullname
*/}}
{{- define "zora-ai-jobs.fullname" -}}
{{- if .Values.fullnameOverride }}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}
{{- else }}
{{- printf "%s-zora-ai-jobs" .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- end }}

{{- define "zora-ai-jobs.configmapName" -}}
{{- include "zora-ai-jobs.fullname" . }}-script
{{- end }}

{{/*
Job name includes short checksum so each script/params change produces a new name.
ArgoCD then deletes the old Job and creates the new one (no in-place replace), avoiding
immutable-field errors (selector, template labels).
*/}}
{{- define "zora-ai-jobs.jobName" -}}
{{- $sum := include "zora-ai-jobs.scriptChecksum" . | trim }}
{{- $short := $sum | trunc 8 }}
{{- printf "%s-%s" (include "zora-ai-jobs.fullname" .) $short | trunc 63 }}
{{- end }}

{{/*
Script checksum for Job naming: changes when script content, script params, configMapRef,
OR job spec (image, env, initContainers, command, args, useImageEntrypoint) changes.
Including the job spec is critical: Job spec.selector / spec.template are immutable, so
when the rendered Job spec changes (e.g. image tag bump) we must produce a new Job name —
otherwise ArgoCD will try to replace the existing Job in place and sync will fail with
"selector: field is immutable".
*/}}
{{- define "zora-ai-jobs.scriptChecksum" -}}
{{- $jobSpec := toYaml .Values.job }}
{{- if .Values.script.content }}
{{- $rendered := tpl .Values.script.content . }}
{{- $databases := .Values.script.databases | default list | sortAlpha | join "," }}
{{- $readOnlyUser := .Values.script.readOnlyUser | default "" }}
{{- printf "%s|databases:%s|readOnlyUser:%s|job:%s" $rendered $databases $readOnlyUser $jobSpec | sha256sum }}
{{- else if and .Values.script.configMapRef .Values.script.configMapRef.name }}
{{- printf "external-%s-%s|job:%s" .Values.script.configMapRef.name (.Values.script.configMapRef.key | default "script.sh") $jobSpec | sha256sum }}
{{- else }}
{{- printf "noscript|job:%s" $jobSpec | sha256sum }}
{{- end }}
{{- end }}

{{/*
Common labels — all five standard Helm labels.
*/}}
{{- define "zora-ai-jobs.labels" -}}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}

{{/*
Selector labels — stable name+instance subset used in matchLabels and pod template metadata.
Never include chart version or date here; changes would break rolling updates.
*/}}
{{- define "zora-ai-jobs.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
Container spec — the full "- name: run-script" list item.

Call with nindent matching the containers list indentation in each template:
  job.yaml:     {{- include "zora-ai-jobs.container" . | nindent 6 }}
  cronjob.yaml: {{- include "zora-ai-jobs.container" . | nindent 10 }}
*/}}
{{- define "zora-ai-jobs.container" -}}
{{- $hasScript := or .Values.script.content (and .Values.script.configMapRef .Values.script.configMapRef.name) -}}
{{- $hasScriptMount := or .Values.script.content .Values.script.configMapRef.name -}}
- name: run-script
  image: {{ printf "%s:%s" (required "job.image.repository is required" .Values.job.image.repository) (required "job.image.tag is required" .Values.job.image.tag) | quote }}
  imagePullPolicy: {{ .Values.job.image.pullPolicy }}
  {{- if or .Values.job.command $hasScript }}
  command:
  {{- if .Values.job.command }}
  {{- toYaml .Values.job.command | nindent 2 }}
  {{- else }}
  - /bin/sh
  - {{ .Values.script.scriptMountPath | default "/scripts" }}/{{ .Values.script.scriptKey | default "script.sh" }}
  {{- end }}
  {{- end }}
  {{- with .Values.job.env }}
  env:
  {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- with .Values.job.envFrom }}
  envFrom:
  {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- with .Values.job.resources }}
  resources:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- with .Values.job.containerSecurityContext }}
  securityContext:
    {{- toYaml . | nindent 4 }}
  {{- end }}
  {{- if or $hasScriptMount .Values.job.extraVolumeMounts .Values.pvc.enabled }}
  volumeMounts:
  {{- if $hasScriptMount }}
  - name: script
    mountPath: {{ .Values.script.scriptMountPath | default "/scripts" }}
    readOnly: true
  {{- end }}
  {{- with .Values.job.extraVolumeMounts }}
  {{- toYaml . | nindent 2 }}
  {{- end }}
  {{- if .Values.pvc.enabled }}
  - name: backup-pvc
    mountPath: {{ .Values.pvc.mountPath | default "/backups" }}
  {{- end }}
  {{- end }}
{{- end }}

{{/*
Volumes block — the full "volumes:" section with all volume definitions.
Renders nothing when no volumes are needed.

Call with nindent matching the pod spec indentation in each template:
  job.yaml:     {{- include "zora-ai-jobs.volumes" . | nindent 6 }}
  cronjob.yaml: {{- include "zora-ai-jobs.volumes" . | nindent 10 }}
*/}}
{{- define "zora-ai-jobs.volumes" -}}
{{- $hasScriptVol := or .Values.script.content .Values.script.configMapRef.name -}}
{{- if or $hasScriptVol .Values.job.extraVolumes .Values.pvc.enabled -}}
volumes:
{{- if .Values.script.content }}
- name: script
  configMap:
    name: {{ include "zora-ai-jobs.configmapName" . }}
    defaultMode: 0755
{{- else if .Values.script.configMapRef.name }}
- name: script
  configMap:
    name: {{ .Values.script.configMapRef.name }}
    {{- $cmKey := .Values.script.configMapRef.key | default (.Values.script.scriptKey) | default "script.sh" }}
    {{- $scriptKey := .Values.script.scriptKey | default "script.sh" }}
    items:
    - key: {{ $cmKey }}
      path: {{ $scriptKey }}
    defaultMode: 0755
{{- end }}
{{- with .Values.job.extraVolumes }}
{{- toYaml . | nindent 0 }}
{{- end }}
{{- if .Values.pvc.enabled }}
- name: backup-pvc
  persistentVolumeClaim:
    claimName: {{ .Values.pvc.existingClaim | default (include "zora-ai-jobs.fullname" .) }}
{{- end }}
{{- end }}
{{- end }}
