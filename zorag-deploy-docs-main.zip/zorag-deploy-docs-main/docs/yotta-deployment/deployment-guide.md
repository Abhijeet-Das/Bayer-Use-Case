# ZORA AI — Kubernetes Deployment Guide

**Cluster:** Private Kubernetes (4 nodes)  
**Scope:** End-to-end — cluster bootstrap through application go-live

---

## PHASE 1: Cluster Foundation

Run from the master node inside `k8s-cluster-setup/`:

#### Step 1: Hostname & /etc/hosts Setup

| IP | Hostname | Role |
|----|----------|------|
| `<MASTER_IP>` | `<MASTER_HOSTNAME>` | Master |
| `<WORKER_1_IP>` | `<WORKER_1_HOSTNAME>` | Worker |
| `<WORKER_2_IP>` | `<WORKER_2_HOSTNAME>` | Worker |
| `<WORKER_3_IP>` | `<WORKER_3_HOSTNAME>` | Worker |

```bash
# Set hostname on each node
hostnamectl set-hostname <NODE_HOSTNAME>

# Add to /etc/hosts on ALL 4 nodes
cat <<EOF >> /etc/hosts
<MASTER_IP>    <MASTER_HOSTNAME>
<WORKER_1_IP>  <WORKER_1_HOSTNAME>
<WORKER_2_IP>  <WORKER_2_HOSTNAME>
<WORKER_3_IP>  <WORKER_3_HOSTNAME>
EOF
```

See [01-hostname-setup.md](k8s-cluster-setup/01-hostname-setup.md) for detailed steps.

#### Step 2: Prerequisites

```bash
bash 02-prerequisites.sh
```

#### Step 3: Flannel CNI

```bash
kubectl apply -f 03-flannel-cni.yaml
kubectl wait --for=condition=ready pod -l k8s-app=flannel-ds -n kube-flannel --timeout=300s
```

#### Step 4: CoreDNS

```bash
kubectl apply -f 04-coredns.yaml
kubectl rollout status deployment/coredns -n kube-system
```

#### Step 5: kube-proxy

```bash
kubectl apply -f 05-kube-proxy.yaml
kubectl rollout status daemonset/kube-proxy -n kube-system
```

#### Step 6: Traefik Ingress Controller

```bash
kubectl apply -f 06-traefik-ingress.yaml
kubectl rollout status deployment/traefik -n traefik
```

#### Step 7: MetalLB

```bash
bash 10-deploy-metallb-offline.sh
kubectl get svc -n traefik -o wide
# EXTERNAL-IP should show: <INGRESS_IP>
```

---

## PHASE 1.5: Jump Server DNS

Add to `/etc/hosts` on the jump server:

```bash
cat >> /etc/hosts << 'EOF'
<WORKER_1_IP>  cfo-rbac.<YOUR_DOMAIN>
<WORKER_1_IP>  cfo-rbac-api.<YOUR_DOMAIN>
<WORKER_1_IP>  cfo-rbac-api-ui.<YOUR_DOMAIN>
<WORKER_1_IP>  cfo-ai.<YOUR_DOMAIN>
<WORKER_1_IP>  zora-ai-backend.<YOUR_DOMAIN>
<WORKER_1_IP>  zora-ai-configuration-server.<YOUR_DOMAIN>
EOF
```

---

## PHASE 2: Namespace & Secrets

```bash
# Create namespace
kubectl create namespace <NAMESPACE>

# Apply secrets
kubectl apply -f cfo-deployment/secrets/zora-ai-db-users-secrets.yaml
kubectl apply -f cfo-deployment/secrets/zora-ai-k8s-secrets.yaml

# Create registry pull secret
kubectl create secret docker-registry <REGISTRY_SECRET_NAME> \
  --docker-server=<CONTAINER_REGISTRY_HOST> \
  --docker-username=<REGISTRY_USERNAME> \
  --docker-password=<REGISTRY_PASSWORD> \
  --namespace=<NAMESPACE>

# Verify
kubectl get secrets -n <NAMESPACE>
```

---

## PHASE 3: Application Deployment

**Option A — Automated (recommended):**

```bash
cd cfo-deployment/scripts
chmod +x service-deploy.sh
./service-deploy.sh
```

**Option B — Manual Helm:**

```bash
cd cfo-deployment

helm install zora-ai-postgres ./charts/zora-ai-postgres \
  --namespace <NAMESPACE> --values values/values-zora-ai-postgres.yaml
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=postgresql -n <NAMESPACE> --timeout=300s

helm install zora-ai-redis ./charts/zora-ai-redis \
  --namespace <NAMESPACE> --values values/values-zora-ai-redis.yaml
kubectl wait --for=condition=ready pod -l app.kubernetes.io/name=redis -n <NAMESPACE> --timeout=300s

helm install zora-ai-configuration-server ./charts/zora-ai-universal-chart \
  --namespace <NAMESPACE> --values values/values-zora-ai-configuration-server.yaml

helm install zora-ai-backend ./charts/zora-ai-universal-chart \
  --namespace <NAMESPACE> --values values/values-zora-ai-backend.yaml

helm install cfo-rbac-api ./charts/zora-ai-comserv-rbac-app \
  --namespace <NAMESPACE> --values values/values-zora-ai-rbac-backend.yaml

helm install cfo-rbac ./charts/zora-ai-comserv-rbac-ui \
  --namespace <NAMESPACE> --values values/values-zora-ai-rbac-frontend.yaml

helm install zora-ai-frontend ./charts/zora-ai-universal-chart \
  --namespace <NAMESPACE> --values values/values-zora-ai-frontend.yaml

helm install zora-ai-engine ./charts/zora-ai-universal-chart \
  --namespace <NAMESPACE> --values values/values-zora-ai-engine.yaml

helm install zora-ai-customer-data-server ./charts/zora-ai-universal-chart \
  --namespace <NAMESPACE> --values values/values-zora-ai-customer-data-server.yaml

helm list -n <NAMESPACE>
kubectl get pods -n <NAMESPACE> -o wide
```

---

## Credentials Reference

Fill these in your secrets files before deploying. Never commit real values to source control.

| Secret | Key | Placeholder |
|--------|-----|-------------|
| Database passwords | All role-based users | `<DB_PASSWORD>` |
| Redis password | `redis-password` | `<REDIS_PASSWORD>` |
| LLM API key | `AZURE_LLM_API_KEY` | `<LLM_API_KEY>` |
| OIDC client secret | `OIDC_CLIENTSECRET` | `<OIDC_CLIENT_SECRET>` |

To read back a deployed secret:

```bash
kubectl get secret zora-ai-engine-secrets -n <NAMESPACE> \
  -o jsonpath='{.data.AZURE_LLM_API_KEY}' | base64 -d
```
