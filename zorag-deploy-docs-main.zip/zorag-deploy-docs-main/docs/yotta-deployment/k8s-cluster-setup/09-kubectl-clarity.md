# kubectl apply — Clarity on Where to Run

## The Simple Answer

`kubectl apply` is **always run from master** — but pods land on **workers automatically**.

---

## Why Master?

`kubectl` talks to the **Kubernetes API Server** which only runs on master.
After `kubeadm init`, the kubeconfig is already set up on master — no extra steps needed.

---

## What Actually Happens When You Run kubectl apply

```
You run: kubectl apply -f 06-traefik-ingress.yaml  (on master)
                │
                ▼
        API Server (<MASTER_IP> - master)
                │
                ▼
        Scheduler decides which node gets the pods
                │
        ┌───────┼───────┐
        ▼       ▼       ▼
    worker-1 worker-2 worker-3
    (<WORKER_1_IP>) (<WORKER_2_IP>) (<WORKER_3_IP>)
    Traefik  Traefik  Traefik
    pod      pod      pod
```

---

## File-by-File Clarity

| File | kubectl run from | Pods land on |
|------|-----------------|--------------|
| `03-flannel-cni.yaml` | master | ALL nodes (DaemonSet) |
| `04-coredns.yaml` | master | master (auto by kubeadm) |
| `05-kube-proxy.yaml` | master | ALL nodes (DaemonSet) |
| `06-traefik-ingress.yaml` | master | ALL workers (DaemonSet) |
| `10-deploy-metallb-offline.sh` | master | `metallb-system` pods + LB IP allocation |
| `07-application.yaml` | master | ALL workers (spread across worker-1,2,3) |

---

## Can You Run kubectl from Other Nodes?

Yes — if you copy the kubeconfig from master:

```bash
# Run on master — copy config to a worker or jump server
scp /etc/kubernetes/admin.conf root@<WORKER_1_IP>:/root/.kube/config
scp /etc/kubernetes/admin.conf root@<WORKER_2_IP>:/root/.kube/config
scp /etc/kubernetes/admin.conf root@<WORKER_3_IP>:/root/.kube/config
```

Then `kubectl` works from that node too. But **master is the standard place** since kubeconfig is already there.

---

## Summary

| Question | Answer |
|----------|--------|
| Where do I run `kubectl apply`? | **master (`<MASTER_IP>`)** |
| Where do pods actually run? | **worker-1, worker-2, worker-3** |
| Does master run any app pods? | **No** — master only runs control plane |
| Can workers run kubectl? | **Yes** — if kubeconfig is copied |
