# Kubernetes Private Cluster — Complete Infrastructure

## Node Details

| IP | Hostname | Role |
|----|----------|------|
| `<MASTER_IP>` | `<MASTER_HOSTNAME>` | Master |
| `<WORKER_1_IP>` | `<WORKER_1_HOSTNAME>` | Worker |
| `<WORKER_2_IP>` | `<WORKER_2_HOSTNAME>` | Worker |
| `<WORKER_3_IP>` | `<WORKER_3_HOSTNAME>` | Worker |

---

## Cluster Topology

```
Jump Server (Browser Access)
        │
        │  /etc/hosts on Jump Server:
        │  <WORKER_1_IP>  cfo-rbac.<YOUR_DOMAIN>
        │  <WORKER_1_IP>  cfo-rbac-api.<YOUR_DOMAIN>
        │  <WORKER_1_IP>  cfo-rbac-api-ui.<YOUR_DOMAIN>
        │  <WORKER_1_IP>  cfo-ai.<YOUR_DOMAIN>
        │  <WORKER_1_IP>  zora-ai-backend.<YOUR_DOMAIN>
        │  <WORKER_1_IP>  zora-ai-configuration-server.<YOUR_DOMAIN>
        │
        │  https://cfo-rbac.<YOUR_DOMAIN>:32337  (RBAC - nodePort)
        │  https://cfo-ai.<YOUR_DOMAIN>:32337    (AI   - nodePort)
        ▼
┌──────────────────────────────────────────────┐
│         master (<MASTER_IP>)                 │
│  kube-apiserver, scheduler, controller-mgr   │
│  etcd, CoreDNS                               │
└──────────────┬───────────────────────────────┘
               │ Flannel CNI (10.244.0.0/16)
     ┌─────────┼──────────┐
     ▼         ▼          ▼
 worker-1   worker-2   worker-3
<W1_IP>    <W2_IP>    <W3_IP>
 kubelet    kubelet    kubelet
kube-proxy kube-proxy kube-proxy
 Traefik    ZORA AI    ZORA AI
 Ingress   Platform   Platform
            Pods       Pods
```

---

## Deployment Structure

The application deployment is handled by the **cfo-deployment** folder:

```
cfo-deployment/
├── charts/                          # Helm charts for all services
│   ├── zora-ai-postgres/           # PostgreSQL database
│   ├── zora-ai-redis/              # Redis cache
│   ├── zora-ai-universal-chart/    # Microservices template
│   ├── zora-ai-jobs/               # Job deployments
│   ├── zora-ai-comserv-rbac-app/   # RBAC backend
│   └── zora-ai-comserv-rbac-ui/    # RBAC frontend
├── values/                          # Helm values overrides
│   ├── values-zora-ai-postgres.yaml
│   ├── values-zora-ai-redis.yaml
│   ├── values-zora-ai-backend.yaml
│   ├── values-zora-ai-frontend.yaml
│   ├── values-zora-ai-engine.yaml
│   ├── values-zora-ai-customer-data-server.yaml
│   ├── values-zora-ai-configuration-server.yaml
│   ├── values-zora-agent-skills.yaml
│   └── ... (more service values)
├── secrets/                         # Kubernetes secrets
│   ├── zora-ai-db-users-secrets.yaml     # Database credentials
│   ├── zora-ai-k8s-secrets.yaml          # Platform secrets
│   └── proxy.yaml                        # Traefik middleware & ingress
└── scripts/                         # Deployment automation
    ├── service-deploy.sh            # Main deployment script (12 steps)
    └── restart-service.sh           # Service restart utility
```

---

## Deployment Order & Location

### Phase 1: Kubernetes Cluster Setup (One Time)

| Step | File | Run On | Command |
|------|------|--------|---------|
| 0 | 00-architecture.md | Reference | Read this first |
| 1 | 01-hostname-setup.md | ALL 4 nodes | Manual steps inside |
| 2 | 02-prerequisites.sh | ALL 4 nodes | `bash 02-prerequisites.sh` |
| 3 | kubeadm init | master only | See 02-prerequisites.sh bottom |
| 4 | kubeadm join | worker-1,2,3 | Command printed by kubeadm init |
| 5 | 03-flannel-cni.yaml | master only | `kubectl apply -f 03-flannel-cni.yaml` |
| 6 | 04-coredns.yaml | master only | `kubectl apply -f 04-coredns.yaml` |
| 7 | 05-kube-proxy.yaml | master only | `kubectl apply -f 05-kube-proxy.yaml` |
| 8 | 06-traefik-ingress.yaml | master only | `kubectl apply -f 06-traefik-ingress.yaml` |
| 9 | 10-deploy-metallb-offline.sh | master only | `bash 10-deploy-metallb-offline.sh` |

### Phase 2: ZORA AI Platform Deployment

| Step | Location | Command | Duration |
|------|----------|---------|----------|
| 1 | cfo-deployment/scripts/ | `./service-deploy.sh` | 15–30 min |

The `service-deploy.sh` script automates the complete 12-step deployment:

- **Step 1:** Deploy secrets (database, platform, engine keys)
- **Steps 2–11:** Deploy core services (PostgreSQL, Redis, microservices, jobs)
- **Step 12:** Deploy proxy (Traefik middleware & ingress)

### Phase 3: Validation & Access

| Step | File | Command |
|------|------|---------|
| 1 | 08-validate-and-access.sh | `bash 08-validate-and-access.sh` |

> **Note:** All `kubectl apply` commands run from the **master node**. Phase 2 also runs from master.

---

## Jump Server — /etc/hosts Setup (One Time)

```bash
cat >> /etc/hosts << 'EOF'
<WORKER_1_IP>   cfo-rbac.<YOUR_DOMAIN>
<WORKER_1_IP>   cfo-rbac-api.<YOUR_DOMAIN>
<WORKER_1_IP>   cfo-rbac-api-ui.<YOUR_DOMAIN>
<WORKER_1_IP>   cfo-ai.<YOUR_DOMAIN>
<WORKER_1_IP>   zora-ai-backend.<YOUR_DOMAIN>
<WORKER_1_IP>   zora-ai-configuration-server.<YOUR_DOMAIN>
EOF
```

You can use any worker IP — all nodes run the Traefik ingress controller.

---

## Access URLs

| Service | URL | Port |
|---------|-----|------|
| **RBAC Frontend** | `https://cfo-rbac.<YOUR_DOMAIN>:32337` | 32337 (NodePort) |
| **RBAC API** | `https://cfo-rbac-api.<YOUR_DOMAIN>` | 443 |
| **RBAC UI API** | `https://cfo-rbac-api-ui.<YOUR_DOMAIN>` | 443 |
| **AI Frontend** | `https://cfo-ai.<YOUR_DOMAIN>:32337` | 32337 (NodePort) |
| **Backend API** | `https://zora-ai-backend.<YOUR_DOMAIN>` | 443 |
| **Config Server** | `https://zora-ai-configuration-server.<YOUR_DOMAIN>` | 443 |
| **Traefik Dashboard** | `http://<WORKER_1_IP>:30900/dashboard` | 30900 |

> `cfo-rbac` and `cfo-ai` **must use port 32337** when accessed from the jump server (NodePort).

---

## Internal Kubernetes Service Names

```bash
# Database & Cache
zora-ai-postgres:5432
zora-ai-redis-master:6379

# Core Services
zora-ai-backend:8000
zora-ai-configuration-server:8080
zora-ai-customer-data-server:8080
cfo-rbac-api:80
cfo-rbac-api-ui:80
```

---

## External Authentication Services

```bash
# OIDC Provider
https://<OIDC_ISSUER_DOMAIN>/authorize
https://<OIDC_ISSUER_DOMAIN>/oauth/token
https://<OIDC_ISSUER_DOMAIN>/userinfo

# CIAM & IDP
<CIAM_BASE_URL>
<IDP_USER_LOOKUP_URL>

# Product Application URLs
<PRODUCT_APP_URL_1>
<PRODUCT_APP_URL_2>
```

---

## Kubernetes Namespace

```bash
NAMESPACE: <NAMESPACE>
```

View all ZORA AI resources:

```bash
kubectl get all -n <NAMESPACE>
kubectl get pods -n <NAMESPACE> -o wide
kubectl get svc -n <NAMESPACE>
kubectl get ingress -n <NAMESPACE>
```
