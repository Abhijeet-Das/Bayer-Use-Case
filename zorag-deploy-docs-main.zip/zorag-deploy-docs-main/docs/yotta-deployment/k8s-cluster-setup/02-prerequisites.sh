#!/bin/bash
# =============================================================
# FILE: 02-prerequisites.sh
# RUN ON: ALL 4 NODES — master, worker-1, worker-2, worker-3
#
# SSH into each node and run: bash 02-prerequisites.sh
#
#   ssh root@<MASTER_IP>    → master
#   ssh root@<WORKER_1_IP>  → worker-1
#   ssh root@<WORKER_2_IP>  → worker-2
#   ssh root@<WORKER_3_IP>  → worker-3
# =============================================================
set -euo pipefail

echo "=== [1/6] Disabling swap ==="
swapoff -a
sed -i '/ swap / s/^/#/' /etc/fstab

echo "=== [2/6] Loading kernel modules ==="
cat <<EOF | tee /etc/modules-load.d/k8s.conf
overlay
br_netfilter
EOF
modprobe overlay
modprobe br_netfilter

echo "=== [3/6] Applying sysctl params ==="
cat <<EOF | tee /etc/sysctl.d/k8s.conf
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF
sysctl --system

echo "=== [4/6] Installing containerd ==="
apt-get update -y
apt-get install -y apt-transport-https ca-certificates curl gnupg lsb-release
apt-get install -y containerd
mkdir -p /etc/containerd
containerd config default | tee /etc/containerd/config.toml
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml
systemctl enable --now containerd

echo "=== [5/6] Installing kubeadm, kubelet, kubectl ==="
# Pin to your target Kubernetes version — change v1.29 to match your cluster version
curl -fsSL https://pkgs.k8s.io/core:/stable:/v1.29/deb/Release.key | \
  gpg --dearmor -o /etc/apt/keyrings/kubernetes-apt-keyring.gpg

echo 'deb [signed-by=/etc/apt/keyrings/kubernetes-apt-keyring.gpg] https://pkgs.k8s.io/core:/stable:/v1.29/deb/ /' | \
  tee /etc/apt/sources.list.d/kubernetes.list

apt-get update -y
apt-get install -y kubelet=1.29.* kubeadm=1.29.* kubectl=1.29.*
apt-mark hold kubelet kubeadm kubectl
systemctl enable --now kubelet

echo "=== [6/6] Disabling firewall ==="
ufw disable || true

echo ""
echo "Prerequisites done on $(hostname)."
echo ""

# =============================================================
# NEXT STEP — MASTER ONLY
# Run AFTER this script completes on ALL 4 nodes
# =============================================================
#
# SSH into master:
#   ssh root@<MASTER_IP>
#
# Run kubeadm init:
#   kubeadm init \
#     --apiserver-advertise-address=<MASTER_IP> \
#     --pod-network-cidr=10.244.0.0/16 \
#     --service-cidr=10.96.0.0/12 \
#     --kubernetes-version=1.29.0
#
# Set up kubeconfig on master:
#   mkdir -p $HOME/.kube
#   cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
#   chown $(id -u):$(id -g) $HOME/.kube/config
#
# Then copy the printed kubeadm join command and run it on:
#   ssh root@<WORKER_1_IP>  (worker-1)
#   ssh root@<WORKER_2_IP>  (worker-2)
#   ssh root@<WORKER_3_IP>  (worker-3)
# =============================================================
