#!/bin/bash

# =============================================================
# FILE: 08-validate-and-access.sh
# RUN ON: master or any node with kubectl access
# COMMAND: bash 08-validate-and-access.sh
# PURPOSE: Validate ZORA AI Platform deployment
# RUN AFTER: ./service-deploy.sh completes successfully
# =============================================================

# ── Configuration ─────────────────────────────────────────────
NAMESPACE="${NAMESPACE:-cfo-app-dev}"   # override with: NAMESPACE=my-ns bash 08-validate-and-access.sh
INGRESS_IP="${INGRESS_IP:-<INGRESS_IP>}"
YOUR_DOMAIN="${YOUR_DOMAIN:-<YOUR_DOMAIN>}"

EXPECTED_SERVICES=(
    "zora-ai-postgres"
    "zora-ai-redis"
    "zora-ai-backend"
    "zora-ai-frontend"
    "zora-ai-engine"
    "zora-ai-customer-data-server"
    "zora-ai-configuration-server"
    "zora-ai-rbac-backend"
    "zora-ai-rbac-frontend"
)

echo "════════════════════════════════════════════════════════════"
echo "   ZORA AI Platform — Deployment Validation & Access"
echo "════════════════════════════════════════════════════════════"
echo

# =============================================================
# 1. CLUSTER STATUS
# =============================================================

echo "1. CLUSTER NODES"
echo "────────────────────────────────────────────────────────────"
kubectl get nodes -o wide
echo

# =============================================================
# 2. SYSTEM COMPONENTS
# =============================================================

echo "2. KUBERNETES SYSTEM PODS (kube-system namespace)"
echo "────────────────────────────────────────────────────────────"
kubectl get pods -n kube-system -o wide | grep -E "flannel|coredns|kube-proxy"
echo

# =============================================================
# 3. TRAEFIK INGRESS
# =============================================================

echo "3. TRAEFIK INGRESS CONTROLLER (traefik namespace)"
echo "────────────────────────────────────────────────────────────"
kubectl get pods -n traefik -o wide 2>/dev/null || echo "Traefik not found in traefik namespace"
echo

# =============================================================
# 4. ZORA AI PLATFORM NAMESPACE
# =============================================================

echo "4. ZORA AI NAMESPACE: $NAMESPACE"
echo "────────────────────────────────────────────────────────────"
if kubectl get ns $NAMESPACE &>/dev/null; then
    echo "  Namespace '$NAMESPACE' exists"
else
    echo "  Namespace '$NAMESPACE' NOT FOUND — deployment has not been run yet"
    exit 1
fi
echo

# =============================================================
# 5. ZORA AI PLATFORM PODS
# =============================================================

echo "5. ZORA AI PLATFORM PODS"
echo "────────────────────────────────────────────────────────────"
POD_COUNT=$(kubectl get pods -n $NAMESPACE --no-headers 2>/dev/null | wc -l)
RUNNING_COUNT=$(kubectl get pods -n $NAMESPACE --field-selector=status.phase=Running --no-headers 2>/dev/null | wc -l)

echo "Total pods: $POD_COUNT | Running: $RUNNING_COUNT"
echo
kubectl get pods -n $NAMESPACE -o wide
echo

# =============================================================
# 6. SERVICES
# =============================================================

echo "6. SERVICES IN $NAMESPACE"
echo "────────────────────────────────────────────────────────────"
kubectl get svc -n $NAMESPACE -o wide
echo

# =============================================================
# 7. DEPLOYMENTS & STATEFULSETS
# =============================================================

echo "7. DEPLOYMENTS & STATEFULSETS"
echo "────────────────────────────────────────────────────────────"
echo "Deployments:"
kubectl get deployments -n $NAMESPACE -o wide
echo
echo "StatefulSets:"
kubectl get statefulsets -n $NAMESPACE -o wide
echo

# =============================================================
# 8. JOBS
# =============================================================

echo "8. JOBS"
echo "────────────────────────────────────────────────────────────"
kubectl get jobs -n $NAMESPACE -o wide
echo

# =============================================================
# 9. SECRETS
# =============================================================

echo "9. SECRETS IN $NAMESPACE"
echo "────────────────────────────────────────────────────────────"
kubectl get secrets -n $NAMESPACE
echo

# =============================================================
# 10. INGRESS & MIDDLEWARE
# =============================================================

echo "10. INGRESS & TRAEFIK CONFIGURATION"
echo "────────────────────────────────────────────────────────────"
echo "Ingress Rules:"
kubectl get ingress -n $NAMESPACE -o wide
echo
echo "Traefik Middleware:"
kubectl get middleware -n $NAMESPACE -o wide 2>/dev/null || echo "No middleware found"
echo

# =============================================================
# 11. SERVICE READINESS CHECK
# =============================================================

echo "11. SERVICE READINESS CHECK"
echo "────────────────────────────────────────────────────────────"
FAILED_CHECKS=0

for service in "${EXPECTED_SERVICES[@]}"; do
    REPLICAS=$(kubectl get deployment $service -n $NAMESPACE -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "0")
    READY=$(kubectl get deployment $service -n $NAMESPACE -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")

    if [ "$REPLICAS" == "0" ]; then
        REPLICAS=$(kubectl get statefulset $service -n $NAMESPACE -o jsonpath='{.spec.replicas}' 2>/dev/null || echo "0")
        READY=$(kubectl get statefulset $service -n $NAMESPACE -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo "0")
    fi

    if [ "$READY" -eq "$REPLICAS" ] && [ "$REPLICAS" -gt 0 ]; then
        echo "  $service: $READY/$REPLICAS ready"
    else
        echo "  $service: $READY/$REPLICAS ready  <-- NOT READY"
        FAILED_CHECKS=$((FAILED_CHECKS + 1))
    fi
done
echo

# =============================================================
# 12. INTERNAL DNS RESOLUTION
# =============================================================

echo "12. INTERNAL DNS RESOLUTION TESTS"
echo "────────────────────────────────────────────────────────────"
for service in "zora-ai-postgres" "zora-ai-redis" "zora-ai-backend"; do
    echo "DNS test: $service.$NAMESPACE.svc.cluster.local"
    kubectl run dns-test-$service --image=busybox:1.36 --restart=Never --rm -i --quiet -- \
        sh -c "nslookup $service.$NAMESPACE.svc.cluster.local 2>&1 | grep -q 'Address' && echo '    DNS resolves' || echo '    DNS does not resolve'"
done
echo

# =============================================================
# 13. CONNECTIVITY TESTS (Internal)
# =============================================================

echo "13. CONNECTIVITY TESTS (Internal)"
echo "────────────────────────────────────────────────────────────"

echo "Testing backend service connectivity..."
kubectl run conn-test-backend --image=curlimages/curl:8.7.1 --restart=Never --rm -i --quiet -- \
    sh -c "curl -s http://zora-ai-backend:80/health 2>&1 | head -20 && echo || echo 'No response'"
echo

echo "Testing PostgreSQL connectivity..."
kubectl run conn-test-postgres --image=busybox:1.36 --restart=Never --rm -i --quiet -- \
    sh -c "timeout 3 bash -c 'echo > /dev/tcp/zora-ai-postgres/5432' 2>&1 && echo '    PostgreSQL port open' || echo '    PostgreSQL port closed'"
echo

echo "Testing Redis connectivity..."
kubectl run conn-test-redis --image=busybox:1.36 --restart=Never --rm -i --quiet -- \
    sh -c "timeout 3 bash -c 'echo > /dev/tcp/zora-ai-redis/6379' 2>&1 && echo '    Redis port open' || echo '    Redis port closed'"
echo

# =============================================================
# 14. DEPLOYMENT SUMMARY
# =============================================================

echo "════════════════════════════════════════════════════════════"
echo "   SUMMARY"
echo "════════════════════════════════════════════════════════════"

if [ $FAILED_CHECKS -eq 0 ] && [ $RUNNING_COUNT -ge 5 ]; then
    echo "  DEPLOYMENT SUCCESSFUL — all core services are running and ready"
else
    echo "  DEPLOYMENT INCOMPLETE — some services are still starting or not ready"
    echo "  Wait a few minutes and re-run this script."
fi

echo
echo "════════════════════════════════════════════════════════════"
echo "   ACCESSING THE ZORA AI PLATFORM"
echo "════════════════════════════════════════════════════════════"
echo
echo "Option 1: From jump server (with /etc/hosts configured)"
echo "  Add to jump server /etc/hosts:"
echo "    $INGRESS_IP  cfo-rbac.$YOUR_DOMAIN"
echo "    $INGRESS_IP  cfo-ai.$YOUR_DOMAIN"
echo "  Then access:"
echo "    https://cfo-rbac.$YOUR_DOMAIN:32337"
echo "    https://cfo-ai.$YOUR_DOMAIN:32337"
echo
echo "Option 2: Direct IP access (no DNS needed)"
echo "  https://$INGRESS_IP/api"
echo
echo "Option 3: Port-forward to local machine"
echo "  kubectl port-forward -n $NAMESPACE svc/zora-ai-backend 8080:80 &"
echo "  Then: http://localhost:8080"
echo
echo "════════════════════════════════════════════════════════════"
echo "   JUMP SERVER /etc/hosts — COMPLETE SET"
echo "════════════════════════════════════════════════════════════"
echo
echo "  $INGRESS_IP  cfo-rbac.$YOUR_DOMAIN"
echo "  $INGRESS_IP  cfo-rbac-api.$YOUR_DOMAIN"
echo "  $INGRESS_IP  cfo-rbac-api-ui.$YOUR_DOMAIN"
echo "  $INGRESS_IP  cfo-ai.$YOUR_DOMAIN"
echo "  $INGRESS_IP  zora-ai-backend.$YOUR_DOMAIN"
echo "  $INGRESS_IP  zora-ai-configuration-server.$YOUR_DOMAIN"
echo
echo "════════════════════════════════════════════════════════════"
echo "   AVAILABLE URLs (with /etc/hosts setup)"
echo "════════════════════════════════════════════════════════════"
echo
echo "  RBAC Frontend:  https://cfo-rbac.$YOUR_DOMAIN:32337"
echo "  RBAC API:       https://cfo-rbac-api.$YOUR_DOMAIN"
echo "  RBAC UI:        https://cfo-rbac-api-ui.$YOUR_DOMAIN"
echo "  AI Frontend:    https://cfo-ai.$YOUR_DOMAIN:32337"
echo "  Backend API:    https://zora-ai-backend.$YOUR_DOMAIN"
echo "  Config Server:  https://zora-ai-configuration-server.$YOUR_DOMAIN"
echo
echo "════════════════════════════════════════════════════════════"
echo "   INTERNAL KUBERNETES SERVICE NAMES"
echo "════════════════════════════════════════════════════════════"
echo
echo "  zora-ai-postgres:5432"
echo "  zora-ai-redis-master:6379"
echo "  zora-ai-backend:8000"
echo "  zora-ai-configuration-server:8080"
echo "  zora-ai-customer-data-server:8080"
echo "  cfo-rbac-api:8000"
echo
echo "════════════════════════════════════════════════════════════"
echo "   USEFUL COMMANDS"
echo "════════════════════════════════════════════════════════════"
echo
echo "  kubectl logs <pod-name> -n $NAMESPACE"
echo "  kubectl logs -f <pod-name> -n $NAMESPACE"
echo "  kubectl describe pod <pod-name> -n $NAMESPACE"
echo "  kubectl get pods -n $NAMESPACE -w"
echo "  kubectl get events -n $NAMESPACE --sort-by='.lastTimestamp'"
echo "  helm list -n $NAMESPACE"
echo "  helm status <release-name> -n $NAMESPACE"
echo "  kubectl rollout restart deployment/<name> -n $NAMESPACE"
echo
echo "════════════════════════════════════════════════════════════"
