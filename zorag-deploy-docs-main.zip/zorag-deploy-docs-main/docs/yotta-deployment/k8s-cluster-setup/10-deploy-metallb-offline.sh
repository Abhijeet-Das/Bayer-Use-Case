#!/bin/bash

# =============================================================
# FILE: 10-deploy-metallb-offline.sh
# PURPOSE: Deploy MetalLB from local manifest (no internet required)
# RUN ON: Master node
# USAGE: bash 10-deploy-metallb-offline.sh
#
# Before running:
#   Edit metallb-complete.yaml → set the IPAddressPool addresses
#   to a free IP range on your network (e.g. <INGRESS_IP>-<INGRESS_IP>)
# =============================================================

set -e

echo "════════════════════════════════════════════════════════════════════════"
echo "      DEPLOYING METALLB (OFFLINE) — NO INTERNET REQUIRED"
echo "════════════════════════════════════════════════════════════════════════"
echo ""

# ── Step 1: Deploy Complete MetalLB Manifest ─────────────────────────────
echo "1. Deploying MetalLB from local manifest..."
echo "   (No internet required)"

kubectl apply -f metallb-complete.yaml

echo "   MetalLB manifest applied (CRDs + infrastructure)"
echo ""

# ── Step 1b: Wait for CRDs to register ───────────────────────────────────
echo "1b. Waiting for CRDs to register in API server..."
echo "    (Critical — avoids 'no matches for kind' errors)"

for i in {1..60}; do
  if kubectl get crd ipaddresspools.metallb.io &>/dev/null && \
     kubectl get crd l2advertisements.metallb.io &>/dev/null; then
    echo "    CRDs registered!"
    break
  fi
  if [ $((i % 5)) -eq 0 ]; then
    echo "    Waiting... (attempt $i/60)"
  fi
  sleep 1
done

sleep 3

echo "    Re-applying manifest to create config resources..."
kubectl apply -f metallb-complete.yaml

echo "    MetalLB config resources applied"
echo ""

# ── Step 2: Wait for MetalLB Pods ────────────────────────────────────────
echo "2. Waiting for MetalLB pods to be ready (30-60 seconds)..."

kubectl wait --for=condition=ready pod \
  -l app.kubernetes.io/name=metallb \
  -n metallb-system \
  --timeout=300s 2>/dev/null || true

echo "   MetalLB pods ready"
echo ""

# ── Step 3: Verify All Resources ─────────────────────────────────────────
echo "3. Verifying MetalLB resources..."
echo ""

echo "   MetalLB Pods:"
kubectl get pods -n metallb-system --no-headers | sed 's/^/      /'
echo ""

echo "   IPAddressPool:"
kubectl get ipaddresspool -n metallb-system --no-headers | sed 's/^/      /'
echo ""

echo "   L2Advertisement:"
kubectl get l2advertisement -n metallb-system --no-headers | sed 's/^/      /'
echo ""

# ── Step 4: Check External IP Assignment ─────────────────────────────────
echo "4. Checking Traefik external IP assignment..."
echo ""

kubectl get svc -n traefik -o wide

echo ""

EXTERNAL_IP=$(kubectl get svc traefik -n traefik -o jsonpath='{.status.loadBalancer.ingress[0].ip}' 2>/dev/null || echo "PENDING")

if [ "$EXTERNAL_IP" != "PENDING" ] && [ -n "$EXTERNAL_IP" ]; then
  echo "   External IP assigned: $EXTERNAL_IP"
else
  echo "   External IP still pending (may take 1-2 minutes)"
  echo "   Check with: kubectl get svc -n traefik -o wide"
fi

echo ""

# ── Step 5: Next Steps ────────────────────────────────────────────────────
echo "════════════════════════════════════════════════════════════════════════"
echo "      METALLB DEPLOYMENT COMPLETE"
echo "════════════════════════════════════════════════════════════════════════"
echo ""

echo "NEXT STEPS:"
echo ""

echo "1. CONFIGURE JUMP SERVER /etc/hosts:"
echo "   Add to /etc/hosts on your jump server:"
echo ""
echo "   <INGRESS_IP>  cfo-rbac.<YOUR_DOMAIN>"
echo "   <INGRESS_IP>  cfo-rbac-api.<YOUR_DOMAIN>"
echo "   <INGRESS_IP>  cfo-rbac-api-ui.<YOUR_DOMAIN>"
echo "   <INGRESS_IP>  cfo-ai.<YOUR_DOMAIN>"
echo "   <INGRESS_IP>  zora-ai-backend.<YOUR_DOMAIN>"
echo "   <INGRESS_IP>  zora-ai-configuration-server.<YOUR_DOMAIN>"
echo ""

echo "2. DEPLOY APPLICATION:"
echo "   cd ../cfo-deployment/scripts"
echo "   ./service-deploy.sh"
echo ""

echo "3. ACCESS FROM JUMP SERVER (after /etc/hosts is set):"
echo "   https://cfo-rbac.<YOUR_DOMAIN>:32337"
echo "   https://cfo-ai.<YOUR_DOMAIN>:32337"
echo ""

echo "4. TRAEFIK DASHBOARD:"
echo "   http://<INGRESS_IP>:9000/dashboard/"
echo ""

echo "════════════════════════════════════════════════════════════════════════"
