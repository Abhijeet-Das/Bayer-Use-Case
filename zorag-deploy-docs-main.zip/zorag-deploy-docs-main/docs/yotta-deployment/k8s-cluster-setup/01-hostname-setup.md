# Hostname & /etc/hosts Setup

## Node IPs & Hostnames

Replace the values below with your actual node IPs and hostnames before running any commands.

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `<MASTER_IP>` | Master node IP | `192.168.10.10` |
| `<WORKER_1_IP>` | Worker 1 node IP | `192.168.10.11` |
| `<WORKER_2_IP>` | Worker 2 node IP | `192.168.10.12` |
| `<WORKER_3_IP>` | Worker 3 node IP | `192.168.10.13` |

---

## Step 1 — Set Hostname on Each Node

SSH into each node and run individually:

**On master (`<MASTER_IP>`):**
```bash
hostnamectl set-hostname master
```

**On worker-1 (`<WORKER_1_IP>`):**
```bash
hostnamectl set-hostname worker-1
```

**On worker-2 (`<WORKER_2_IP>`):**
```bash
hostnamectl set-hostname worker-2
```

**On worker-3 (`<WORKER_3_IP>`):**
```bash
hostnamectl set-hostname worker-3
```

---

## Step 2 — Add /etc/hosts on ALL 4 Nodes

Run this **same block on every node** — master, worker-1, worker-2, worker-3:

```bash
cat <<EOF >> /etc/hosts
<MASTER_IP>    master
<WORKER_1_IP>  worker-1
<WORKER_2_IP>  worker-2
<WORKER_3_IP>  worker-3
EOF
```

---

## Step 3 — Verify on Each Node

```bash
# Check hostname is set correctly
hostname

# Check /etc/hosts looks correct
cat /etc/hosts

# Ping all nodes by name
ping -c 2 master
ping -c 2 worker-1
ping -c 2 worker-2
ping -c 2 worker-3
```

---

## Summary — Who Runs What

| Node     | Step 1 — Set Hostname | Step 2 — /etc/hosts |
|----------|-----------------------|----------------------|
| master   | `hostnamectl set-hostname master` | All 4 nodes |
| worker-1 | `hostnamectl set-hostname worker-1` | All 4 nodes |
| worker-2 | `hostnamectl set-hostname worker-2` | All 4 nodes |
| worker-3 | `hostnamectl set-hostname worker-3` | All 4 nodes |

> Every node must have all 4 IPs in `/etc/hosts` before running `02-prerequisites.sh`.

---

## Next Step

Once hostnames and /etc/hosts are done on all 4 nodes, proceed to:

```bash
bash 02-prerequisites.sh   # run on each node one by one
```
