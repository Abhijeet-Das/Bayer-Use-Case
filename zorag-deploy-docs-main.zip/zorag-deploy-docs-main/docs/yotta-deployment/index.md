# ZORA AI Platform — Private Kubernetes Deployment

This section covers deploying the ZORA AI Platform on a **private, air-gapped-style Kubernetes cluster** — typically used for on-premises or data-centre environments where internet access is restricted or absent.

---

## Overview

| Phase | What | Duration |
|-------|------|----------|
| **Phase 1** | Kubernetes cluster foundation | One-time setup |
| **Phase 1.5** | Jump server DNS configuration | One-time setup |
| **Phase 2** | ZORA AI platform deployment | 15–30 min per release |
| **Phase 3** | Validation & access | < 5 min |

---

## Cluster Topology

A typical deployment uses **4 nodes**: one master and three workers.

```
Jump Server / Browser Client
        │
        │  /etc/hosts  →  <INGRESS_IP>  <YOUR_DOMAIN> subdomains
        │
        │  https://cfo-rbac.<YOUR_DOMAIN>:32337   (RBAC – NodePort)
        │  https://cfo-ai.<YOUR_DOMAIN>:32337     (AI   – NodePort)
        ▼
┌─────────────────────────────────────────────────┐
│           master (<MASTER_IP>)                  │
│  kube-apiserver · scheduler · controller-mgr   │
│  etcd · CoreDNS                                │
└──────────────┬──────────────────────────────────┘
               │  Flannel CNI (10.244.0.0/16)
      ┌────────┼────────┐
      ▼        ▼        ▼
  worker-1  worker-2  worker-3
  kubelet   kubelet   kubelet
  kube-proxy kube-proxy kube-proxy
  Traefik   ZORA AI   ZORA AI
  Ingress   Pods      Pods
```

---

## Placeholder Reference

Replace every placeholder below with your actual values before starting.

| Placeholder | Description | Example |
|-------------|-------------|---------|
| `<MASTER_IP>` | Master node IP | `192.168.10.10` |
| `<WORKER_1_IP>` | First worker node IP | `192.168.10.11` |
| `<WORKER_2_IP>` | Second worker node IP | `192.168.10.12` |
| `<WORKER_3_IP>` | Third worker node IP | `192.168.10.13` |
| `<INGRESS_IP>` | MetalLB / Traefik external IP (typically worker-1) | `192.168.10.11` |
| `<MASTER_HOSTNAME>` | Master hostname | `k8s-master` |
| `<WORKER_1_HOSTNAME>` | Worker 1 hostname | `k8s-worker-1` |
| `<WORKER_2_HOSTNAME>` | Worker 2 hostname | `k8s-worker-2` |
| `<WORKER_3_HOSTNAME>` | Worker 3 hostname | `k8s-worker-3` |
| `<YOUR_DOMAIN>` | Base domain for all service URLs | `cfo.example.com` |
| `<NAMESPACE>` | Kubernetes namespace for ZORA AI | `cfo-app-dev` |
| `<CONTAINER_REGISTRY>` | Docker/OCI registry host | `registry.example.com` |
| `<REGISTRY_SECRET_NAME>` | Name of the registry pull secret | `registry-secret` |
| `<REGISTRY_USERNAME>` | Registry login username | `deploy-user` |
| `<REGISTRY_PASSWORD>` | Registry login password | — |
| `<IMAGE_TAG>` | ZORA AI image tag to deploy | `v2.1.1` |
| `<TLS_SECRET_NAME>` | Wildcard TLS secret in Kubernetes | `wildcard-tls` |
| `<LLM_ENDPOINT_URL>` | Base URL of the LLM inference service | `https://llm.example.com` |
| `<LLM_API_KEY>` | API key for the LLM service | — |
| `<LLM_MODEL_NAME>` | LLM model identifier | `gpt-4o` |
| `<OIDC_ISSUER_DOMAIN>` | OIDC / Auth0 tenant domain | `tenant.auth0.com` |
| `<OIDC_CLIENT_ID>` | OIDC application client ID | — |
| `<OIDC_CLIENT_SECRET>` | OIDC application client secret | — |
| `<DB_PASSWORD>` | Password for all database service accounts | — |
| `<REDIS_PASSWORD>` | Password for Redis | — |
| `<STORAGE_CLASS>` | Kubernetes storage class for PVCs | `standard` |

---

## DNS Reference

### Jump Server `/etc/hosts`

```
<INGRESS_IP>  cfo-rbac.<YOUR_DOMAIN>
<INGRESS_IP>  cfo-rbac-api.<YOUR_DOMAIN>
<INGRESS_IP>  cfo-rbac-api-ui.<YOUR_DOMAIN>
<INGRESS_IP>  cfo-ai.<YOUR_DOMAIN>
<INGRESS_IP>  zora-ai-backend.<YOUR_DOMAIN>
<INGRESS_IP>  zora-ai-configuration-server.<YOUR_DOMAIN>
```

### Service Access URLs

| Service | URL | Notes |
|---------|-----|-------|
| AI Frontend | `https://cfo-ai.<YOUR_DOMAIN>:32337` | NodePort — use port 32337 from jump server |
| RBAC Frontend | `https://cfo-rbac.<YOUR_DOMAIN>:32337` | NodePort — use port 32337 from jump server |
| RBAC API | `https://cfo-rbac-api.<YOUR_DOMAIN>` | Standard HTTPS |
| RBAC UI API | `https://cfo-rbac-api-ui.<YOUR_DOMAIN>` | Standard HTTPS |
| Backend API | `https://zora-ai-backend.<YOUR_DOMAIN>` | Standard HTTPS |
| Config Server | `https://zora-ai-configuration-server.<YOUR_DOMAIN>` | Standard HTTPS |
| Traefik Dashboard | `http://<INGRESS_IP>:30900/dashboard` | Internal access only |

### Internal Kubernetes Service Names

```
zora-ai-postgres:5432
zora-ai-redis-master:6379
zora-ai-backend:8000
zora-ai-configuration-server:8080
zora-ai-customer-data-server:8080
cfo-rbac-api:80
cfo-rbac-api-ui:80
```

---

## External Integrations

| Service | Purpose | Placeholder |
|---------|---------|-------------|
| OIDC / Auth0 | User authentication | `<OIDC_ISSUER_DOMAIN>` |
| CIAM API | Identity management | configure in RBAC values |
| LLM Inference | AI Engine queries | `<LLM_ENDPOINT_URL>` |
| Container Registry | Image pulls | `<CONTAINER_REGISTRY>` |

---

**Next:** [Deployment Guide →](deployment-guide.md)
