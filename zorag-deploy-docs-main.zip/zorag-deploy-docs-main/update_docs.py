#!/usr/bin/env python

# This script is used to update the mkdocs.yml file with the correct repo name and org name
import os
import subprocess


def get_git_repo_name():
    # Get the current working directory

    git_repo_output = subprocess.run(
        ["git", "config", "--get", "remote.origin.url"],
        text=True,
        capture_output=True,
    )

    if git_repo_output.returncode != 0:
        raise Exception("Could not get git repo url")
    return git_repo_output.stdout.strip()


def update_mkdocs_data():
    git_repo_url = get_git_repo_name()
    base_repo_name = git_repo_url.split("/")[-1].replace(".git", "")
    base_org_name = git_repo_url.split("/")[-2]

    cwd = os.getcwd()
    mkdocs_file = os.path.join(cwd, "mkdocs.yml")
    template_pages_url = "https://Deloitte-US-Engineering.github.io/mkdocs-template"
    template_repo_url = "https://github.com/Deloitte-US-Engineering/mkdocs-template.git"
    template_edit_url = (
        "https://github.com/Deloitte-US-Engineering/mkdocs-template/edit"
    )

    replace_map = {
        template_repo_url: git_repo_url,
        template_edit_url: "https://github.com/"
        + base_org_name
        + "/"
        + base_repo_name
        + "/edit",
        template_pages_url: "https://" + base_org_name + ".github.io/" + base_repo_name,
    }
    replace_lines = []

    with open(mkdocs_file, "r") as f:
        # we are opening as normal text to avoid interpreting the file as yaml
        lines = f.readlines()
        for line in lines:
            cleaned_line = "" + line
            for url in replace_map.keys():
                if url in cleaned_line:
                    cleaned_line = cleaned_line.replace(url, replace_map[url])
            replace_lines.append(cleaned_line)

    with open(mkdocs_file, "w") as f:
        f.writelines(replace_lines)


def commit_mkdocs_changes():
    git_repo_output = subprocess.run(
        ["git", "add", "mkdocs.yml"],
        text=True,
        capture_output=True,
    )

    if git_repo_output.returncode != 0:
        raise Exception("Could not add mkdocs.yml to git")

    git_repo_output = subprocess.run(
        [
            "git",
            "commit",
            "-m",
            "docs: Update mkdocs.yml to reflect repo name and org name",
        ],
        text=True,
        capture_output=True,
    )

    if git_repo_output.returncode != 0:
        raise Exception("Could not commit mkdocs.yml to git")

    git_repo_output = subprocess.run(
        ["git", "push"],
        text=True,
        capture_output=True,
    )

    if git_repo_output.returncode != 0:
        raise Exception("Could not push mkdocs.yml to git")


if __name__ == "__main__":
    update_mkdocs_data()
    commit_mkdocs_changes()
