# Zora AI Deployments

Production-ready Helm charts and values files for deploying Zora AI applications on Kubernetes.

---

## Table of Contents

- [Overview](#overview)
- [Repository Structure](#repository-structure)
- [Deployment Guides](#deployment-guides)
- [Helm Charts](#helm-charts)
- [Prerequisites](#prerequisites)
- [Quick Start](#quick-start)

---

## Overview

This repository contains:

- **Helm Charts** — Reusable Kubernetes deployment templates
- **Values Files** — Environment-specific configurations for CFO and EM deployments
- **Deployment Guides** — Step-by-step instructions for production deployment
- **Automation Scripts** — Python scripts for downloading and deploying services

---

## Repository Structure

```
aiq-deploy-docs/
├── cfo-deployment/                 # CFO deployment guide and scripts
│   ├── CFO_Deployment_Guide.md
│   └── download_and_extract_values.py
└── kubernetes/
    ├── charts/                     # Shared Helm charts
    │   ├── aiq-ext-postgres/       # PostgreSQL database chart
    │   ├── aiq-ext-service/        # Generic service chart
    │   ├── zora-ai-comserv-rbac-app/   # RBAC backend service
    │   ├── zora-ai-comserv-rbac-ui/    # RBAC frontend service
    │   ├── zora-ai-jobs/           # Kubernetes jobs (DB init, etc.)
    │   ├── zora-ai-postgres/       # PostgreSQL for Zora AI
    │   ├── zora-ai-redis/          # Redis cache service
    │   └── zora-ai-universal-chart/    # Universal chart for all apps
    ├── cfo-values/                 # CFO environment values files
    │   ├── values-zora-agent-skills.yaml
    │   ├── values-zora-ai-backend.yaml
    │   ├── values-zora-ai-configuration-server.yaml
    │   ├── values-zora-ai-customer-data-server.yaml
    │   ├── values-zora-ai-engine.yaml
    │   ├── values-zora-ai-frontend.yaml
    │   ├── values-zora-ai-postgres.yaml
    │   ├── values-zora-ai-rbac-backend.yaml
    │   ├── values-zora-ai-rbac-frontend.yaml
    │   ├── values-zora-ai-redis.yaml
    │   └── cfo_end-to-end_deployment.py
```

---

## Deployment Guides

| Application | Guide | Description |
|-------------|-------|-------------|
| **CFO** | [CFO_Deployment_Guide.md](cfo-deployment/CFO_Deployment_Guide.md) | Full deployment guide for Zora AI (CFO) |

---

## Helm Charts

| Chart | Description |
|-------|-------------|
| `zora-ai-universal-chart` | Universal chart supporting all Zora AI applications |
| `zora-ai-postgres` | PostgreSQL for Zora AI services |
| `zora-ai-redis` | Redis cache and session store |
| `zora-ai-comserv-rbac-app` | RBAC backend API service |
| `zora-ai-comserv-rbac-ui` | RBAC frontend UI service |
| `zora-ai-jobs` | One-time Kubernetes jobs (DB initialization) |

---

## Prerequisites

- Kubernetes cluster (v1.19+)
- kubectl CLI (v1.19+)
- Helm CLI (v3.8+)
- Python 3
- JFrog credentials (username and API token)
- Ingress Controller or Application Gateway
- StorageClass configured for persistent volumes
- SSL/TLS certificates for HTTPS endpoints

---

## Quick Start

### 1. Clone the Repository

```bash
git clone https://github.com/Deloitte-US-Innovation-Technology/zorag-deploy-docs.git
cd zorag-deploy-docs
```

### 2. Choose Deployment Type

**For Zora AI (CFO) Deployment:**
```bash
cd cfo-deployment
# Follow CFO_Deployment_Guide.md
```

### 3. Configure Credentials

Update the download script with your JFrog credentials:
```python
EDGE_USER = "your-username"
EDGE_TOKEN = "your-api-token"
ARTIFACT_PATH = "path/to/values"
```

### 4. Deploy

```bash
python3 download_and_extract_values.py
# Follow the deployment guide for your application
```

---

## License

Internal use only — Deloitte US Innovation & Technology

