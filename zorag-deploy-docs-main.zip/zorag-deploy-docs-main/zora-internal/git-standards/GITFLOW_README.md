# Zora Git Standard Workflow

This document describes the Git branching and release strategy used across Zora AI service repositories.

![Zora Git Workflow](./zora-git-workflow.svg)

---

## Overview

The workflow is divided into three phases:

| Phase | Who | What happens |
|---|---|---|
| **Creating a Feature** | Developer | Work is scoped, branched, reviewed, and merged to `develop` |
| **Creating a Release** | Developer + GitHub Actions | A release branch is created and bumping the version on it triggers GitHub Actions, which opens a PR in the `aiq-service` repo |
| **Approval & Release** | GitHub Actions + QA | The AI-Automations repo is updated with the RC image tag, the manifest PR is reviewed and approved, QA validates, the manifest is updated again with the stable tag, a final **PR Validate & Approval** gate merges `release/*` to both `develop` and `main`, and an official `release/*` tag is cut |

---

## Branch Structure

| Branch | Purpose |
|---|---|
| `main` | Stable production-ready code. Only receives merges from approved release PRs. |
| `develop` | Integration branch. All feature work targets this branch. |
| `feature/<name>` | Short-lived branch for a single Jira story or task. Branched from and merged back to `develop`. |
| `release/va.b.c` | Release stabilization branch. Branched from `develop` when a release is being prepared. |

---

## Phase 1 — Creating a Feature

```
develop → feature/<name> → (PR) → develop
```

1. **Create a Jira Story Ticket** — All work begins with a tracked Jira story.
2. **Create a feature branch** — Branch off `develop` using the naming convention `feature/<name>`.
3. **Develop & commit changes** — Work is done locally and pushed to the feature branch.
4. **Open a Pull Request** — A PR is opened targeting `develop`.
5. **PR Review & Approval** — At least one peer review is required before merging.
6. **Merge to `develop`** — Once approved, the feature branch is merged into `develop` and the branch is deleted.

> Feature branches are short-lived and should not be kept open longer than necessary.

---

## Phase 2 — Creating a Release

```
develop → release/va.b.c → bump version on release/* → GitHub Actions → aiq-service Repo PR
```

1. **Create a release branch** — Branch `release/va.b.c` from `develop` when the set of features for this version is complete.
2. **Bump the version on the `release/*` branch** — Update the version in the relevant files to `va.b.c-rc.1` and commit directly to the `release/*` branch. **This commit is the trigger for automation** — there is no separate manual tag push step.
3. **GitHub Actions takes over** — The version-bump commit on the `release/*` branch triggers a GitHub Actions workflow that:
   - Builds and publishes the release candidate image
   - Opens a Pull Request in the **`aiq-service` repo** (RC version `va.b.c-rc.1`) targeting `main`

> The previous "Create & push the release tag" step has been removed. GitHub Actions now triggers off of the `release/*` branch directly. The official `va.b.c` tag is still created automatically at the end of Phase 3.

---

## Phase 3 — Approval & Release

```
aiq-service Repo PR → Update AI-Automations repo (RC tag) → PR Review & Approval → QA validation
  → Update AI-Automations repo (stable tag) → PR Validate & Approval → merge release/* to develop & main → official release/* tag
```

1. **Update AI-Automations repo `main` with the `aiq-service` `release/*` image tag** — The AI-Automations repo `main` is updated with the new `release/*` image tag so the deployment manifests reference the RC build.
2. **PR Review & Approval (manifest PR)** — The manifest update PR in the AI-Automations repo is peer-reviewed and approved before QA deploys.
3. **QA deploys and tests** — QA deploys the updated manifests and validates the environment. The deployed version may be a release candidate `va.b.c-rc.N` or a stable `va.b.c` build.
4. **QA Passes?**
   - **No** — QA sends the `release/*` branch back for a fix. A `release/*` branch fix commit **updates the existing `aiq-service` PR** (rather than opening a new one); flow returns to the AI-Automations manifest update step for re-test.
   - **Yes** — Continue to final approval.
5. **Update AI-Automations repo `main` with the stable `aiq-service` `release/*` image tag** — Once QA passes, the AI-Automations repo `main` is updated again with the final stable `release/*` image tag.
6. **PR Validate & Approval** — A final validation/approval gate confirms the release is ready to merge.
7. **Merge `release/*` to `develop` and `main`** — On approval, the `release/*` branch is merged into both `develop` (to keep integration current) and `main` (to publish the release).
8. **Official `release/*` tag cut** — GitHub Actions tags the merged `main` commit with the final `release/*` version (no `-rc` suffix), marking the official release.

---

## RC Iteration Loop

If QA finds issues, the process loops:

```
release/va.b.c → release/* branch fix (bump va.b.c-rc.N+1) → updates existing aiq-service PR → AI-Automations updated → QA retests
```

There is no limit on the number of RC iterations. Each fix commit on the `release/*` branch produces a new RC build and **updates the existing `aiq-service` PR** in place — a new PR is not opened for each iteration.

---

## Naming Conventions

| Artifact | Format | Example |
|---|---|---|
| Feature branch | `feature/<jira-id-or-description>` | `feature/ZORA-123-login-fix` |
| Release branch | `release/va.b.c` | `release/v1.4.0` |
| Release candidate tag | `va.b.c-rc.N` | `v1.4.0-rc.1` |
| Official release tag | `va.b.c` | `v1.4.0` |

---

## Key Rules

- **Never commit directly to `main` or `develop`** — all changes go through PRs.
- **Feature branches always target `develop`**, never `main` or a release branch.
- **Release branches are created from `develop`** only when the feature set for that version is stable.
- **Commits to `release/*` drive automation** — bumping the version (or pushing a fix) on a `release/*` branch is what triggers GitHub Actions; do not push RC tags manually and do not run the pipeline manually.
- **RC fixes update the existing `aiq-service` PR** — do not open a new PR for each RC iteration.
- **The official `release/*` tag is created by GitHub Actions** after the final **PR Validate & Approval** gate and the merge of `release/*` to `main` — do not create it manually.

