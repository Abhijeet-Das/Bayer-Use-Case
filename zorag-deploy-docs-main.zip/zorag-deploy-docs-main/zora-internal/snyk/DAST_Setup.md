# Snyk DAST Scan

## Prerequisites

1. Connect to GP VPN.
2. Ensure you have write access to the target repository.

## Overview

Snyk DAST can be set up for deployed web applications and APIs. It is best suited for applications with accessible web front ends. Separate backend setup is typically not required because Snyk dynamically crawls and tests the application.

It performs testing in live environments to identify issues such as:

- SQL injection
- Cross-site scripting (XSS)
- Authentication flaws
- Misconfigurations

## How to Submit DAST Scan Request

### Step 1: Open the Automated Application Testing Request

Open the **Automated Application Testing** request form in ServiceNow.

[Automated Application Testing - Snyk Onboarding Form - My Support Global](https://deloitteglobal.service-now.com/mysupport?id=sc_cat_item&sys_id=7d8530298328225010421b747daad351)

### Step 2: Fill in ServiceNow Request Details

Complete the required ServiceNow fields using the application, ownership, and DAST access details.

**Sample values:**
- `Requested For: xxx@deloitte.com`
- `Watch List: xxx@deloitte.com, yyy@deloitte.com`
- `Deloitte Member Firm: Deloitte United States`
- `Deloitte Member Firm Territory: United States of America`
- `Application not Found: Checked`
- `Application Name: Zora AI`
- `Service Line: Consulting`
- `Application ID: App54650`
- `Application Owner: Jinlei Liu`
- `Application Owner Email: jinlliu@deloitte.com`
- `Business Criticality: Medium`
- `Integrations: No`
- `Interfaces: Internal`
- `Charge Code: FPE12681-01-26-01-2101`
- `Charge Code Owner: Jinlei Liu`
- `Charge Code Owner Email: jinlliu@deloitte.com`
- `Scan Type: DAST`
- `Component Name: zora-ai-frontend`
- `DAST Type: Web`
- `Web Server IP Address: https://zoraai-emv2.dev02.zoraai.deloitteinnovation.us/`
- `Application Base URL: https://zoraai-emv2.dev02.zoraai.deloitteinnovation.us/`
- `Developers: xxx@deloitte.com, yyy@deloitte.com`
- `Normal Users: xxx@deloitte.com`
- `View Only Users: xxx@deloitte.com`
- `Additional Comments: You can add the sample values in comment.`

**Notes:**
- Use email IDs for `Requested For`, `Watch List`, `Developers`, `Normal Users`, and `View Only Users`.
- The charge code should validate successfully before you proceed.
- Enter `Component Name` only if the web application has multiple components that need separate scope.
- Select the appropriate `DAST Type` based on whether the target is a web application or API.
- Ensure the `Web Server IP Address` or endpoint allows connectivity from the required scanning source based on the selected interface.

### Step 3: Submit the Request

Use one of the available actions:

- **Save as Draft** if the request is not ready
- **Order Now** to submit the request

## Post-Submission Steps

### Step 4: Wait for Target ID Creation

After submitting the ServiceNow ticket, the AAT team will create a Target ID for the application.

### Step 5: Send an Email to the AAT Team for API Key

Send an email to `automatedapplicationtesting@deloitte.com` requesting the API key for the created target.

Use this email template:

```text
Hi Team,

Could you please help with the API key for the following target?

Target: XXXXX
Target URL: XXXXXX

Regards,
Your Name
```

### Step 6: Request IP Whitelisting and Host Entry

Ask `vimg@deloitte.com` to whitelist `10.183.106.0/26` over port `443` for the application endpoint used in the DAST scan.

After whitelisting, Ask `sushbehera@deloitte.com` to add the host entry in snyk.

### Step 7: Ask Developers to Set Up the Login Process

Ask developers to set up the application login process required for DAST scanning.

### Step 8: Store the Target ID in Doppler

Add the Target ID to Doppler as a secret. Keep the secret name unique.

Also add the Probely API key secret in Doppler. Keep both secret names unique.

## Repository Setup

### Step 9: Add the GitHub Actions Workflow

Once the Target ID is added in Doppler, go to the repository where the DAST scan needs to be configured.

Create a new branch and add a new workflow file named `.github/workflows/dast.yml`.

Before using the workflow:

- Update the push branch to the branch that should trigger the workflow.
- Replace `probely-api-key` and `probely-target-id` with the correct unique secret names from Doppler for your application.

#### Sample Workflow

```yaml
name: DAST Scan (Probely)

on:
  push:
    # Add the branches that should trigger this workflow.
    branches:
      - qa
  workflow_dispatch:

permissions:
  contents: read

jobs:
  dast-scan:
    name: Probely DAST Scan
    runs-on: ubuntu-latest

    steps:
      - name: Checkout
        uses: actions/checkout@v4

      - name: Run Probely DAST scan
        id: dast
        uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/dast-scan@main
        with:
          probely-api-key: ${{ secrets.PROBELY_API_KEY }}
          probely-target-id: ${{ secrets.ZORAAI_FRONTEND_PROBELY_TARGET_ID }}
          probely-ui-base-url: https://plus.probely.app
          fail-on-high: "true"
          fail-on-medium: "false"
          fail-on-low: "false"

      - name: Print DAST summary
        if: always()
        run: |
          echo "Scan ID: ${{ steps.dast.outputs.scan-id }}"
          echo "Scan status: ${{ steps.dast.outputs.scan-status }}"
          echo "Core UI: ${{ steps.dast.outputs.core-ui-url }}"
          echo "Critical findings: ${{ steps.dast.outputs.critical-count }}"
          echo "High findings: ${{ steps.dast.outputs.high-count }}"
          echo "Medium findings: ${{ steps.dast.outputs.medium-count }}"
          echo "Low findings: ${{ steps.dast.outputs.low-count }}"
          echo "Total findings: ${{ steps.dast.outputs.total-findings }}"
```

### Step 10: Run the Workflow

Trigger the workflow by either:

- Pushing to the configured branch
- Running it manually through `workflow_dispatch`

### Step 11: Review the Scan Output

Review the pipeline summary for:

- Scan ID
- Scan status
- Core UI URL
- Critical findings
- High findings
- Medium findings
- Low findings
- Total findings

### Step 12: Download the Report

Once the pipeline is complete, download the DAST scan report.

## Save, commit, push, and create PR to main

After adding the workflow file:

```bash
git add .github/workflows/dast.yml
git commit -m "Add DAST scan workflow"
git push -u origin feature/add-dast-scan
```

Open a PR to main and assign a maintainer for approval.

After merge, run the workflow and validate that the DAST scan is running properly and the results are stored correctly.