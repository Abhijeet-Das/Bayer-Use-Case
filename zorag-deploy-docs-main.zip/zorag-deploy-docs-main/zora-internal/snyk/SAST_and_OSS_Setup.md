# SAST and OSS Setup (Snyk)

Use this guide to add Snyk SAST and OSS scanning in a repository CI workflow.

## SAST and OSS Scan Overview

- `SAST (Snyk Code)` scans your custom source code for security issues such as injection risks, insecure logic, and unsafe patterns.
- `OSS (Snyk Open Source)` scans third-party dependencies for known vulnerabilities and license risks.
- Running both scans gives complete coverage across your in-house code and external packages.
- In CI, these scans can be configured to fail builds or block PR merges based on severity thresholds.

## Prerequisites

1. Connect to GP VPN.
2. Ensure you have write access to the target repository.

## Step 1: Clone the target repository

Clone the repository where you want to implement the Snyk scan.

		git clone https://github.com/<org>/<repo>.git
		cd <repo>

Example:

		git clone https://github.com/Deloitte-US-Innovation-Technology/sample-repo.git
		cd sample-repo

## Step 2: Create a feature branch from main

Switch to `main`, pull the latest changes, and then create a feature branch.

		git checkout main
		git pull origin main
		git checkout -b feature/add-snyk-sast-oss-scan

## Step 3: Update .github/workflows/ci.yml

Open .github/workflows/ci.yml and add the following YAML after the SonarQube Scan job.

```yaml
snyk-scan:
  name: Snyk Code (SAST) Scan
  runs-on: [nbi]
  continue-on-error: true
  needs: validate-access
  outputs:
    status: ${{ steps.snyk.outputs.status }}
    project-url: ${{ steps.snyk.outputs.project-url }}
  steps:
    - name: Checkout Code
      uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/checkout-action@main
      with:
        ref: ${{ github.event.inputs.commit || github.event.inputs.release_tag || github.event.inputs.branch || github.ref }}

    - name: Snyk Code SAST Scan
      id: snyk
      uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/snyk-scan@main
      with:
        snyk-token: ${{ secrets.SNYK_TOKEN }}

ci-cd:
  needs: [validate-access, snyk-scan, sonarqube]
```

For downstream jobs, include `snyk-scan` in `needs` so its status can be used later in the workflow.

Notes:

1. Confirm that the repository has the SNYK_TOKEN secret configured from Doppler.
2. For any downstream job (for example ci-cd), add `snyk-scan` in `needs`.

## Step 4 (Optional): Update notify job with Snyk status

If your repository uses an Engine CI/CD-style notify job, add `snyk-scan` to `needs` and pass `needs.snyk-scan.outputs.status` to both the pipeline summary and Teams notification.

```yaml
notify:
  name: Notify
  runs-on: ubuntu-latest
  continue-on-error: true
  needs: [ci-cd, sonarqube, snyk-scan, unit-tests, update-helm-chart, force-sync-argocd]
  if: always()
  steps:
    - name: Generate Pipeline Summary
      id: summary
      if: always()
      uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/pipeline-summary@main
      with:
        snyk-status: ${{ needs.snyk-scan.outputs.status }}

    - name: Send Teams Notification
      if: always()
      uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/teams-notification@main
      with:
        webhook-url: ${{ secrets.TEAMS_WEBHOOK_URL }}
        snyk-status: ${{ needs.snyk-scan.outputs.status }}
```

## Step 5 (Optional): Add Snyk PR check workflow

If you want Snyk to run as a pull request check and fail the PR when Medium or higher issues are found, add or update [.github/workflows/security-scan.yml](.github/workflows/security-scan.yml) with the Snyk-only scan job.

Use this workflow for PR validation and set the scan type to `snyk-only` when needed. For example, the Snyk job can enforce Medium+ findings as merge-blocking while SonarQube remains informational.

```yaml
name: Security Scan

on:
  workflow_dispatch:
    inputs:
      scan-type:
        description: 'Type of scan to run'
        required: true
        default: 'all'
        type: choice
        options:
          - all
          - sonarqube-only
          - snyk-only
  push:
    # Add the branches that should trigger this workflow.
    branches:
      - main
      - development
      - 'release/**'
  pull_request:

permissions:
  contents: read

jobs:
  snyk-scan:
    name: Snyk Code (SAST) Scan
    runs-on: [nbi]
    if: github.event_name != 'workflow_dispatch' || inputs.scan-type == 'all' || inputs.scan-type == 'snyk-only'
    steps:
      - name: Checkout Code
        uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/checkout-action@main

      - name: Snyk Code SAST Scan
        id: snyk
        uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/snyk-scan@main
        with:
          snyk-token: ${{ secrets.SNYK_TOKEN }}
          monitor: true
          severity-threshold: medium
          fail-on-issues: true
          oss-severity-threshold: medium
          oss-fail-on-issues: true

  summary:
    name: Scan Summary
    runs-on: ubuntu-latest
    needs: [snyk-scan]
    if: always()
    steps:
      - name: Dashboard Links
        uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/scan-summary@main
        with:
          snyk-project-url: ${{ needs.snyk-scan.outputs.snyk-project-url }}
```

After adding the workflow, go to repository Settings, open the Branches section, and add a branch protection rule that requires the Snyk PR check before merge.

## Save, commit, push, and create PR to main

After updating ci.yml:

		git add .github/workflows/ci.yml
		git commit -m "Add Snyk SAST scan and notification status in CI"
		git push -u origin feature/add-snyk-sast-oss-scan

Open a PR to main and assign a maintainer for approval.

After merge, run the workflow and validate that Snyk is running properly and the results are stored correctly.

Review the scan results in the Snyk dashboard.

## Validation checklist

1. ci.yml syntax is valid.
2. SNYK_TOKEN secret is present in repository secrets.
3. If Step 4 is enabled, notify needs includes snyk-scan and both summary and notification receive snyk-status.
4. If Step 5 is enabled, .github/workflows/security-scan.yml is used as the PR check for Snyk-only scans and the branch protection rule requires it.
5. PR targets main branch.
6. After merge, the workflow runs successfully and Snyk results are stored correctly.
