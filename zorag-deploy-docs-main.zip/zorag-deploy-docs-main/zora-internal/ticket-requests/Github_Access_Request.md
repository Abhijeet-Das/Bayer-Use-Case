---
title: Granting GitHub Access to New Users
description: Procedure for adding team members to Zora repository resources, including role mapping and files to update.
---

# Grant GitHub access to users

**Developers and business users** can access Zora GitHub resources once they're added to the correct Zora user groups. There are **four levels of access**, based on the user's interaction with the repository.

Use the process below to **add a new user**, **add a user to a new repository group**, or **update an existing user's access level** (`role`).

Create a branch from `main`, make your changes, and open a pull request. Since PRs require approvals, there can be a delay in access provisioning.

## Scope

- **Repository:** `Deloitte-US-Engineering/dep-platforms-rbac`
- **Base branch:** `main`
- **Folder to work in:** `onboarding/Deloitte-US-Innovation-Technology`
- **DEP merge POC:** `yininganagoudar@deloitte.com`

## Roles

Select a user's `role` based on required access:

- **viewers**: Grants view-only permissions.
- **developers**: Grants read and write permissions for non-production work.
- **managers**: Grants team membership and team settings access.
- **maintainers**: Grants full administrative access.

## Repository

Add users using the `dep-platforms-rbac` repository:

https://github.com/Deloitte-US-Engineering/dep-platforms-rbac

!!! info
    You can review an example PR [here](https://github.com/Deloitte-US-Engineering/dep-platforms-rbac/pull/3220/files).

## Files to update

The location for all team files is:

`./onboarding/Deloitte-US-Innovation-Technology/`

- `aiq`: `team_int-pllm-i.yml` (general Zora POCs)
- `ext`: `team_int-ext-i.yml` (SUT repositories)
- `zorag`: `team_zorag.yml` (deploy docs site for global team members)
- `zora-d`: `team_zora-d.yml` (Zora demos for commercialization team members)

## File syntax

```yaml
roles:
	developers:
	# Deloitte mail-id
	- firstname.lastname@deloitte.com
	managers:
	- firstname.lastname@deloitte.com
	maintainers:
	- firstname.lastname@deloitte.com
	viewers:
	- firstname.lastname@deloitte.com
```

## Steps

Follow these steps to add users to a group:

1. **Pull** the latest `main` branch.

```bash
git checkout main
git pull origin main
```

2. **Create** a branch. Use `onboard/` in the branch name, for example `onboard/firstname-lastname/realm`.

```bash
git checkout -b onboard/some-username
```

3. **Add** the user's email in the correct role section of the correct `.yml` file.

!!! note
	Maintain alphabetical order when adding users.

5. **Stage** the file.

```bash
git add team-file.yml
```

6. **Commit** with a clear message.

```bash
git commit -m "chore: onboard Some Username as developer"
```

7. **Push** the branch.

```bash
git push origin onboard/some-username
```

8. **Open** a PR and assign a maintainer for approval.

After merging PR, the user has access.
