# Cloud Access Request

Use the following process to request cloud access for a user.

## Prerequisites

- **Connect to GPVPN:** `gpvpn.deloitteinnovation.us`
- **Okta first login is mandatory:** The user must log in to Okta at least one time before being added.

## Step-by-Step Process

1. **Connect to GPVPN** using `gpvpn.deloitteinnovation.us`.
2. **Open** `https://deloittecms.digitalidentityservice.com/app/UserHome`.
3. **Authenticate** with Deloitte ID and password, then approve the Okta notification.
4. **Click** **ServiceNow UD** in the portal.
5. **Click** **Request Something**.
6. **Open** **Okta User Group Management**.

   - **Navigation Path:** `Home -> CMS Operations Catalog -> Okta User Access Management -> Okta User Group Management`

7. In **Actions**, select **Add or Remove**.
8. For **Access For**, select **Project User**.
9. For **Project Name**, select the applicable project from the dropdown list.
10. **Search** for the user in the user tab to verify whether they are already added.
11. If the user is not present, **click Add User** and add the user details.
12. **Select** the required role for cloud access.
13. **Submit** the request.
14. **Share** the request context and ticket number with the CloudOps support team for approval.

## Request Message Template

Use this template when sharing the ticket for approval:

```text
Please provide AWS cloud access for the <project_name> project to the following user:

<user_id>

Request Number: REQ12345
```

## Email Template

Use this template to send the email:

```text
To: USAEFAIMLOperate@deloitte.com
Subject: AWS Cloud Access Request - <project_name>

Hello Team,

Please provide AWS cloud access for the below users.

Project Name: <project_name>
Access Type: <role_or_access_level>

Users:
<user_1>
<user_2>

Request Number: REQ12345

Thank you.
```

## Additional Notes

- **Multiple users can be added** in a single request by using the **Add** button.
- **Azure login format:** Use `<username>@openclouddeloitte.com` to sign in to Azure.
- **Verification step:** After cloud access is approved, complete sign-in and verify using Okta.

## CloudOps support team

### US Time Zone

- adfrost@deloitte.com
- dbasnet@deloitte.com
- hkulirntharaja@deloitte.com

### USI Time Zone

- vimg@deloitte.com
- shsagar@deloitte.com
- pasprashanth@deloitte.com
- nithyar6@deloitte.com
