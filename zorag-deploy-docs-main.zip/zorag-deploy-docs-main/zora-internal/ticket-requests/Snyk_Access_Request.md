# Snyk Access Request

Use the following process to submit a Snyk access request.

## Step-by-Step Process

1. Open the ServiceNow request page:

    https://deloitteglobal.service-now.com/mysupport?id=emp_taxonomy_topic&topic_id=81edc2131bdd3a502902c9d1604bcbc6&in_context=true

2. Select **Automated Application Testing - General Request Form**.
3. In **Requested For**, select the email address of the person who needs access.
4. In **Watch List**, add the person(s) who should receive notifications for this ticket.
5. Select **Deloitte Member Firm** based on the member firm the application will be charged to.
6. Select **Deloitte Member Firm Territory**.
7. In **Request Type**, select **Access**.
8. In **Platform**, select **Snyk**.
9. In **Snyk Organizations**, enter a comma-separated list of all Snyk Organizations for which this request is in reference to.
10. In **Normal Users**, enter the email IDs of non-developers who need access to integrate Snyk with SCM, CICD, and to view scan results.
11. In **View Only Users**, enter the email IDs of users who need only read/view access (for example: BISOs or reporting teams).
12. Submit the request.

## Notes

- After submitting the request, please monitor the ticket; the AAT team will provide access.
