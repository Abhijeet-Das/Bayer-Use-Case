# Kubernetes Access Request and Login Guide

## What You Need Before Starting

- Deloitte VPN connection: `gpvpn.deloitteinnovation.us`
- Deloitte SSO and Okta access
- ServiceNow access
- Cloud access approval for the required environment (mandatory before cluster access)
- A valid business reason for access

## Part 1: Raise the Access Request

1. Connect to Deloitte VPN.
2. Open `https://deloittecms.digitalidentityservice.com/app/UserHome`.
3. Sign in with Deloitte credentials and complete Okta approval.
4. Open **ServiceNow UD**.
5. Select **Request Something**.
6. Select **General Infrastructure Service/Enhancement Request**.
7. Paste the request template below and update the placeholders.
8. Submit the request.
9. Save the ServiceNow request number (example: REQ12345).
10. Share the request number with the CloudOps support team.

## Request Template (ServiceNow)

```text
Please provide Kubernetes access for the user(s) listed below.

Cloud Provider: <AWS | Azure | GCP>
Environment: <Dev | QA | Stage | Prod>
Access Type: <Read Only | Developer | Admin>


Users:
<user_1@deloitte.com>
<user_2@deloitte.com>

Request Number: REQ12345
```

## Email Template (After Ticket Submission)

```text
To: USAEFAIMLOperate@deloitte.com
Subject: Kubernetes Access Request - REQ12345

Hello Team,

Please review and process the Kubernetes access request.

Cloud Provider: <AWS | Azure | GCP>
Environment: <Dev | QA | Stage | Prod>
Access Type: <Read Only | Developer | Admin>
Scope: <Cluster | Namespace>

Users:
<user_1@deloitte.com>
<user_2@deloitte.com>

Request Number: REQ12345

Thank you.
```

## Part 2: Log In to Cloud After Approval

Cluster access is possible only after cloud access is approved and active.

Use only the cloud platform your team confirms.

### Option A: GCP Login and Cluster Access

```bash
gcloud components install gke-gcloud-auth-plugin
gcloud auth login
gcloud config set project <gcp_project_id>
gcloud container clusters get-credentials <cluster_name> --region <region> --project <gcp_project_id>
kubectl get ns
```

### Option B: AWS Login and Cluster Access

```bash
# Use your approved AWS login method (SSO/Okta as instructed by your team)
aws sts get-caller-identity
aws eks update-kubeconfig --name <cluster_name> --region <region>
kubectl get ns
```

### Option C: Azure Login and Cluster Access

```bash
az login
az account set --subscription <subscription_id_or_name>
az aks get-credentials --resource-group <resource_group> --name <cluster_name> --overwrite-existing
kubectl get ns
```

## Part 3: Confirm You Are Connected to the Correct Cluster

Run these commands:

```bash
kubectl config get-contexts
kubectl config current-context
kubectl get ns
```

If namespaces are listed, your access is working.

## Common Issues and What to Do

- VPN disconnected: reconnect VPN and retry.
- SSO/Okta failure: re-authenticate and retry.
- Access denied: confirm request is approved and correct access type was granted.
- Wrong cluster context: switch context and retry.

## Support Contact

For access request follow-up, contact:

- USAEFAIMLOperate@deloitte.com

## Endpoint Reference

Use this link to open Azure Private Endpoints:

- https://portal.azure.com/#view/HubsExtension/AssetMenuBlade/~/PrivateEndpoints/assetName/NetworkFoundation/extensionName/Microsoft_Azure_Network
