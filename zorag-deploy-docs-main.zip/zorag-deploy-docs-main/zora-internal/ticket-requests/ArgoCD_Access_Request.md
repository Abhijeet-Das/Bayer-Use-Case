# ArgoCD Access Request

Use the following process to request ArgoCD access for a user.

## Prerequisites

- **Connect to GPVPN:** `gpvpn.deloitteinnovation.us`
- **Okta login is mandatory:** The user should have access for OKTA to rasie the request.

## Step-by-Step Process

1. **Connect to GPVPN** using `gpvpn.deloitteinnovation.us`.
2. **Open** `https://deloittecms.digitalidentityservice.com/app/UserHome`.
3. **Authenticate** with Deloitte ID and password, then approve the Okta notification.
4. **Click** **ServiceNow UD** in the portal.
5. **Click** **Request Something**.
6. **Open** **General Infrastructure Service/Enhancement Request**.
7. Enter request details using the values below.
8. **Submit** the request.
9. **Copy** the ServiceNow request number after submission.
10. **Email** the request context and ServiceNow ticket number to USAEFAIMLOperate@deloitte.com.

## Form Values

- **Project Name:** Aria PLLM (or your applicable project)
- **Cloud Service Account:** AZSUB-DEP-AME-DEL-ARI-NONPROD (or your applicable account)
- **Short Description:** Please provide ArgoCD access for below users.
- **Description Template:**

```text
Please provide Argo CD access for the below users.

Users:
<user_1>
<user_2>

URL: https://argocd.<environment>.<domain>/
```

## Email Template

Use this template to send the email:

```text
To: USAEFAIMLOperate@deloitte.com
Subject: Argo CD Access Request

Hello Team,

Please provide Argo CD access for the below users.

Users:
<user_1>
<user_2>

Argo CD URL: https://argocd.<environment>.<domain>/

Request Number: REQ12345

Thank you.
```

## Additional Notes

- **Multiple users can be added** in a single request.

## CloudOps support team

### US Time Zone

- adfrost@deloitte.com
- dbasnet@deloitte.com
- hkulirntharaja@deloitte.com

### USI Time Zone

- vimg@deloitte.com
- shsagar@deloitte.com
- pasprashanth@deloitte.com
- nithyar6@deloitte.com