# Zora AI Digital Worker Platform: Security Design
### Annex B: Amazon Web Services (AWS) Deployment

**Document Type:** Cloud Deployment Annex  
**Platform:** Zora AI CFO Insights  
**Deployment Target:** Client AWS Account (Amazon Elastic Kubernetes Service)  
**Core Framework Version:** 1.0  
**Annex Version:** 1.0  
**Classification:** Confidential

> **Prerequisites:** This annex covers AWS-specific security architecture, services, and infrastructure only. Read the **Zora AI Digital Worker Platform: Security Design: Core Framework** first for platform-agnostic principles, agent security, data handling protocols, and the full control matrix baseline.

---

## Version History

| Version | Date | Changes | Author |
|---|---|---|---|
| 1.0 | 2026-03-19 | Initial release: AWS deployment annex | Deloitte Zora AI Platform Team |
| 1.1 | 2026-03-24 | Aligned with Core Framework v2.1: updated platform name, monitoring to OTel-first, em dash removal | Deloitte Zora AI Platform Team |

---

## Table of Contents

1. [AWS Deployment Overview](#1-aws-deployment-overview)
2. [AWS Security Architecture](#2-aws-security-architecture)
3. [Identity & Access Management: AWS](#3-identity--access-management--aws)
4. [LLM Hosting on AWS](#4-llm-hosting-on-aws)
5. [Data Security: AWS](#5-data-security--aws)
6. [Application & API Security: AWS](#6-application--api-security--aws)
7. [Infrastructure Security: EKS & AWS](#7-infrastructure-security--eks--aws)
8. [Monitoring & Observability: AWS](#8-monitoring--observability--aws)
9. [AWS Control Matrix Delta](#9-aws-control-matrix-delta)
10. [Appendix: AWS Infrastructure Specifications](#10-appendix-aws-infrastructure-specifications)

---

## 1. AWS Deployment Overview

In the AWS deployment, Zora AI Digital Workers run as containerized workloads on **Amazon Elastic Kubernetes Service (EKS)** within the client's AWS account. The platform integrates with AWS-native identity, secrets, API management, and monitoring services: **AWS IAM**, **Amazon Cognito**, **AWS Secrets Manager**, **Amazon API Gateway**, and **Amazon CloudWatch / AWS Security Hub**.

### 1.1 Reference Architecture

```mermaid
flowchart TD
    subgraph AWS["AWS Account (Client Tenancy)"]
        subgraph EKS["Amazon EKS: Zora AI Cluster"]
            UI["Zora UI Container\n(React / SSO)"]
            API["Zora FastAPI\n(HTTPS / TLS 1.2)"]
            REDIS["Redis Message Broker"]
            AGENTS["Agent Pods\n· SQL Agents\n· Deep Analysis Agents\n· Report Gen Agents"]
            SKILLS["Skill & Tool Library\n(Finance Domain)"]
            PGDB["PostgreSQL 14.5\n(Analytics DB)"]
            MILVUS["Milvus Vector DB\n2 vCPU / 8 GiB / 30 GB SSD"]
            NIM["NVIDIA NIM Container\nGPT-OSS-120b\n⚙️ Production"]
        end

        subgraph AWS_AI["AWS AI Services"]
            BEDROCK["Amazon Bedrock\nor SageMaker\n🧪 Pilot"]
            APIGW["Amazon API Gateway\n(API Gateway)"]
        end

        subgraph AWS_SEC["AWS Security Services"]
            IAM["AWS IAM\n(AuthN / AuthZ)"]
            COGNITO["Amazon Cognito\n(User Identity / SSO)"]
            SECRETS["AWS Secrets Manager\n(Secrets Management)"]
            CLOUDWATCH["Amazon CloudWatch\n(Monitoring & Logging)"]
            GUARD_DUTY["Amazon GuardDuty\n(Threat Detection)"]
            SEC_HUB["AWS Security Hub\n(Posture Management)"]
        end

        subgraph DATA["Client Data Layer"]
            S3["Amazon S3\n(Data Lake)"]
            REDSHIFT["Amazon Redshift /\nData Warehouse"]
        end
    end

    subgraph DELOITTE["Deloitte Artifact Store (Deployment-time only)"]
        HELM["Helm Charts / Signed Images"]
    end

    USER["Finance User"] -->|"Cognito / Corporate IdP SSO"| UI
    UI --> APIGW
    APIGW --> API
    API --> REDIS
    REDIS --> AGENTS
    AGENTS --> SKILLS
    AGENTS -->|"🧪 Pilot"| BEDROCK
    AGENTS -->|"⚙️ Production"| NIM
    AGENTS --> PGDB
    AGENTS --> MILVUS
    PGDB -->|Daily Incremental Refresh| S3
    S3 --> REDSHIFT
    IAM -->|Role-based access| AGENTS
    COGNITO -->|Token validation| APIGW
    SECRETS -->|Runtime injection| AGENTS
    AGENTS -.->|Logs & Traces| CLOUDWATCH
    GUARD_DUTY -.->|Threat detection| EKS
    DELOITTE -->|One-time secure download| EKS

    style AWS fill:#fff3e0,stroke:#e65100
    style EKS fill:#ffe0b2,stroke:#ef6c00
    style AWS_AI fill:#f3e5f5,stroke:#6a1b9a
    style AWS_SEC fill:#fce4ec,stroke:#c62828
    style DELOITTE fill:#e8f5e9,stroke:#2e7d32,stroke-dasharray: 5 5
    style NIM fill:#e8f5e9,stroke:#2e7d32
    style BEDROCK fill:#ede7f6,stroke:#4527a0
```

### 1.2 AWS Infrastructure Specifications

| Component | Specification |
|---|---|
| **EKS Node Pool** (Zora Agent & Platform) | m6a.16xlarge: 64 vCPUs, 256 GiB RAM (or equivalent) |
| **Processor** | AMD EPYC (Genoa / Milan) |
| **OS** | Amazon Linux 2023 (EKS-optimized AMI) |
| **Data Disk** | 1 × 1024 GiB gp3 EBS Volume |
| **OS Disk** | gp3 EBS (EKS node default) |
| **Vector Database** | Milvus DB: 2 vCPU, 8 GiB, 30 GB gp3 EBS |
| **Kubernetes Service** | Amazon Elastic Kubernetes Service (EKS) |
| **LLM: Pilot** | GPT-OSS-120b via Amazon Bedrock custom model or SageMaker endpoint (VPC endpoint) |
| **LLM: Production** | GPT-OSS-120b via NVIDIA NIM on EKS GPU node pool |

---

## 2. AWS Security Architecture

The Core Framework's four-layer security model maps to AWS-native services as follows:

| Layer | Core Control | AWS Implementation |
|---|---|---|
| **Layer 4: Infrastructure** | Kubernetes Network Policies | EKS Network Policy (VPC CNI) |
| **Layer 4: Infrastructure** | Cloud account-level threat detection | Amazon GuardDuty + AWS Security Hub |
| **Layer 4: Infrastructure** | Encryption at rest | AWS EBS Encryption (KMS-managed) |
| **Layer 3: Application & API** | API gateway | Amazon API Gateway (REST / HTTP API) |
| **Layer 3: Application & API** | RBAC on endpoints | AWS IAM + Cognito authorizer |
| **Layer 3: Application & API** | Cloud secrets manager | AWS Secrets Manager (CSI Driver injection) |
| **Layer 2: Data** | Data lake access policy | AWS IAM + Lake Formation data permissions |
| **Layer 1: AI / Agent** | Cloud content safety (Pilot) | Amazon Bedrock Guardrails (built-in) |
| **Layer 1: AI / Agent** | LLM IAM auth (Pilot) | EKS Pod Identity / IRSA → Bedrock endpoint |

---

## 3. Identity & Access Management: AWS

### 3.1 Authentication Flow

Authentication on AWS uses **Amazon Cognito** as the user identity and token management layer, integrating with the client's corporate identity provider via SAML 2.0 or OIDC federation. **AWS IAM** governs resource-level access for all workload identities.

```mermaid
sequenceDiagram
    participant USER as Finance User
    participant BROWSER as Browser / Client Portal
    participant COGNITO as Amazon Cognito\n(User Pool)
    participant CORP_IDP as Client Corporate IdP\n(SAML / OIDC Federation)
    participant APIGW as Amazon API Gateway
    participant ZORA as Zora UI (EKS)
    participant API as Zora FastAPI

    USER->>BROWSER: Access Zora application URL
    BROWSER->>COGNITO: Initiate OAuth 2.0 / OIDC flow
    COGNITO->>CORP_IDP: Federated authentication (SAML/OIDC)
    CORP_IDP-->>COGNITO: Identity assertion
    COGNITO-->>BROWSER: JWT access token (Cognito token)
    BROWSER->>ZORA: Load UI with token
    ZORA->>APIGW: API call with Bearer token
    APIGW->>COGNITO: Token validation (Cognito Authorizer)
    COGNITO-->>APIGW: Claims (groups, roles)
    APIGW->>API: Forwarded (validated) request
    API-->>ZORA: Authorized response
```

### 3.2 AWS Authorization Controls

| Control | AWS Implementation | Standard |
|---|---|---|
| RBAC | AWS IAM roles mapped to Cognito user groups; finance role segmentation enforced | SOC 2 / ISO 27001 |
| API authorization | API Gateway Cognito Authorizer; per-route IAM policy enforcement | NIST SP 800-53 |
| Least privilege | EKS Pod Identity / IRSA: pods assume scoped IAM roles; no long-lived credentials | CIS EKS Benchmark |
| Secrets access | AWS Secrets Manager resource policies: only designated pod IAM roles can read | CIS AWS Benchmark |
| Admin access | EKS cluster admin via IAM identity only; no shared admin accounts | Zero Trust |
| MFA | Enforced via Cognito User Pool MFA policy and corporate IdP Conditional Access | NIST AAL2 |
| Session management | Cognito token expiry and refresh policies | OWASP ASVS |

### 3.3 EKS Pod Identity: No Static Credentials

All pod-to-AWS-service authentication uses **EKS Pod Identity** (or IRSA: IAM Roles for Service Accounts). Agent pods authenticate to Secrets Manager, Bedrock, and CloudWatch using short-lived STS tokens: no static credentials in pods or environment variables.

```mermaid
flowchart TD
    subgraph EKS["Amazon EKS Cluster"]
        POD["Agent Pod\n(Pod Identity / IRSA)"]
    end
    STS["AWS STS\n(Token Issuance)"]
    SM["AWS Secrets Manager"]
    BEDROCK["Amazon Bedrock"]
    CW["Amazon CloudWatch"]
    S3["Amazon S3"]

    POD -->|AssumeRoleWithWebIdentity| STS
    STS -->|Short-lived credentials| POD
    POD --> SM
    POD --> BEDROCK
    POD --> CW
    POD --> S3

    STATIC["❌ No static credentials\nin pods or env vars"] -.-> POD

    style STATIC fill:#ffebee,stroke:#c62828
    style EKS fill:#ffe0b2,stroke:#ef6c00
```

---

## 4. LLM Hosting on AWS

### 4.1 Pilot Phase: Amazon Bedrock

During the Pilot phase, GPT-OSS-120b is served via **Amazon Bedrock** (custom model import) or a **Amazon SageMaker** managed endpoint within the client's AWS account, accessed via a VPC endpoint. Amazon Bedrock's built-in **Guardrails for Amazon Bedrock** complement Zora's NeMo Guardrails.

```mermaid
flowchart TD
    subgraph AWS["AWS Account: 🧪 Pilot"]
        subgraph EKS["EKS Cluster"]
            AGENT["Zora Agent Pod"]
            GUARD["NeMo Guardrails"]
        end
        subgraph BEDROCK_ENV["Amazon Bedrock (VPC Endpoint)"]
            BR_GUARD["Bedrock Guardrails\n(Built-in)"]
            LLM["GPT-OSS-120b\n(Custom Model / SageMaker)"]
        end
        IRSA["EKS Pod Identity / IRSA\n(IAM Auth)"]
    end

    AGENT --> GUARD
    GUARD -->|Filtered prompt| IRSA
    IRSA -->|STS token| BEDROCK_ENV
    BR_GUARD --> LLM
    LLM -->|Completion| BR_GUARD
    BR_GUARD -->|Filtered| GUARD
    GUARD --> AGENT

    EXT["❌ No data leaves\nAWS account"] -.-> LLM

    style BEDROCK_ENV fill:#f3e5f5,stroke:#6a1b9a
    style GUARD fill:#fff3e0,stroke:#f57c00
    style EXT fill:#ffebee,stroke:#c62828
```

### 4.2 Production Phase: NVIDIA NIM on EKS

For Production, GPT-OSS-120b is self-hosted as an **NVIDIA NIM container** in the `zora-models` namespace on an EKS GPU node group. Zero external calls for LLM inference.

```mermaid
flowchart TD
    subgraph AWS["AWS Account: ⚙️ Production"]
        subgraph EKS["Amazon EKS Cluster"]
            subgraph AGENT_NS["Namespace: zora-platform"]
                AGENT["Zora Agent Pod"]
                GUARD["NeMo Guardrails"]
            end
            subgraph MODEL_NS["Namespace: zora-models (Isolated)"]
                NIM["NVIDIA NIM Container\nGPT-OSS-120b"]
            end
            GPU["EKS GPU Node Group\n(NVIDIA H100 / A100)"]
        end
    end

    AGENT --> GUARD
    GUARD -->|Intra-cluster TLS| NIM
    NIM --> GUARD
    GUARD --> AGENT
    NIM -.->|Runs on| GPU

    EXT["❌ Zero external calls\nfor LLM inference"] -.-> NIM

    style AGENT_NS fill:#ffe0b2,stroke:#ef6c00
    style MODEL_NS fill:#e8f5e9,stroke:#2e7d32
    style EXT fill:#ffebee,stroke:#c62828
```

---

## 5. Data Security: AWS

### 5.1 Encryption at Rest

| Store | AWS Encryption |
|---|---|
| PostgreSQL (CFO Analytics DB) | EBS gp3 Volume Encryption: AWS KMS (CMK optional) |
| Milvus Vector DB | EBS gp3 Volume Encryption: AWS KMS |
| Agent DB (session data) | EBS Volume Encryption: AWS KMS |
| Amazon S3 (data lake, logs) | SSE-S3 or SSE-KMS (AES-256) |
| Amazon Redshift | Cluster encryption via AWS KMS |

### 5.2 Secrets Management: AWS Secrets Manager

- All secrets (connection strings, API keys, certificates) stored in **AWS Secrets Manager**
- Injected into EKS pods at runtime via the **AWS Secrets and Configuration Provider (ASCP)** for the Kubernetes Secrets Store CSI Driver
- Automatic secret rotation supported via Secrets Manager rotation Lambdas: zero redeployment required
- All Secrets Manager access events logged to **AWS CloudTrail** and exportable to SIEM

### 5.3 AWS Lake Formation: Data Access Governance

Where the client's data lake is on AWS (S3 + Glue + Athena or Redshift), **AWS Lake Formation** provides fine-grained data access governance:

- Zora agent IAM roles are granted column-level and row-level permissions via Lake Formation policies
- Agents cannot access data sets outside their granted scope, regardless of what they query
- Lake Formation audit logs capture all data access events per agent identity

---

## 6. Application & API Security: AWS

### 6.1 Amazon API Gateway

| Control | Specification |
|---|---|
| Transport | HTTPS / TLS 1.2+; older protocols not supported |
| Authentication | Amazon Cognito Authorizer or AWS IAM Authorizer |
| Authorization | Per-route IAM policy and Cognito group-based access |
| Secrets | API keys stored in AWS Secrets Manager; referenced via environment injection |
| Rate limiting | API Gateway usage plans and throttling per API key / identity |
| DDoS protection | AWS Shield Standard (all accounts); AWS Shield Advanced (optional) |
| WAF | AWS WAF on API Gateway for OWASP rule set enforcement (optional) |
| Proxy | API Gateway in front of all agent FastAPI services: no direct pod exposure |

### 6.2 AWS Network Security

```mermaid
flowchart TD
    INTERNET["Internet / Client Users"]
    SHIELD["AWS Shield\n(DDoS Protection)"]
    WAF["AWS WAF\n(Optional)"]
    APIGW["Amazon API Gateway"]

    subgraph VPC["AWS VPC (Client)"]
        subgraph EKS_SUB["EKS Private Subnet"]
            EKS["EKS Cluster\n(Private API Endpoint)"]
        end
        subgraph DATA_SUB["Data Subnet"]
            PGDB["PostgreSQL Pod"]
            MILVUS["Milvus Pod"]
        end
        subgraph AI_SUB["AI / Secrets (VPC Endpoints)"]
            BEDROCK_EP["Amazon Bedrock\n(VPC Endpoint)"]
            SM_EP["AWS Secrets Manager\n(VPC Endpoint)"]
        end
    end

    SG["Security Groups\n(Per Resource)"]
    NACL["Network ACLs\n(Per Subnet)"]

    INTERNET --> SHIELD --> WAF --> APIGW --> EKS
    EKS --> PGDB
    EKS --> MILVUS
    EKS --> BEDROCK_EP
    EKS --> SM_EP
    SG -.->|Controls| EKS_SUB
    NACL -.->|Controls| DATA_SUB
    SG -.->|Controls| AI_SUB

    style VPC fill:#fff3e0,stroke:#e65100
    style EKS_SUB fill:#ffe0b2,stroke:#ef6c00
    style DATA_SUB fill:#e8f5e9,stroke:#2e7d32
    style AI_SUB fill:#f3e5f5,stroke:#6a1b9a
```

- **VPC Endpoints** (PrivateLink) used for Amazon Bedrock, Secrets Manager, S3, and CloudWatch: all traffic traverses the AWS backbone, never the public internet
- **Security Groups** enforce allow-list ingress/egress per pod and node
- **Network ACLs** applied at subnet level as secondary control
- EKS API server endpoint is **private**: accessible within the VPC only

---

## 7. Infrastructure Security: EKS & AWS

### 7.1 Amazon EKS Cluster Hardening

| Control | Implementation |
|---|---|
| Namespace isolation | `zora-models` and `zora-platform` namespaces; Network Policy (VPC CNI) enforced |
| Pod security | EKS Pod Security Standards: `restricted` profile; non-root, no privilege escalation |
| Workload identity | EKS Pod Identity / IRSA: short-lived STS tokens; no static credentials |
| Private cluster | EKS API server endpoint private: accessible within VPC only |
| OS hardening | Amazon Linux 2023 EKS-optimized AMI; automatic node group patching via managed node groups |
| Image integrity | Signed Deloitte images; Amazon ECR image scanning (on push + on pull) |
| Helm integrity | Declarative Helm deployment; no manual kubectl exec in production |
| Node group separation | Dedicated GPU node group for `zora-models` namespace (Production) |

### 7.2 Amazon GuardDuty & Security Hub

- **GuardDuty EKS Protection:** Continuous monitoring of EKS audit logs and runtime activity for anomalous container behaviour, cryptocurrency mining, lateral movement
- **GuardDuty S3 Protection:** Monitors data lake access for unusual access patterns
- **GuardDuty Secrets Manager Monitoring:** Alerts on suspicious secret access (enumeration, access from unexpected principals)
- **AWS Security Hub:** Aggregates findings from GuardDuty, Inspector, and Macie; provides unified security posture score and remediation guidance
- **AWS CloudTrail:** All API calls across the account logged; tamper-evident log storage in S3 with CloudTrail Lake for queryable audit history

---

## 8. Monitoring & Observability: AWS

### 8.1 AWS Monitoring Stack

Zora emits all agent traces, prompt interactions, and system events via **OpenTelemetry (OTel)**. The OTel Collector runs within the EKS cluster and forwards data to the client's AWS observability stack. Optionally, a **LangFuse** instance can be deployed within the client's environment for agent trace visualization. The client is responsible for deploying and operating all downstream monitoring infrastructure.

```mermaid
flowchart TD
    subgraph ZORA["Zora Platform (EKS)"]
        OTEL_INSTR["OTel Instrumentation\n(Embedded in Zora)"]
        OTEL["OpenTelemetry Collector"]
        EKS_LOGS["EKS Container Logs"]
    end

    subgraph CLIENT_OPT["Optional: Client-Deployed"]
        LANGFUSE["LangFuse\n(Agent Trace Viewer)"]
    end

    subgraph AWS_OBS["AWS Observability Stack (Client-operated)"]
        CW_LOGS["Amazon CloudWatch Logs"]
        CW_METRICS["CloudWatch Metrics & Alarms"]
        XRAY["AWS X-Ray\n(Distributed Tracing)"]
        SEC_HUB["AWS Security Hub"]
    end

    OTEL_INSTR --> OTEL
    EKS_LOGS --> CW_LOGS
    OTEL -->|Traces| LANGFUSE
    OTEL --> CW_LOGS
    OTEL --> XRAY
    CW_LOGS --> CW_METRICS
    CW_METRICS --> SEC_HUB

    style ZORA fill:#ffe0b2,stroke:#ef6c00
    style CLIENT_OPT fill:#fff9c4,stroke:#f9a825
    style AWS_OBS fill:#fce4ec,stroke:#c62828
```

### 8.2 AWS-Specific Security Event Sources

| Event Type | AWS Source | Export Target |
|---|---|---|
| Agent traces (prompts, responses, tool calls) | OTel Collector | CloudWatch / X-Ray |
| API authentication failures | API Gateway + Cognito | CloudWatch / Security Hub |
| Secrets Manager access | CloudTrail | Security Hub / SIEM |
| EKS runtime anomalies | GuardDuty EKS Runtime | Security Hub / CloudWatch |
| S3 data lake access | GuardDuty S3 / CloudTrail | Security Hub / SIEM |
| SSO / MFA events | Cognito + CloudTrail | CloudWatch / SIEM |
| Network flow anomalies | VPC Flow Logs | CloudWatch Logs |
| LLM token usage | OTel metrics + Bedrock (Pilot) | CloudWatch |
| Infrastructure changes | AWS CloudTrail | Security Hub / SIEM |

---

## 9. AWS Control Matrix Delta

This table covers only the AWS-specific implementation of controls defined in the Core Framework.

| Domain | Control | AWS Implementation |
|---|---|---|
| **AI Security** | Content safety (Pilot) | Amazon Bedrock Guardrails: built-in content filtering |
| **AI Security** | LLM auth (Pilot) | EKS Pod Identity / IRSA → Bedrock VPC endpoint |
| **Data Security** | Encryption at rest | AWS EBS Encryption: KMS (platform-managed or CMK) |
| **Data Security** | Secrets management | AWS Secrets Manager + ASCP CSI Driver pod injection |
| **Data Security** | Data lake governance | AWS Lake Formation: column/row-level IAM policies |
| **Application Security** | Authentication | Amazon Cognito User Pool: OAuth 2.0 / OIDC; corporate IdP federation |
| **Application Security** | MFA | Cognito User Pool MFA policy + corporate IdP enforcement |
| **Application Security** | API gateway | Amazon API Gateway: Cognito Authorizer, rate limiting, usage plans |
| **Application Security** | Workload identity | EKS Pod Identity / IRSA: short-lived STS tokens |
| **Cyber Security** | Network isolation | AWS VPC; private EKS API endpoint; VPC Endpoints (PrivateLink); Security Groups; NACLs |
| **Cyber Security** | Threat detection | Amazon GuardDuty (EKS, S3, Secrets Manager) + AWS Security Hub |
| **Cyber Security** | Audit logging | AWS CloudTrail (all API calls) + CloudTrail Lake |
| **Cyber Security** | Container registry | Amazon ECR: image scanning on push/pull; client-managed private repository |
| **Cyber Security** | Monitoring / SIEM | CloudWatch + X-Ray + Security Hub; optional OpenSearch or Datadog |
| **Cyber Security** | Pen testing policy | AWS-compliant pen testing under AWS penetration testing policy |

---

## 10. Appendix: AWS Infrastructure Specifications

### Primary Node Group: Zora Agent & Platform

| Parameter | Value |
|---|---|
| Instance Family | General-purpose (M6a series: AMD) |
| Instance Type | m6a.16xlarge (or equivalent) |
| vCPUs | 64 |
| Memory | 256 GiB |
| Data Volume | 1 × 1024 GiB gp3 EBS |
| OS | Amazon Linux 2023 (EKS-optimized AMI) |
| Kubernetes Service | Amazon Elastic Kubernetes Service (EKS) |

### LLM Hosting: Pilot (Amazon Bedrock / SageMaker)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Service | Amazon Bedrock (custom model import) or Amazon SageMaker managed endpoint |
| Authentication | EKS Pod Identity / IRSA (no static API key) |
| Network Access | VPC Endpoint (PrivateLink): no public internet |
| Content Filtering | Amazon Bedrock Guardrails (built-in) |

### LLM Hosting: Production (NVIDIA NIM on EKS)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Container | NVIDIA NIM (NVAIE / NIM software stack) |
| Deployment | EKS GPU node group: `zora-models` namespace |
| GPU (Recommended) | NVIDIA H100 80GB or equivalent (p4de.24xlarge or p5.48xlarge) |
| Network Access | Intra-cluster only; Security Group + Network Policy restrict to agent pods |

### Vector Database

| Parameter | Value |
|---|---|
| Technology | Milvus DB |
| vCPUs | 2 |
| Memory | 8 GiB |
| Storage | 30 GB gp3 EBS Volume |

---

*This annex should be read in conjunction with the Zora AI Digital Worker Platform: Security Design: Core Framework. For on-premises / PCAI GPU deployments, refer to the Zora PCAI Security Reference.*

*Document prepared by Deloitte Zora AI Platform Team. Annex Version 1.1 | Core Framework Version 2.1.*