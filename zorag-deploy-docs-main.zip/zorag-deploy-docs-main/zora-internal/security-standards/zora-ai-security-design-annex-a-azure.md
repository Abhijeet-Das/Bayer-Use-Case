# Zora AI Digital Worker Platform: Security Design
### Annex A: Microsoft Azure Deployment

**Document Type:** Cloud Deployment Annex  
**Platform:** Zora AI CFO Insights  
**Deployment Target:** Client Azure Subscription (Azure Kubernetes Service)  
**Core Framework Version:** 1.0  
**Annex Version:** 1.0  
**Classification:** Confidential

> **Prerequisites:** This annex covers Azure-specific security architecture, services, and infrastructure only. Read the **Zora AI Digital Worker Platform: Security Design: Core Framework** first for platform-agnostic principles, agent security, data handling protocols, and the full control matrix baseline.

---

## Version History

| Version | Date | Changes | Author |
|---|---|---|---|
| 1.0 | 2026-03-19 | Initial release: restructured from standalone Azure doc to annex format | Deloitte Zora AI Platform Team |
| 1.1 | 2026-03-24 | Aligned with Core Framework v2.1: updated platform name, monitoring to OTel-first, em dash removal | Deloitte Zora AI Platform Team |

---

## Table of Contents

1. [Azure Deployment Overview](#1-azure-deployment-overview)
2. [Azure Security Architecture](#2-azure-security-architecture)
3. [Identity & Access Management: Azure](#3-identity--access-management--azure)
4. [LLM Hosting on Azure](#4-llm-hosting-on-azure)
5. [Data Security: Azure](#5-data-security--azure)
6. [Application & API Security: Azure](#6-application--api-security--azure)
7. [Infrastructure Security: AKS & Azure](#7-infrastructure-security--aks--azure)
8. [Monitoring & Observability: Azure](#8-monitoring--observability--azure)
9. [Azure Control Matrix Delta](#9-azure-control-matrix-delta)
10. [Appendix: Azure Infrastructure Specifications](#10-appendix-azure-infrastructure-specifications)

---

## 1. Azure Deployment Overview

In the Azure deployment, Zora AI Digital Workers run as containerized workloads on **Azure Kubernetes Service (AKS)** within the client's Azure subscription. The platform integrates with Azure-native identity, secrets, API management, and monitoring services.

### 1.1 Reference Architecture

```mermaid
flowchart TD
    subgraph AZURE["Azure Subscription (Client Tenancy)"]
        subgraph AKS["Azure Kubernetes Service: Zora AI Cluster"]
            UI["Zora UI Container\n(React / SSO)"]
            API["Zora FastAPI\n(HTTPS / TLS 1.2)"]
            REDIS["Redis Message Broker"]
            AGENTS["Agent Pods\n· SQL Agents\n· Deep Analysis Agents\n· Report Gen Agents"]
            SKILLS["Skill & Tool Library\n(Finance Domain)"]
            PGDB["PostgreSQL 14.5\n(Analytics DB)"]
            MILVUS["Milvus Vector DB\n2 vCPU / 8 GiB / 30 GB SSD"]
            NIM["NVIDIA NIM Container\nGPT-OSS-120b\n⚙️ Production"]
        end

        subgraph AZURE_AI["Azure AI Services"]
            FOUNDRY["Azure AI Foundry\nGPT-OSS-120b\n🧪 Pilot"]
            APIM["Azure API Management\n(API Gateway)"]
        end

        subgraph AZURE_SEC["Azure Security Services"]
            ENTRA["Microsoft Entra ID\n(AuthN / AuthZ / SSO)"]
            KEYVAULT["Azure Key Vault\n(Secrets Management)"]
            MONITOR["Azure Monitor /\nApplication Insights"]
            DEFENDER["Microsoft Defender\nfor Cloud"]
        end

        subgraph DATA["Client Data Layer"]
            DATALAKE["Enterprise Data Lake\n(Finance Data)"]
        end
    end

    subgraph DELOITTE["Deloitte Artifact Store (Deployment-time only)"]
        HELM["Helm Charts / Signed Images"]
    end

    USER["Finance User"] -->|"Azure AD SSO"| UI
    UI --> APIM
    APIM --> API
    API --> REDIS
    REDIS --> AGENTS
    AGENTS --> SKILLS
    AGENTS -->|"🧪 Pilot"| FOUNDRY
    AGENTS -->|"⚙️ Production"| NIM
    AGENTS --> PGDB
    AGENTS --> MILVUS
    PGDB -->|Daily Incremental Refresh| DATALAKE
    ENTRA -->|Authenticates| UI
    ENTRA -->|Token Validation| APIM
    KEYVAULT -->|Secrets Injection| AGENTS
    AGENTS -.->|Traces & Logs| MONITOR
    DEFENDER -.->|Threat Detection| AKS
    DELOITTE -->|One-time secure download| AKS

    style AZURE fill:#e3f2fd,stroke:#1565c0
    style AKS fill:#bbdefb,stroke:#1976d2
    style AZURE_AI fill:#e8eaf6,stroke:#3949ab
    style AZURE_SEC fill:#fce4ec,stroke:#c62828
    style DELOITTE fill:#fff3e0,stroke:#e65100,stroke-dasharray: 5 5
    style NIM fill:#e8f5e9,stroke:#2e7d32
    style FOUNDRY fill:#ede7f6,stroke:#4527a0
```

### 1.2 Azure Infrastructure Specifications

| Component | Specification |
|---|---|
| **AKS Node Pool** | Standard_D64as_v6: 64 vCPUs, 256 GiB RAM |
| **Processor** | AMD EPYC 9004 (Genoa) |
| **OS** | Ubuntu Linux 22.04 LTS (AKSUbuntu-2204gen2containerd) |
| **Data Disk** | 1 × 1024 GiB Premium SSD |
| **OS Disk** | Up to 1024 GiB Premium SSD |
| **Vector Database** | Milvus DB: 2 vCPU, 8 GiB, 30 GB Premium SSD |
| **Kubernetes Service** | Azure Kubernetes Service (AKS) |
| **LLM: Pilot** | GPT-OSS-120b via Azure AI Foundry (private endpoint) |
| **LLM: Production** | GPT-OSS-120b via NVIDIA NIM on AKS GPU node pool |

---

## 2. Azure Security Architecture

The Core Framework's four-layer security model maps to Azure-native services as follows:

| Layer | Core Control | Azure Implementation |
|---|---|---|
| **Layer 4: Infrastructure** | Kubernetes Network Policies | AKS Network Policy (Azure CNI) |
| **Layer 4: Infrastructure** | Cloud account-level threat detection | Microsoft Defender for Cloud |
| **Layer 4: Infrastructure** | Encryption at rest | Azure Disk Encryption (Premium SSD) |
| **Layer 3: Application & API** | API gateway | Azure API Management (APIM) |
| **Layer 3: Application & API** | RBAC on endpoints | Azure RBAC + Entra ID groups |
| **Layer 3: Application & API** | Cloud secrets manager | Azure Key Vault (CSI Driver injection) |
| **Layer 2: Data** | Data lake access policy | Client data lake + Azure RBAC |
| **Layer 1: AI / Agent** | Cloud content safety (Pilot) | Azure AI Content Safety (AI Foundry built-in) |
| **Layer 1: AI / Agent** | LLM managed identity auth (Pilot) | Azure Managed Identity → AI Foundry |

---

## 3. Identity & Access Management: Azure

### 3.1 Authentication Flow

Authentication is anchored by **Microsoft Entra ID** (formerly Azure Active Directory). Zora integrates with the client's existing Entra ID tenant, supporting federated identity via SAML 2.0 or OIDC.

```mermaid
sequenceDiagram
    participant USER as Finance User
    participant BROWSER as Browser / Client Portal
    participant ENTRA as Microsoft Entra ID
    participant CORP_IDP as Client Corporate IdP\n(Optional Federation)
    participant APIM as Azure API Management
    participant ZORA as Zora UI (AKS)
    participant API as Zora FastAPI

    USER->>BROWSER: Access Zora application URL
    BROWSER->>ENTRA: Initiate OAuth 2.0 / OIDC flow
    ENTRA->>CORP_IDP: Federated authentication (SAML/OIDC)
    CORP_IDP-->>ENTRA: Identity assertion
    ENTRA-->>BROWSER: JWT access token
    BROWSER->>ZORA: Load UI with token
    ZORA->>APIM: API call with Bearer token
    APIM->>ENTRA: Token validation + claims extraction
    ENTRA-->>APIM: Roles, groups, scopes
    APIM->>API: Forwarded (validated) request
    API-->>ZORA: Authorized response
```

### 3.2 Azure Authorization Controls

| Control | Azure Implementation | Standard |
|---|---|---|
| RBAC | Azure RBAC: finance roles mapped to Entra ID groups | SOC 2 / ISO 27001 |
| API authorization | APIM policies enforce role-based scope per endpoint | NIST SP 800-53 |
| Least privilege | AKS Workload Identity (Managed Identity): no long-lived credentials | CIS AKS Benchmark |
| Secrets access | Key Vault access policies: only designated Managed Identities can read | CIS Azure Benchmark |
| Admin access | AKS cluster admin via Azure RBAC only; no shared admin accounts | Zero Trust |
| MFA | Enforced via Entra ID Conditional Access on Zora app registration | NIST AAL2 |
| Session management | Entra ID token expiry and refresh policies | OWASP ASVS |

### 3.3 Workload Identity: No Static Credentials

All pod-to-service authentication uses **Azure Managed Identities** via AKS Workload Identity. Agent pods authenticate to Azure Key Vault, AI Foundry, and Azure Monitor using short-lived OIDC tokens: no static credentials anywhere.

```mermaid
flowchart TD
    subgraph AKS["AKS Cluster"]
        POD["Agent Pod\n(Workload Identity)"]
    end
    ENTRA["Microsoft Entra ID\n(Token Issuance)"]
    KV["Azure Key Vault"]
    FOUNDRY["Azure AI Foundry"]
    MONITOR["Azure Monitor"]

    POD -->|OIDC token request| ENTRA
    ENTRA -->|Short-lived token| POD
    POD --> KV
    POD --> FOUNDRY
    POD --> MONITOR

    STATIC["❌ No static credentials\nin pods or env vars"] -.-> POD

    style STATIC fill:#ffebee,stroke:#c62828
    style AKS fill:#bbdefb,stroke:#1976d2
```

---

## 4. LLM Hosting on Azure

### 4.1 Pilot Phase: Azure AI Foundry

GPT-OSS-120b is served via a **private endpoint-connected Azure AI Foundry** deployment. Azure AI Foundry adds built-in **Azure AI Content Safety** filters that complement Zora's NeMo Guardrails.

```mermaid
flowchart TD
    subgraph AZURE["Azure Subscription: 🧪 Pilot"]
        subgraph AKS["AKS Cluster"]
            AGENT["Zora Agent Pod"]
            GUARD["NeMo Guardrails"]
        end
        subgraph FOUNDRY_ENV["Azure AI Foundry (Private Endpoint)"]
            CONTENT["Azure AI Content Safety"]
            LLM["GPT-OSS-120b"]
        end
        ENTRA["Managed Identity Auth"]
    end

    AGENT --> GUARD
    GUARD -->|Filtered prompt| ENTRA
    ENTRA -->|Token| FOUNDRY_ENV
    CONTENT --> LLM
    LLM -->|Completion| CONTENT
    CONTENT -->|Filtered| GUARD
    GUARD --> AGENT

    style FOUNDRY_ENV fill:#e8eaf6,stroke:#3949ab
    style GUARD fill:#fff3e0,stroke:#f57c00
```

### 4.2 Production Phase: NVIDIA NIM on AKS

GPT-OSS-120b is self-hosted in the `zora-models` namespace on an AKS GPU node pool. Zero external calls for LLM inference.

```mermaid
flowchart TD
    subgraph AZURE["Azure Subscription: ⚙️ Production"]
        subgraph AKS["AKS Cluster"]
            subgraph AGENT_NS["Namespace: zora-platform"]
                AGENT["Zora Agent Pod"]
                GUARD["NeMo Guardrails"]
            end
            subgraph MODEL_NS["Namespace: zora-models (Isolated)"]
                NIM["NVIDIA NIM Container\nGPT-OSS-120b"]
            end
            GPU["AKS GPU Node Pool\n(NVIDIA H100 / A100)"]
        end
    end

    AGENT --> GUARD
    GUARD -->|Intra-cluster TLS| NIM
    NIM --> GUARD
    GUARD --> AGENT
    NIM -.->|Runs on| GPU

    EXT["❌ Zero external calls\nfor LLM inference"] -.-> NIM

    style AGENT_NS fill:#bbdefb,stroke:#1976d2
    style MODEL_NS fill:#c8e6c9,stroke:#388e3c
    style EXT fill:#ffebee,stroke:#c62828
```

---

## 5. Data Security: Azure

### 5.1 Encryption at Rest

| Store | Azure Encryption |
|---|---|
| PostgreSQL (CFO Analytics DB) | Azure Disk Encryption: Premium SSD; CMK optional |
| Milvus Vector DB | Azure Disk Encryption: 30 GB Premium SSD; CMK optional |
| Agent DB (session data) | Azure Disk Encryption |
| Azure Storage (logs, config) | Azure Storage Service Encryption (256-bit AES) |
| Azure API Management | Customer data auto-encrypted at rest (Azure MySQL + Azure Storage) |

### 5.2 Secrets Management: Azure Key Vault

- All secrets (connection strings, API keys, certificates) stored in **Azure Key Vault**
- Injected into pods at runtime via the **Azure Key Vault Provider for Secrets Store CSI Driver**
- Key rotation managed via Key Vault versioning: zero redeployment required
- All Key Vault access events logged to Azure Monitor and exportable to SIEM

---

## 6. Application & API Security: Azure

### 6.1 Azure API Management

| Control | Specification |
|---|---|
| Transport | HTTPS / TLS 1.2+; TLS 1.0/1.1 disabled |
| Authentication | Microsoft Entra ID as default auth method |
| Authorization | Azure RBAC; per-API scope enforcement |
| Secrets | API keys stored in Key Vault named values integration |
| Rate limiting | Per subscription / user identity |
| DDoS protection | Azure DDoS Protection Standard on public endpoints |
| Proxy | APIM in front of all agent FastAPI services: no direct pod exposure |

### 6.2 Azure Network Security

```mermaid
flowchart TD
    INTERNET["Internet / Client Users"]
    DDOS["Azure DDoS Protection Standard"]
    WAF["Azure Application Gateway\nwith WAF (Optional)"]
    APIM["Azure API Management"]

    subgraph VNET["Azure Virtual Network (Client)"]
        subgraph AKS_SUB["AKS Subnet (Private)"]
            AKS["AKS Cluster\n(Private API Server)"]
        end
        subgraph DATA_SUB["Data Subnet"]
            PGDB["PostgreSQL Pod"]
            MILVUS["Milvus Pod"]
        end
        subgraph AI_SUB["AI Services (Private Endpoints)"]
            FOUNDRY_PE["Azure AI Foundry\n(Private Endpoint)"]
            KV_PE["Azure Key Vault\n(Private Endpoint)"]
        end
    end

    NSG["Network Security Groups\n(Per Subnet)"]

    INTERNET --> DDOS --> WAF --> APIM --> AKS
    AKS --> PGDB
    AKS --> MILVUS
    AKS --> FOUNDRY_PE
    AKS --> KV_PE
    NSG -.->|Controls| AKS_SUB
    NSG -.->|Controls| DATA_SUB
    NSG -.->|Controls| AI_SUB

    style VNET fill:#e3f2fd,stroke:#1565c0
    style AKS_SUB fill:#bbdefb,stroke:#1976d2
    style DATA_SUB fill:#e8f5e9,stroke:#2e7d32
    style AI_SUB fill:#e8eaf6,stroke:#3949ab
```

Private Endpoints are used for Azure AI Foundry and Key Vault: all traffic traverses the Azure backbone, never the public internet. Azure Private DNS Zones resolve private endpoint FQDNs within the VNet.

---

## 7. Infrastructure Security: AKS & Azure

### 7.1 AKS Cluster Hardening

| Control | Implementation |
|---|---|
| Namespace isolation | `zora-models` and `zora-platform` namespaces; Network Policy enforced |
| Pod security | AKS Pod Security Admission: `restricted` profile; non-root, no privilege escalation |
| Workload Identity | Azure Workload Identity: short-lived OIDC tokens; no static service account tokens |
| Private cluster | AKS API server endpoint private: accessible within VNet only |
| OS hardening | AKSUbuntu-2204gen2containerd; automatic OS patches via AKS node image upgrades |
| Image integrity | Signed Deloitte images; AKS Image Integrity (Notary v2) optionally enforced |
| Helm integrity | Declarative Helm deployment; no manual kubectl exec in production |

### 7.2 Microsoft Defender for Cloud

- **Defender for Containers:** Continuous vulnerability scanning of AKS node images and running workloads; runtime anomaly detection
- **Defender for Key Vault:** Alerts on suspicious access patterns (bulk enumeration, unexpected source IPs)
- **Secure Score:** Ongoing visibility into security posture gaps and remediation guidance
- **Security Alerts:** Exportable to SIEM via Azure Event Hub

---

## 8. Monitoring & Observability: Azure

### 8.1 Azure Monitoring Stack

Zora emits all agent traces, prompt interactions, and system events via **OpenTelemetry (OTel)**. The OTel Collector runs within the AKS cluster and forwards data to the client's Azure observability stack. Optionally, a **LangFuse** instance can be deployed within the client's environment for agent trace visualization. The client is responsible for deploying and operating all downstream monitoring infrastructure.

```mermaid
flowchart TD
    subgraph ZORA["Zora Platform (AKS)"]
        OTEL_INSTR["OTel Instrumentation\n(Embedded in Zora)"]
        OTEL["OpenTelemetry Collector"]
        AKS_LOGS["AKS Container Logs"]
    end

    subgraph CLIENT_OPT["Optional: Client-Deployed"]
        LANGFUSE["LangFuse\n(Agent Trace Viewer)"]
    end

    subgraph AZURE_OBS["Azure Observability Stack (Client-operated)"]
        APP_INS["Azure Application Insights"]
        LOG_AN["Azure Log Analytics Workspace"]
        AZ_MON["Azure Monitor\n(Metrics + Alerts)"]
        SENTINEL["Microsoft Sentinel\n(SIEM / SOAR)"]
    end

    OTEL_INSTR --> OTEL
    AKS_LOGS --> LOG_AN
    OTEL -->|Traces| LANGFUSE
    OTEL --> APP_INS
    OTEL --> LOG_AN
    APP_INS --> AZ_MON
    LOG_AN --> AZ_MON
    AZ_MON --> SENTINEL

    style ZORA fill:#bbdefb,stroke:#1976d2
    style CLIENT_OPT fill:#fff9c4,stroke:#f9a825
    style AZURE_OBS fill:#fce4ec,stroke:#c62828
```

### 8.2 Azure-Specific Security Event Sources

| Event Type | Azure Source | Export Target |
|---|---|---|
| Agent traces (prompts, responses, tool calls) | OTel Collector | App Insights / Log Analytics |
| API authentication failures | Azure APIM + Entra ID | Microsoft Sentinel |
| Key Vault secret access | Key Vault Diagnostic Logs | Sentinel / Log Analytics |
| AKS pod anomalies | Defender for Containers | Sentinel / Azure Monitor |
| SSO / MFA events | Entra ID Sign-in Logs | Sentinel / Log Analytics |
| Network flow anomalies | Azure NSG Flow Logs | Log Analytics |
| LLM token usage | OTel metrics + AI Foundry (Pilot) | Log Analytics |

---

## 9. Azure Control Matrix Delta

This table covers only the Azure-specific implementation of controls defined in the Core Framework. Refer to the Core Framework Section 12 for the full baseline.

| Domain | Control | Azure Implementation |
|---|---|---|
| **AI Security** | Content safety (Pilot) | Azure AI Content Safety: built into AI Foundry endpoint |
| **AI Security** | LLM auth (Pilot) | Azure Managed Identity → AI Foundry private endpoint |
| **Data Security** | Encryption at rest | Azure Disk Encryption (platform-managed or CMK) |
| **Data Security** | Secrets management | Azure Key Vault + CSI Driver pod injection |
| **Application Security** | Authentication | Microsoft Entra ID: OAuth 2.0 / OIDC; MSAL in UI |
| **Application Security** | MFA | Entra ID Conditional Access: enforced on Zora app registration |
| **Application Security** | API gateway | Azure API Management: proxy, rate limiting, Entra ID auth |
| **Application Security** | Workload identity | AKS Workload Identity: short-lived OIDC tokens |
| **Cyber Security** | Network isolation | Azure VNet; private AKS cluster; Private Endpoints; NSGs; Private DNS |
| **Cyber Security** | Threat detection | Microsoft Defender for Cloud (Containers + Key Vault) |
| **Cyber Security** | Container registry | Optional: Azure Container Registry (ACR) for client-managed image mirroring |
| **Cyber Security** | Monitoring / SIEM | Azure Monitor + Log Analytics + Microsoft Sentinel |
| **Cyber Security** | Pen testing policy | Azure-compliant pen testing under Microsoft pen testing policy |

---

## 10. Appendix: Azure Infrastructure Specifications

### Primary Node Pool: Zora Agent & Platform

| Parameter | Value |
|---|---|
| Machine Family | General-purpose (D series) |
| Instance Type | Standard_D64as_v6 |
| vCPUs | 64 |
| Memory | 256 GiB |
| Data Disk | 1 × 1024 GiB Premium SSD |
| OS Disk | Up to 1024 GiB Premium SSD |
| Processor | AMD EPYC 9004 (Genoa) \[x86-64\] |
| Node Image | AKSUbuntu-2204gen2containerd-202507.21.0 |
| Operating System | Ubuntu Linux 22.04 LTS |
| Kubernetes Service | Azure Kubernetes Service (AKS) |

### LLM Hosting: Pilot (Azure AI Foundry)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Service | Microsoft Azure AI Foundry (formerly Azure AI Studio) |
| Deployment Type | Managed online endpoint: client Azure subscription |
| Authentication | Azure Managed Identity |
| Network Access | Private Endpoint only |
| Content Filtering | Azure AI Content Safety (built-in) |

### LLM Hosting: Production (NVIDIA NIM on AKS)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Container | NVIDIA NIM (NVAIE / NIM software stack) |
| Deployment | AKS GPU node pool: `zora-models` namespace |
| GPU (Recommended) | NVIDIA H100 80GB or equivalent |
| Network Access | Intra-cluster only; Network Policy restricts to agent pods |

### Vector Database

| Parameter | Value |
|---|---|
| Technology | Milvus DB |
| vCPUs | 2 |
| Memory | 8 GiB |
| Storage | 30 GB Premium SSD |

---

*This annex should be read in conjunction with the Zora AI Digital Worker Platform: Security Design: Core Framework. For on-premises / PCAI GPU deployments, refer to the Zora PCAI Security Reference.*

*Document prepared by Deloitte Zora AI Platform Team. Annex Version 1.1 | Core Framework Version 2.1.*