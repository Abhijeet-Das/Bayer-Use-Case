# Zora AI Digital Worker Platform: Security Design
### Annex C: SAP Business Technology Platform (BTP) Deployment

**Document Type:** Cloud Deployment Annex  
**Platform:** Zora AI CFO Insights  
**Deployment Target:** Client SAP BTP Account (Kyma Runtime)  
**Core Framework Version:** 1.0  
**Annex Version:** 1.0  
**Classification:** Confidential

> **Prerequisites:** This annex covers SAP BTP-specific security architecture, services, and infrastructure only. Read the **Zora AI Digital Worker Platform: Security Design: Core Framework** first for platform-agnostic principles, agent security, data handling protocols, and the full control matrix baseline.

---

## Version History

| Version | Date | Changes | Author |
|---|---|---|---|
| 1.0 | 2026-03-19 | Restructured from standalone BTP doc to annex format; added Pilot/Production LLM hosting model | Deloitte Zora AI Platform Team |
| 1.1 | 2026-03-24 | Aligned with Core Framework v2.1: updated platform name, monitoring to OTel-first, em dash removal | Deloitte Zora AI Platform Team |

---

## Table of Contents

1. [SAP BTP Deployment Overview](#1-sap-btp-deployment-overview)
2. [SAP BTP Security Architecture](#2-sap-btp-security-architecture)
3. [Identity & Access Management: SAP BTP](#3-identity--access-management--sap-btp)
4. [LLM Hosting on SAP BTP](#4-llm-hosting-on-sap-btp)
5. [Data Security: SAP BTP](#5-data-security--sap-btp)
6. [Application & API Security: SAP BTP](#6-application--api-security--sap-btp)
7. [Infrastructure Security: Kyma & BTP](#7-infrastructure-security--kyma--btp)
8. [Monitoring & Observability: SAP BTP](#8-monitoring--observability--sap-btp)
9. [SAP BTP Control Matrix Delta](#9-sap-btp-control-matrix-delta)
10. [Appendix: SAP BTP Deployment Notes](#10-appendix-sap-btp-deployment-notes)

---

## 1. SAP BTP Deployment Overview

In the SAP BTP deployment, Zora AI Digital Workers run as containerized workloads within the client's **SAP BTP account**, on the **Kyma Kubernetes runtime**. This deployment topology is uniquely positioned for clients whose financial data resides primarily in SAP systems (S/4HANA, Datasphere, SAP Analytics Cloud), as Zora integrates natively with SAP's governed data and identity layer.

### 1.1 Reference Architecture

```mermaid
flowchart TD
    subgraph SAP_BTP["SAP Business Technology Platform (Client Tenancy)"]
        subgraph KYMA["Kyma Runtime: Zora AI Cluster"]
            UI["Zora UI Container\n(React / SSO)"]
            API["Zora FastAPI\n(HTTPS / TLS 1.2)"]
            REDIS["Redis Message Broker"]
            AGENTS["Agent Pods\n· SQL Agents\n· Deep Analysis Agents\n· Report Gen Agents"]
            SKILLS["Skill & Tool Library\n(Finance Domain)"]
            PGDB["PostgreSQL 14.5\n(Analytics DB)"]
            MILVUS["Milvus Vector DB\n(Knowledge Base)"]
            NIM["NVIDIA NIM Container\nGPT-OSS-120b\n⚙️ Production"]
        end

        subgraph SAP_SVCS["SAP Platform Services"]
            AI_CORE["SAP AI Core\nGPT-OSS-120b\n🧪 Pilot"]
            GEN_HUB["SAP Generative AI Hub\n(Model Governance)"]
            CIS["SAP Cloud Identity Services\n(AuthN / AuthZ / SSO)"]
            DATASPHERE["SAP Datasphere\n(Business Data Fabric)"]
            SAC["SAP Analytics Cloud"]
        end

        subgraph SAP_ERP["Enterprise Systems"]
            S4["SAP S/4HANA RISE"]
            SNOW["Snowflake / Data Lake"]
        end
    end

    subgraph DELOITTE["Deloitte Artifact Store (Deployment-time only)"]
        HELM["Helm Charts / Signed Images"]
    end

    USER["Finance User\n(Client Employee)"] -->|"SAP Fiori Launchpad SSO"| UI
    UI --> API
    API --> REDIS
    REDIS --> AGENTS
    AGENTS --> SKILLS
    AGENTS -->|"🧪 Pilot"| AI_CORE
    AI_CORE --> GEN_HUB
    AGENTS -->|"⚙️ Production"| NIM
    AGENTS --> PGDB
    AGENTS --> MILVUS
    PGDB -->|Daily Incremental Refresh| DATASPHERE
    DATASPHERE -->|Existing Access Controls| S4
    DATASPHERE --> SNOW
    CIS -->|Authenticates| UI
    DELOITTE -->|One-time secure download| KYMA

    style SAP_BTP fill:#e8f5e9,stroke:#2e7d32
    style KYMA fill:#c8e6c9,stroke:#388e3c
    style SAP_SVCS fill:#e3f2fd,stroke:#1565c0
    style DELOITTE fill:#fff3e0,stroke:#e65100,stroke-dasharray: 5 5
    style NIM fill:#c8e6c9,stroke:#388e3c
    style AI_CORE fill:#bbdefb,stroke:#1565c0
```

### 1.2 SAP BTP Deployment Notes

The BTP deployment has a distinct advantage for SAP-centric clients: Zora integrates directly with **SAP Datasphere** as the governed semantic data layer, meaning all existing SAP data access controls: including row-level security and data access policies: are automatically inherited by Zora agents. Agents have no direct access to S/4HANA or source systems.

---

## 2. SAP BTP Security Architecture

The Core Framework's four-layer security model maps to SAP BTP and Kyma-native services as follows:

| Layer | Core Control | SAP BTP / Kyma Implementation |
|---|---|---|
| **Layer 4: Infrastructure** | Kubernetes Network Policies | Kyma runtime network policies |
| **Layer 4: Infrastructure** | Cloud account-level controls | BTP account IAM + Audit Logging |
| **Layer 4: Infrastructure** | Encryption at rest | BTP / Kyma persistent volume encryption |
| **Layer 3: Application & API** | API gateway | BTP API Management (or Kyma API Gateway) |
| **Layer 3: Application & API** | RBAC on endpoints | BTP IAM + SAP CIS role assignments |
| **Layer 3: Application & API** | Cloud secrets manager | BTP Secret Store (Kubernetes Secrets + BTP binding) |
| **Layer 2: Data** | Data access policy enforcement | SAP Datasphere ABAC: role-based + row-level policies |
| **Layer 1: AI / Agent** | Cloud content safety (Pilot) | SAP Generative AI Hub content governance |
| **Layer 1: AI / Agent** | LLM governed access (Pilot) | SAP AI Core scoped service binding |

---

## 3. Identity & Access Management: SAP BTP

### 3.1 Authentication Flow

Authentication on SAP BTP is anchored by **SAP Cloud Identity Services (CIS)** as the central identity provider. Zora is accessed via the **SAP Fiori Launchpad** tile: users authenticate once through their SAP session and launch Zora without a separate login flow.

```mermaid
sequenceDiagram
    participant USER as Finance User
    participant FIORI as SAP Fiori Launchpad
    participant CIS as SAP Cloud Identity Services
    participant IDP as Client Corporate IdP\n(SAML / OIDC Federation)
    participant ZORA as Zora UI (Kyma)
    participant API as Zora FastAPI

    USER->>FIORI: Access Zora tile
    FIORI->>CIS: Initiate SSO flow
    CIS->>IDP: Federated authentication (SAML/OIDC)
    IDP-->>CIS: Identity assertion
    CIS-->>FIORI: JWT / SAP session token
    FIORI->>ZORA: Launch Zora UI with token
    ZORA->>API: API call with Bearer token
    API->>CIS: Token validation
    CIS-->>API: Claims (roles, groups)
    API-->>ZORA: Authorized response
```

### 3.2 SAP BTP Authorization Controls

| Control | SAP BTP Implementation | Standard |
|---|---|---|
| RBAC | Zora UI + API enforce finance role segmentation mapped to SAP CIS groups | SOC 2 / ISO 27001 |
| ABAC | Data access policies inherited from SAP Datasphere semantic layer | SAP Access Control |
| Least privilege | Each agent pod operates under a scoped Kubernetes ServiceAccount | CIS Benchmark |
| SSO integration | SAP CIS: single domain (cloud.sap.com) for prod and non-prod | SAP Reference Architecture |
| Session management | Managed by SAP Cloud Identity Services; chat history scoped to authenticated user | OWASP ASVS |
| API authorization | Bearer token validated against SAP CIS per request | NIST SP 800-53 |

### 3.3 SAP Datasphere Data Access Segmentation

A defining security characteristic of the BTP deployment: **Zora inherits and enforces SAP Datasphere's existing data access controls**. Agents query exclusively through the Datasphere semantic layer: no direct access to S/4HANA or source systems.

```mermaid
flowchart TD
    AGENT["Zora SQL / Deep Analysis Agent"]
    DS["SAP Datasphere\n(Semantic Layer)"]
    POLICY["Datasphere Data Access Policies\n(Role-based, Row-level, Column-level)"]
    S4["S/4HANA Finance Data"]
    SNOW["Snowflake / External Data Lake"]

    AGENT -->|Query via governed API| DS
    DS --> POLICY
    POLICY -->|Enforced scope| S4
    POLICY -->|Enforced scope| SNOW

    NOTE["❌ Agents have NO direct access\nto S/4HANA or source systems"] -.-> AGENT

    style NOTE fill:#ffebee,stroke:#c62828
    style POLICY fill:#e8f5e9,stroke:#2e7d32
    style DS fill:#e3f2fd,stroke:#1565c0
```

---

## 4. LLM Hosting on SAP BTP

### 4.1 Pilot Phase: SAP AI Core + Generative AI Hub

During the Pilot phase, GPT-OSS-120b is hosted via **SAP AI Core** within the client's BTP tenancy, governed by **SAP Generative AI Hub** for model access control and usage governance. All inference occurs within the BTP account.

```mermaid
flowchart TD
    subgraph BTP["SAP BTP (Client Tenancy): 🧪 Pilot"]
        subgraph KYMA["Kyma Cluster"]
            AGENT["Zora Agent Pod"]
            GUARD["NeMo Guardrails"]
        end
        subgraph SAP_AI["SAP AI Services"]
            GEN_HUB["SAP Generative AI Hub\n(Access Governance)"]
            AI_CORE["SAP AI Core\n(GPT-OSS-120b Runtime)"]
        end
    end

    AGENT --> GUARD
    GUARD -->|Filtered prompt| GEN_HUB
    GEN_HUB -->|Authorized request| AI_CORE
    AI_CORE -->|Completion| GUARD
    GUARD --> AGENT

    EXT["❌ No data leaves\nBTP tenancy"] -.-> AI_CORE

    style BTP fill:#e8f5e9,stroke:#2e7d32
    style SAP_AI fill:#e3f2fd,stroke:#1565c0
    style GUARD fill:#fff3e0,stroke:#f57c00
    style EXT fill:#ffebee,stroke:#c62828
```

SAP Generative AI Hub provides model access governance, usage metering, and content policy controls that complement Zora's NeMo Guardrails.

### 4.2 Production Phase: NVIDIA NIM on Kyma

For Production, GPT-OSS-120b is self-hosted as an **NVIDIA NIM container** in the `zora-models` namespace within the Kyma cluster. Zero external calls for LLM inference: the model runs entirely within the client's BTP environment.

```mermaid
flowchart TD
    subgraph BTP["SAP BTP (Client Tenancy): ⚙️ Production"]
        subgraph KYMA["Kyma Runtime"]
            subgraph AGENT_NS["Namespace: zora-platform"]
                AGENT["Zora Agent Pod"]
                GUARD["NeMo Guardrails"]
            end
            subgraph MODEL_NS["Namespace: zora-models (Isolated)"]
                NIM["NVIDIA NIM Container\nGPT-OSS-120b"]
            end
            GPU["GPU-enabled Node\n(NVIDIA H100 / A100)"]
        end
    end

    AGENT --> GUARD
    GUARD -->|Intra-cluster TLS| NIM
    NIM --> GUARD
    GUARD --> AGENT
    NIM -.->|Runs on| GPU

    EXT["❌ Zero external calls\nfor LLM inference"] -.-> NIM

    style AGENT_NS fill:#c8e6c9,stroke:#388e3c
    style MODEL_NS fill:#a5d6a7,stroke:#2e7d32
    style EXT fill:#ffebee,stroke:#c62828
```

---

## 5. Data Security: SAP BTP

### 5.1 Encryption at Rest

| Store | SAP BTP / Kyma Encryption |
|---|---|
| PostgreSQL (CFO Analytics DB) | Kyma persistent volume encryption; row-level security enforced |
| Milvus Vector DB | Kyma persistent volume encryption; access restricted to agent service accounts |
| Agent DB (session data) | Kyma persistent volume encryption; scoped per authenticated SAP identity |

### 5.2 Secrets Management: BTP Secret Store

- All secrets (connection strings, API keys, SAP service bindings) stored in the **BTP Secret Store** via Kubernetes Secrets bound to BTP service instances
- Secrets are not stored in Helm values files, container images, or environment variable definitions
- SAP service bindings (AI Core, Datasphere) are managed via BTP service instances: credentials are rotated through the BTP service operator without manual intervention
- All BTP-level credential access is captured in **BTP Audit Logging**

---

## 6. Application & API Security: SAP BTP

### 6.1 API Gateway Security

| Control | SAP BTP Specification |
|---|---|
| Transport | HTTPS / TLS 1.2 minimum |
| Proxy protection | BTP API Management or Kyma API Gateway in front of all agent services |
| Authentication | Bearer token validated against SAP Cloud Identity Services |
| Secrets | API keys stored in BTP Secret Store; referenced via Kubernetes secret bindings |
| Input validation | All API inputs parameterized and validated before passing to agent layer |
| Output validation | Agent outputs pass through NeMo Guardrails before reaching the user |

### 6.2 SAP Fiori Launchpad Integration

A security advantage specific to BTP: Zora is launched from the **SAP Fiori Launchpad** tile. This means:

- Users do not access Zora through a separate URL: the Fiori tile enforces SAP session authentication before launch
- No additional login prompt; session trust is already established via SAP CIS
- User Management and Chat History are scoped to the authenticated SAP Cloud Identity Services identity
- SAP CIS handles session expiry and token refresh, eliminating Zora's need to manage credentials

---

## 7. Infrastructure Security: Kyma & BTP

### 7.1 Kyma Cluster Security

| Control | Implementation |
|---|---|
| Namespace isolation | `zora-models` and `zora-platform` namespaces; Kyma network policies enforced |
| Pod security | Pods run with non-root users; Kubernetes security contexts enforced |
| Network policies | Kyma network policies restrict inter-pod communication to defined service dependencies |
| Secrets management | Kubernetes Secrets bound to BTP Secret Store: no credentials in config or environment variables |
| Image provenance | All Zora images sourced from Deloitte's signed artifact store; no public registry pulls in production |
| Helm integrity | Declarative Helm deployment: fully auditable; no manual pod modification |

### 7.2 BTP Account-Level Security

- **SAP BTP Identity & Access Management** governs who can administer the BTP account, Kyma cluster, and service instances
- **BTP Audit Logging** captures all platform-level administrative and service access events
- **SAP Cloud Connector** (if applicable) manages secure, outbound-only connectivity to on-premise S/4HANA systems: no inbound firewall ports opened from on-premise to BTP

### 7.3 Deployment Pipeline Security

```mermaid
sequenceDiagram
    participant DELOITTE as Deloitte Artifact Store
    participant CLIENT as Client Admin Team
    participant KYMA as Kyma Cluster
    participant HELM as Helm Deployment

    DELOITTE->>CLIENT: Secure time-limited download link\n(Signed Images + Helm Charts)
    CLIENT->>CLIENT: Verify image checksums / signatures
    CLIENT->>KYMA: kubectl / Helm deploy
    HELM->>KYMA: Deploy UI Pod + Agent Pods + PostgreSQL
    CLIENT->>KYMA: Deploy LLM\n(SAP AI Core binding: Pilot\nor NIM on Kyma: Production)
    CLIENT->>KYMA: Configure SSO via SAP Cloud Identity Services
    Note over DELOITTE,KYMA: After deployment, Deloitte has NO\npersistent runtime access to the cluster
```

---

## 8. Monitoring & Observability: SAP BTP

### 8.1 SAP BTP Monitoring Stack

Zora emits all agent traces, prompt interactions, and system events via **OpenTelemetry (OTel)**. The OTel Collector runs within the Kyma cluster and forwards data to the client's SAP observability stack. Optionally, a **LangFuse** instance can be deployed within the client's BTP environment for agent trace visualization. The client is responsible for deploying and operating all downstream monitoring infrastructure.

```mermaid
flowchart TD
    subgraph ZORA["Zora Platform (Kyma)"]
        OTEL_INSTR["OTel Instrumentation\n(Embedded in Zora)"]
        OTEL["OpenTelemetry Collector"]
        KYMA_LOGS["Kyma Container Logs"]
    end

    subgraph CLIENT_OPT["Optional: Client-Deployed"]
        LANGFUSE["LangFuse\n(Agent Trace Viewer)"]
    end

    subgraph SAP_OBS["SAP / Client Observability (Client-operated)"]
        SAP_ALM["SAP Cloud ALM\n(Application Lifecycle Mgmt)"]
        BTP_AUDIT["BTP Audit Logging"]
        SIEM["Client SIEM Platform"]
    end

    OTEL_INSTR --> OTEL
    KYMA_LOGS --> SAP_ALM
    OTEL -->|Traces| LANGFUSE
    OTEL --> SAP_ALM
    OTEL --> SIEM
    BTP_AUDIT --> SIEM

    style ZORA fill:#e8f5e9,stroke:#2e7d32
    style CLIENT_OPT fill:#fff9c4,stroke:#f9a825
    style SAP_OBS fill:#e3f2fd,stroke:#1565c0
```

### 8.2 SAP BTP-Specific Security Event Sources

| Event Type | BTP Source | Export Target |
|---|---|---|
| Agent traces (prompts, responses, tool calls) | OTel Collector | SAP Cloud ALM / SIEM |
| API authentication failures | BTP API Management + SAP CIS | SIEM / BTP Audit Log |
| Service binding access | BTP Audit Logging | SIEM |
| Kyma pod events | Kyma cluster logs | SAP Cloud ALM |
| SSO login / logout events | SAP Cloud Identity Services | SIEM / Client IAM Audit |
| LLM token usage | OTel metrics + SAP AI Core (Pilot) | SAP Cloud ALM |
| Datasphere data access | Datasphere audit logs | Client SIEM |

---

## 9. SAP BTP Control Matrix Delta

This table covers only the SAP BTP-specific implementation of controls defined in the Core Framework.

| Domain | Control | SAP BTP Implementation |
|---|---|---|
| **AI Security** | Content governance (Pilot) | SAP Generative AI Hub: model access policies and usage governance |
| **AI Security** | LLM governed access (Pilot) | SAP AI Core scoped service binding: no direct model endpoint access |
| **Data Security** | Encryption at rest | Kyma persistent volume encryption (BTP-managed) |
| **Data Security** | Secrets management | BTP Secret Store + Kubernetes Secrets via BTP service operator |
| **Data Security** | Data access governance | SAP Datasphere ABAC: role-based and row-level policies; agents query only via semantic layer |
| **Application Security** | Authentication | SAP Cloud Identity Services: SAML/OIDC federation; single cloud.sap.com domain |
| **Application Security** | SSO entry point | SAP Fiori Launchpad tile: no separate Zora login; session trust from SAP CIS |
| **Application Security** | Authorization | BTP IAM + SAP CIS group-based role mapping; Datasphere ABAC inherited |
| **Application Security** | API gateway | BTP API Management or Kyma API Gateway |
| **Cyber Security** | Network isolation | Kyma network policies; namespace separation; BTP account boundary |
| **Cyber Security** | Outbound connectivity | SAP Cloud Connector: outbound-only; no inbound firewall ports for on-premise S/4HANA |
| **Cyber Security** | Audit logging | BTP Audit Logging: all platform and service access events |
| **Cyber Security** | Monitoring / ALM | SAP Cloud ALM + OpenTelemetry export to SIEM |
| **Cyber Security** | Pen testing policy | SAP BTP pen testing under SAP's shared responsibility model |

---

## 10. Appendix: SAP BTP Deployment Notes

### Kyma Runtime

| Parameter | Value |
|---|---|
| Runtime | SAP BTP Kyma (managed Kubernetes) |
| Kubernetes Distribution | Kyma (based on upstream Kubernetes) |
| Node sizing | Dependent on BTP plan; equivalent compute to 64 vCPU / 256 GiB recommended for production |
| OS | Managed by SAP (Garden Linux / BTP node image) |
| Namespace structure | `zora-platform` (agents, UI, DB), `zora-models` (NIM: Production) |

### LLM Hosting: Pilot (SAP AI Core)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Service | SAP AI Core (managed LLM runtime within BTP) |
| Governance | SAP Generative AI Hub |
| Authentication | SAP service binding (no static credentials) |
| Network Access | Within BTP tenancy: no public endpoint |

### LLM Hosting: Production (NVIDIA NIM on Kyma)

| Parameter | Value |
|---|---|
| Model | GPT-OSS-120b |
| Container | NVIDIA NIM (NVAIE / NIM software stack) |
| Deployment | Kyma GPU-enabled node: `zora-models` namespace |
| GPU (Recommended) | NVIDIA H100 80GB or equivalent |
| Network Access | Intra-cluster only; Kyma network policy restricts to agent pods |

### Vector Database

| Parameter | Value |
|---|---|
| Technology | Milvus DB |
| vCPUs | 2 |
| Memory | 8 GiB |
| Storage | 30 GB persistent volume (BTP-managed) |

### Key SAP Service Dependencies

| Service | Role in Zora Deployment |
|---|---|
| SAP Cloud Identity Services | Identity provider: AuthN, SSO, token issuance |
| SAP Datasphere | Governed data access layer: all agent queries routed through |
| SAP AI Core | LLM runtime (Pilot phase) |
| SAP Generative AI Hub | Model access governance and content policy (Pilot phase) |
| SAP Analytics Cloud | Analytics and reporting complement (client-dependent) |
| BTP Audit Logging | Platform-level event capture: admin and service access |
| SAP Cloud ALM | Application lifecycle monitoring and alerting |

---

*This annex should be read in conjunction with the Zora AI Digital Worker Platform: Security Design: Core Framework. For hyperscaler-specific security recommendations (Azure or AWS), refer to the corresponding annex.*

*Document prepared by Deloitte Zora AI Platform Team. Annex Version 1.1 | Core Framework Version 2.1.*