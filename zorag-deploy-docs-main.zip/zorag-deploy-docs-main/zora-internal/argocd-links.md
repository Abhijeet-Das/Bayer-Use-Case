---
title: argocd environments
description: table list of all active argoCD environments.
---

# ArgoCD Environments

Argo CD is a Kubernetes-native, declarative GitOps continuous delivery tool that automates application deployment and lifecycle management. It uses Git repositories as the single source of truth for Kubernetes manifests, ensuring that the live cluster state always matches the desired state defined in Git.

Read the docs: https://argo-cd.readthedocs.io/

## Azure Environments
- Dev02: https://argocd.zoraai-dev02-eus2-internal.dev02.zoraai.deloitteinnovation.us/applications
- Dev: https://argocd.zoraai-dev-eus-internal.dev.zoraai.deloitteinnovation.us/applications
- QA: https://argocd.zoraai-qa-eus2-internal.qa.zoraai.eng.deloitte.com/applications
- Demo EUS: https://argocd.zoraai-demo-eus-internal.demo.zoraai.eng.deloitte.com/applications
- Demo WUS: https://argocd.zoraai-demo-wus-internal.wus.demo.zoraai.eng.deloitte.com/
- Lab: https://argocd.zoraai-lab-eus-internal.lab.zoraai.eng.deloitte.com/applications
- Dev03: https://argocd.zoraai-dev03-eus2-internal.dev03.zoraai.eng.deloitte.com/applications
- Dev04: https://argocd.zoraai-dev04-eus2-internal.dev04.zoraai.eng.deloitte.com/applications
- Dev05: https://argocd.zoraai-dev05-eus2.dev05.zoraai.eng.deloitte.com/
- Dev06: https://argocd.zoraai-dev06-eus2.dev06.zoraai.eng.deloitte.com/
- Train01: https://argocd.zoraai-train01-eus.train01.zoraai.eng.deloitte.com/
- Enbridge Demo: https://argocd.enbridgedemo-eus.enbridgedemo.deloitteinnovation.us/
 
## AWS Environments
- SUT Dev: https://argocd.zoraai-sut-eus.dev.sut.zoraai.eng.deloitte.com/
- SUT QA: https://argocd.zoraai-qa-sut-eus.qa.sut.zoraai.eng.deloitte.com/
- SUT QA1: https://argocd.zoraai-sut-qa1-eus.qa1.sut.zoraai.eng.deloitte.com/applications
- SUT ppd: https://argocd.zoraai-sut-ppd-eus.ppd.sut.zoraai.eng.deloitte.com/
- Payment X Advise: https://argocd.zoraai-advise-eus.dev.advise.zoraai.eng.deloitte.com/

## Client Specific (Azure) Environments
- Colgate Dev: https://argocd.zoraai-colgate-pd-eus.pd.colgate.zoraai.eng.deloitte.com/
- Colgate Prod: https://argocd.zoraai-colgate-cp-eus.colgate.zoraai.eng.deloitte.com/