# PostgreSQL Role-Based Users — Runbook

Runbook for creating and managing per-service database users on `zora-ai-postgres2`. Replaces the shared `postgres` superuser with least-privilege, role-based access.

## Background

Previously all apps connected as `postgres` superuser. This runbook covers deploying dedicated DB users with minimal permissions per service. The init-db Job (`values-zora-ai-postgres-init-db.yaml`) is the source of truth for user creation and grants.

## Users & Permissions Matrix

| User | DB | Schema | Permissions | Used by |
|------|-----|--------|-------------|---------|
| `zora_backend_user` | `customer_data` | public | SELECT (read-only) | Backend API |
| `zora_backend_user` | `zora_config` | public | SELECT (read-only) | Backend API |
| `zora_backend_user` | `rbac_db` | public | SELECT, INSERT, UPDATE, DELETE (no CREATE) | Backend API |
| `zora_backend_user` | `zora_app` | public | SELECT, INSERT, UPDATE, DELETE + CREATE (**owner**) | Backend API |
| `zora_customerdata_user` | `customer_data` | all schemas (varies by env) | SELECT, INSERT, UPDATE, DELETE + CREATE (**owner** of all schemas) | Customer Data Server |
| `zora_config_user` | `zora_config` | public | SELECT, INSERT, UPDATE, DELETE + CREATE (**owner**) | Configuration Server |
| `zora_engine_cfo_user` | `customer_data` | cfo_data | SELECT (read-only) | Engine (CFO agent) |
| `zora_engine_cfo_user` | `skill_storage` | public | SELECT (read-only) | Engine (CFO agent) |
| `zora_engine_cfo_user` | `synthetic_data_v3` | cfo_data | SELECT (read-only, optional DB) | Engine (CFO agent) |
| `zora_engine_em_user` | `customer_data` | em_data | SELECT (read-only) | Engine (EM agent) |
| `zora_engine_em_user` | `skill_storage` | public | SELECT (read-only) | Engine (EM agent) |
| `zora_engine_em_user` | `synthetic_data_v3` | em_data | SELECT (read-only, optional DB) | Engine (EM agent) |
| `zora_rbac_backend_user` | `rbac_db` | public | SELECT, INSERT, UPDATE, DELETE + CREATE (**owner**) | RBAC Backend |
| `zora_agent_skills_user` | `skill_storage` | public | SELECT, INSERT, UPDATE, DELETE + CREATE (**owner**) | Agent Skills Job |
| `zora_developer` | all databases | all schemas | ALL PRIVILEGES (DML + DDL, no role management) | Manual developer access |

### Database Owners

Each database has a designated owner user — the service that runs Alembic migrations (DDL: CREATE TABLE, ALTER TABLE, DROP INDEX, etc.). All existing **schemas, tables, and sequences** must be transferred from `postgres` to the owner as a **one-time manual step** per environment (see [Transfer Ownership](#6-transfer-ownership-one-time-per-env)).

| Database | Owner user | Why |
|----------|-----------|-----|
| `customer_data` | `zora_customerdata_user` | Customer Data Server runs migrations (schemas vary by env: public, cfo_data, em_data, cfo_data_v1, collection_advisory, payment_data_dictionary, revenue_advisor) |
| `zora_config` | `zora_config_user` | Configuration Server runs migrations |
| `zora_app` | `zora_backend_user` | Backend API runs migrations |
| `rbac_db` | `zora_rbac_backend_user` | RBAC Backend runs migrations |
| `skill_storage` | `zora_agent_skills_user` | Agent Skills Job runs migrations and ingests skills |

Once ownership is transferred, new tables created by the owner user are automatically owned by that user — no recurring script needed.

### Design Decisions

- **`zora_backend_user` has no CREATE on `rbac_db`** — it only reads/writes existing tables. Schema ownership belongs to `zora_rbac_backend_user` which runs Alembic migrations.
- **Each DB has a single owner** — the user that runs migrations. Other users get only DML grants (SELECT/INSERT/UPDATE/DELETE), not ownership.
- **Engine users are schema-scoped** — `zora_engine_cfo_user` only sees `cfo_data`, `zora_engine_em_user` only sees `em_data`. They cannot access `public` or each other's schemas in `customer_data`.
- **Engine users read `skill_storage`** — both engine users get read-only access to `skill_storage.public` (agent skills consumed during inference).
- **`zora_customerdata_user` owns all schemas in `customer_data`** — schemas are created dynamically by Alembic migrations (varies by env). Requires `GRANT CREATE ON DATABASE customer_data` so migrations can run `CREATE SCHEMA IF NOT EXISTS`. **Schema ownership must be transferred** alongside tables — the init-db script uses `ALTER DEFAULT PRIVILEGES FOR ROLE <schema_owner>` which only works when the schema is owned by the app user, not `postgres`.
- **`synthetic_data_v3` grants are optional** — that DB may not exist in all environments; the script uses `|| true` for those grants.
- **One RBAC user for both apps** — RBAC backend and RBAC UI share `zora_rbac_backend_user` (the separate `zora_rbac_backend_ui_user` was dropped as unnecessary).
- **Developer user for manual operations** — `zora_developer` has full DML+DDL on all databases but cannot create/modify users or permissions. Password is shared via Doppler (not randomly generated like service users), allowing team members to run migrations, test schema changes, or debug issues without using the `postgres` superuser.

## Shared Team Users

These users are shared across the team, not tied to specific applications. Passwords are managed in Doppler and synced via External Secrets.

| User | Purpose | Password Source |
|------|---------|-----------------|
| `postgres` | Superuser (init-db job only, not used by apps or developers) | Doppler: `DB_PASSWORD_POSTGRES` |
| `postgres_read` | Read-only across all DBs and schemas (Grafana, debugging) | Doppler: `DB_PASSWORD_POSTGRES_READ` |
| `zora_developer` | Developer access — full DML+DDL on all databases and schemas, no role management | Doppler: `DB_PASSWORD_ZORA_DEVELOPER` |

**Developer user capabilities:**
- ✅ SELECT, INSERT, UPDATE, DELETE, TRUNCATE on all tables
- ✅ CREATE TABLE, ALTER TABLE, DROP TABLE (DDL)
- ✅ CREATE/DROP indexes, sequences, views
- ✅ Run Alembic migrations manually
- ✅ CREATE SCHEMA (for testing)
- ❌ CREATE ROLE, ALTER ROLE, DROP ROLE (no user management)
- ❌ GRANT or REVOKE (no permission management)
- ❌ Superuser operations (config changes, system catalog access)

---

## ArgoCD Configuration

**Feature branch merged:** PR #62 merged to `main` on 2026-04-08. All migrated environments now track `main`.

The `postgres-init-db` ArgoCD apps for migrated environments (dev2, dev3, qa, lab, demo) have been updated:

```yaml
targetRevision: main   # All migrated envs
```

Environments not yet migrated still track `main` but use the old init-db script (only `postgres_read`, no role-based users). See [Per-Environment Rollout](#per-environment-rollout) below.

**Critical: `ignoreDifferences` for the secret.** Helm `lookup()` doesn't work in ArgoCD (it runs `helm template` without cluster access), so every sync would regenerate random passwords and overwrite the secret. The ArgoCD app uses `ignoreDifferences` + `RespectIgnoreDifferences` to prevent this:

```yaml
ignoreDifferences:
  - group: ""
    kind: Secret
    name: zora-ai-db-users-secrets
    jsonPointers:
      - /data
syncOptions:
  - RespectIgnoreDifferences=true
```

This means the secret is only created on first sync. To rotate passwords, see [Password Rotation](#password-rotation).

---

## Deployment Steps (new environment)

### 0. Pre-Migration Validation and Backup

**CRITICAL:** Before starting any migration, verify the current state is healthy and create a backup. Do not introduce migration changes on top of existing issues.

#### 0.1. Check Current Application and Database Health

```bash
NS=zora-ai-<env>

# 1. Check all pod statuses — identify any pre-existing CrashLoopBackOff or errors
kubectl get pods -n $NS

# 2. Check postgres logs for recent errors
kubectl logs zora-ai-postgres2-0 -n $NS -c postgres --tail=100 | grep -iE "error|fatal|fail"

# 3. Check current active connections (baseline)
kubectl exec zora-ai-postgres2-0 -n $NS -c postgres -- \
  psql -U postgres -c "SELECT usename, datname, state, COUNT(*) FROM pg_stat_activity WHERE state IS NOT NULL GROUP BY usename, datname, state ORDER BY usename, datname;"

# 4. Check app logs for any DB connection errors
for pod in $(kubectl get pods -n $NS -o name | grep -E "backend|configuration-server|customer-data-server|engine|rbac-app" | grep -v "backup\|idle\|job"); do
  echo "=== $pod ==="
  kubectl logs $pod -n $NS --tail=20 2>&1 | grep -iE "error|fatal|fail|permission denied|authentication" || echo "  (clean)"
done
```

**Document any pre-existing issues** before proceeding. For example:
- App CrashLoopBackOff due to missing files in container image
- SQL errors from missing database columns (unrelated to permissions)
- Connection pool exhaustion or timeout errors

This baseline prevents confusion about which errors are migration-related vs. pre-existing.

#### 0.2. Create Database Backup

**Before making any database changes** (users, grants, or ownership transfers), create a full backup:

```bash
NS=zora-ai-<env>
TIMESTAMP=$(date +%Y%m%d_%H%M%S)

# Trigger on-demand backup job (if backup CronJob exists)
kubectl create job --from=cronjob/zora-ai-postgres-backup postgres-backup-premigration-$TIMESTAMP -n $NS

# OR: Manual pg_dumpall backup
kubectl exec zora-ai-postgres2-0 -n $NS -c postgres -- \
  pg_dumpall -U postgres | gzip > postgres-backup-$NS-$TIMESTAMP.sql.gz

# Verify backup size (should be non-zero)
ls -lh postgres-backup-$NS-$TIMESTAMP.sql.gz
```

**Store the backup in a safe location** (Azure Blob Storage, S3, or persistent volume) before proceeding. If migration encounters issues, this backup allows full rollback.

**Why this is critical:**
- Table ownership transfer is irreversible without a backup
- Password rotation can lock out apps if secret sync fails
- Pre-existing bugs may surface during migration — backup enables rollback

---

### 1. Verify the Helm secret template

The `zora-ai-jobs` chart creates a `zora-ai-db-users-secrets` Kubernetes Secret with random passwords via Helm `lookup` + `randAlphaNum`. Verify the chart template renders:

```bash
helm template postgres-init-db ./kubernetes/charts/zora-ai-jobs \
  -f ./kubernetes/azure/<env>/values-zora-ai-postgres-init-db.yaml \
  -s templates/secret.yaml
```

**Note:** Locally `lookup()` returns empty (no cluster), so Helm generates fresh random passwords — this is expected. In-cluster, ArgoCD also can't `lookup()`, which is why `ignoreDifferences` is required (see above).

### 2. Sync the init-db ArgoCD app

Trigger an ArgoCD sync for `postgres-init-db`. The Job will:
1. Create databases (idempotent)
2. Create/update `postgres_read` user
3. Grant read-only on all schemas in all DBs
4. Create all 7 role-based users with passwords from the secret
5. Grant per-user permissions as per the matrix above

**Note:** Table ownership transfer is NOT part of the Job — it's a one-time manual step (see step 6 below).

### 3. Check init-db job logs

After the Job completes, verify the script ran successfully by checking the logs:

```bash
# Find the job name
kubectl get jobs -n $NS | grep postgres

# Check logs (use the job name from above)
kubectl logs job/<job-name> -n $NS -c run-script
```

**What to look for:**
- Every `psql` command should return `GRANT`, `ALTER ROLE`, `ALTER DEFAULT PRIVILEGES`, or `DO` — no errors
- All 8 users should show `created/updated` messages (7 service users + 1 developer user)
- The script should end with `Init-DB script completed successfully.`
- **Expected non-errors:** `schema "em_data" does not exist` on `synthetic_data_v3` is normal (not all schemas exist in all envs, handled with `|| true`)
- **Expected notices:** `extension "pg_textsearch" already exists, skipping` is normal

If any `psql` command fails with an unexpected error, fix the issue in the values file, increment `passwordsGeneration`, commit, push, and re-sync.

### 4. Verify users were created

```bash
# Set context
NS=zora-ai-<env>
POD=zora-ai-postgres2-0

kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -c "SELECT rolname FROM pg_roles WHERE rolname LIKE 'zora_%' ORDER BY rolname;"
```

Expected output:
```
 zora_agent_skills_user
 zora_backend_user
 zora_config_user
 zora_customerdata_user
 zora_developer
 zora_engine_cfo_user
 zora_engine_em_user
 zora_rbac_backend_user
```

### 5. Verify permissions

```bash
# Check schema privileges on rbac_db
kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -d rbac_db -c "\dn+"

# Expected: zora_rbac_backend_user has UC (Usage + Create)
#           zora_backend_user has U only (Usage, no Create)

# Check table ownership in rbac_db
kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -d rbac_db -c "SELECT tablename, tableowner FROM pg_tables WHERE schemaname = 'public';"

# Expected: all tables owned by zora_rbac_backend_user
```

### 6. Transfer ownership (one-time per env)

After users are created, transfer ownership of existing **schemas, tables, and sequences** from `postgres` to the designated owner for each DB. This is a **one-time manual operation** — once done, new objects created by the owner user will automatically be owned by them.

**Why schemas too?** The init-db script uses `ALTER DEFAULT PRIVILEGES FOR ROLE <owner>` which requires the schema to be owned by the specified role. If schemas remain owned by `postgres`, backup jobs fail because `postgres_read` default privileges are never applied to objects created by the app user. See [ZORAAI-6702](https://jira.tools.deloitteinnovation.us/browse/ZORAAI-6702).

```bash
NS=zora-ai-<env>
POD=zora-ai-postgres2-0

# Helper: transfer schema + all tables + sequences in a DB to a new owner.
# Discovers all non-system schemas dynamically — no hardcoded list needed.
transfer_ownership() {
  local db="$1" owner="$2"
  kubectl exec $POD -n $NS -c postgres -- \
    psql -U postgres -d "$db" -c "
      DO \$\$
      DECLARE
        s TEXT;
        obj RECORD;
      BEGIN
        FOR s IN SELECT schema_name FROM information_schema.schemata
                 WHERE schema_name NOT IN ('pg_catalog', 'information_schema', 'pg_toast', 'public') LOOP
          EXECUTE format('ALTER SCHEMA %I OWNER TO $owner', s);
          RAISE NOTICE 'Schema % owner -> $owner', s;
        END LOOP;
        FOR s IN SELECT DISTINCT schemaname FROM pg_tables
                 WHERE schemaname NOT IN ('pg_catalog', 'information_schema', 'pg_toast') LOOP
          FOR obj IN SELECT tablename FROM pg_tables WHERE schemaname = s LOOP
            EXECUTE format('ALTER TABLE %I.%I OWNER TO $owner', s, obj.tablename);
          END LOOP;
          FOR obj IN SELECT sequence_name FROM information_schema.sequences WHERE sequence_schema = s LOOP
            EXECUTE format('ALTER SEQUENCE %I.%I OWNER TO $owner', s, obj.sequence_name);
          END LOOP;
        END LOOP;
      END
      \$\$;
    "
  echo "Transferred ownership of all objects in $db to $owner"
}

transfer_ownership customer_data zora_customerdata_user
transfer_ownership zora_config   zora_config_user
transfer_ownership zora_app      zora_backend_user
transfer_ownership rbac_db       zora_rbac_backend_user
transfer_ownership skill_storage zora_agent_skills_user
```

> **Note:** `public` schema is excluded from `ALTER SCHEMA OWNER` because it is owned by `pg_database_owner` in PostgreSQL 15+. Tables and sequences inside `public` are still transferred.

**Verify ownership:**
```bash
# Check schema ownership
for db in customer_data zora_config zora_app rbac_db skill_storage; do
  echo "=== $db: schemas ==="
  kubectl exec $POD -n $NS -c postgres -- \
    psql -U postgres -d "$db" -c "SELECT nspname AS schema, nspowner::regrole AS owner FROM pg_namespace WHERE nspname NOT IN ('pg_catalog','information_schema','pg_toast');"
done

# Check table ownership
for db in customer_data zora_config zora_app rbac_db skill_storage; do
  echo "=== $db: tables ==="
  kubectl exec $POD -n $NS -c postgres -- \
    psql -U postgres -d "$db" -c "SELECT schemaname, tablename, tableowner FROM pg_tables WHERE schemaname NOT IN ('pg_catalog','information_schema') ORDER BY schemaname, tablename;"
done
```

### 7. Update app values files to use new credentials

Each app's values file needs `DB_USER` / `DB_PASSWORD` env vars pointing to the new user and the `zora-ai-db-users-secrets` secret. Example for backend:

```yaml
env:
  - name: DB_USER
    value: zora_backend_user
  - name: DB_PASSWORD
    valueFrom:
      secretKeyRef:
        name: zora-ai-db-users-secrets
        key: backend-password
```

### 8. Restart apps and verify connectivity

After ArgoCD syncs the updated values, check logs:

```bash
for app in backend configuration-server customer-data-server engine; do
  echo "=== zora-ai-$app ==="
  kubectl -n $NS logs deploy/zora-ai-$app --tail=50 2>/dev/null \
    | grep -i -E "error|connection refused|permission denied|password" \
    || echo "  (no errors)"
done
```

---

## Operational Procedures

### Password Rotation

1. Delete the secret so Helm regenerates it:
   ```bash
   kubectl delete secret zora-ai-db-users-secrets -n $NS
   ```
2. Increment `passwordsGeneration` in `values-zora-ai-postgres-init-db.yaml`
3. Commit, push, sync `postgres-init-db` ArgoCD app
4. Restart all app pods (they pick up the new secret on next mount):
   ```bash
   kubectl -n $NS rollout restart deploy/zora-ai-backend deploy/zora-ai-configuration-server \
     deploy/zora-ai-customer-data-server deploy/zora-ai-engine \
     deploy/zora-ai-rbac-app deploy/zora-ai-rbac-app-ui
   ```

### Adding a New User

1. Add the password key to `secret.data` in `values-zora-ai-postgres-init-db.yaml`
2. Add the env var reference in `job.env`
3. Add the `create_or_update_user` call and grant statements in `script.content`
4. Increment `passwordsGeneration`
5. Commit, push, sync

### Dropping a User

Users with dependent objects cannot be dropped directly. Follow this sequence:

```bash
# 1. Revoke all privileges in every DB the user has access to
psql -U postgres -d <db> -c "
  REVOKE ALL ON ALL TABLES IN SCHEMA public FROM <user>;
  REVOKE ALL ON ALL SEQUENCES IN SCHEMA public FROM <user>;
  REVOKE ALL ON SCHEMA public FROM <user>;
  REVOKE ALL ON DATABASE <db> FROM <user>;
  ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON TABLES FROM <user>;
  ALTER DEFAULT PRIVILEGES IN SCHEMA public REVOKE ALL ON SEQUENCES FROM <user>;
"

# 2. Drop the user
psql -U postgres -c "DROP USER <user>;"
```

If `DROP USER` still fails with "objects depend on it", check for remaining default privilege grants:
```bash
psql -U postgres -d <db> -c "
  SELECT pg_describe_object(classid, objid, objsubid)
  FROM pg_shdepend
  WHERE refobjid = (SELECT oid FROM pg_roles WHERE rolname = '<user>')
    AND dbid = (SELECT oid FROM pg_database WHERE datname = '<db>');
"
```

### Checking Effective Permissions

```bash
# What can a user do on a specific table?
psql -U postgres -d <db> -c "
  SELECT grantee, table_schema, table_name, privilege_type
  FROM information_schema.role_table_grants
  WHERE grantee = '<user>'
  ORDER BY table_schema, table_name, privilege_type;
"

# Can a user CREATE in a schema?
psql -U postgres -d <db> -c "\dn+"
# Look for 'C' in the Access privileges column next to the user
```

---

## Troubleshooting

### "permission denied for table ..."
The user lacks DML grants on existing tables. The init-db Job grants on "ALL TABLES" at run time — if tables were created *after* the Job ran, they won't be covered. Re-sync the `postgres-init-db` app.

### "permission denied for schema ..."
Missing `GRANT USAGE ON SCHEMA`. Re-sync init-db.

### "must be owner of table ..." (Alembic migration)
Table or schema ownership wasn't transferred. Run the one-time ownership transfer commands from the [Transfer ownership](#6-transfer-ownership-one-time-per-env) section for the affected DB. If a single object was created by `postgres` after the initial transfer (e.g. manual intervention), fix it with:
```bash
kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -d <db> -c "ALTER TABLE public.<table> OWNER TO <owner_user>;"
# Or for schemas:
kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -d <db> -c "ALTER SCHEMA <schema> OWNER TO <owner_user>;"
```

### "permission denied for sequence ..." (pg_dump / backup)
The `postgres_read` user lacks SELECT on sequences in non-public schemas. This happens when `ALTER DEFAULT PRIVILEGES FOR ROLE <owner>` was never set for the schema owner — typically because the schema was still owned by `postgres` instead of the app user. Fix: transfer schema ownership, then re-sync init-db:
```bash
kubectl exec $POD -n $NS -c postgres -- \
  psql -U postgres -d <db> -c "ALTER SCHEMA <schema> OWNER TO <owner_user>;"
# Then re-sync postgres-init-db ArgoCD app (or increment passwordsGeneration)
```

### "role ... cannot be dropped because some objects depend on it"
See the [Dropping a User](#dropping-a-user) section. Key gotcha: `ALTER DEFAULT PRIVILEGES` grants show up as dependencies but aren't visible in `information_schema.role_table_grants`.

### Init-db Job won't re-run
Helm Jobs are immutable once created. ArgoCD must delete the old Job before creating a new one. Ensure the ArgoCD app has `syncPolicy.syncOptions: [Replace=true]` or increment `passwordsGeneration` (which changes the script annotation and forces a new Job).

### "password authentication failed" with empty password in pg_authid
If a user shows `NULL` in `pg_authid.rolpassword` or init-db logs show `empty string is not a valid password`, the password env var is missing from `job.env` in the init-db values file. Example fix for `zora_agent_skills_user`:
```yaml
job:
  env:
    - name: AGENT_SKILLS_USER_PASSWORD
      valueFrom:
        secretKeyRef:
          name: zora-ai-db-users-secrets
          key: agent-skills-password
```
Increment `passwordsGeneration` and re-sync to force a new Job run that will set the password correctly.

### Pods still have old password after secret rotation
When the `zora-ai-db-users-secrets` secret is deleted and recreated (e.g., to add a new key or rotate passwords), Helm generates new random passwords. Pods that started before the rotation will still have the old passwords cached as environment variables. Symptoms: `FATAL: password authentication failed` in postgres logs with pod's password not matching the current secret value. Fix: restart all pods that mount the secret:
```bash
kubectl -n $NS rollout restart deploy/zora-ai-backend deploy/zora-ai-configuration-server \
  deploy/zora-ai-customer-data-server deploy/zora-ai-engine \
  deploy/zora-ai-rbac-app deploy/zora-ai-rbac-app-ui
```

---

## Per-Environment Rollout

Environments are migrated one at a time. The feature branch `ZORAAI-5140_create_postgres_users` is merged into `main` after dev2 is verified. All other envs are migrated directly on `main`.

### Branching Strategy

**Why we can't merge the feature branch yet:** Each environment is migrated separately with manual verification and table ownership transfers. The feature branch contains the init-db Job configuration and this runbook — merging it would deploy the changes to all envs at once via ArgoCD. Instead, we apply changes selectively:

**Commit to `main` (per-environment application config):**
- App values files with new DB user credentials:
  - `kubernetes/azure/<env>/values-zora-ai-backend.yaml`
  - `kubernetes/azure/<env>/values-zora-ai-configuration-server.yaml`
  - `kubernetes/azure/<env>/values-zora-ai-customer-data-server.yaml`
  - `kubernetes/azure/<env>/values-zora-ai-engine.yaml`
  - `kubernetes/azure/<env>/values-zora-ai-rbac-backend.yaml`
  - `kubernetes/azure/<env>/values-zora-ai-rbac-backend-ui.yaml`
  - `kubernetes/azure/<env>/values-zora-agent-skills.yaml`

**Commit to feature branch `ZORAAI-5140_create_postgres_users` (infrastructure):**
- `docs/runbooks/postgres-users-runbook.md` (this file)
- `kubernetes/charts/zora-ai-jobs/` (if chart template changes needed)
- `kubernetes/azure/<env>/values-zora-ai-postgres-init-db.yaml` (init-db Job config per env)

The init-db values files stay on the feature branch because each env's `argocd/<env>/postgres-init-db.yaml` has `targetRevision: ZORAAI-5140_create_postgres_users` (or `main` for envs not yet migrated). Once all envs are complete, merge the feature branch and update all ArgoCD apps to track `main`.

### Pre-Migration Validation

Before starting the migration, check the health of all pods and postgres to avoid creating new issues on top of existing ones:

```bash
# 1. Check all pod statuses — identify any pre-existing CrashLoopBackOff or errors
kubectl get pods -n zora-ai-<env>

# 2. Check postgres logs for recent errors
kubectl logs zora-ai-postgres2-0 -n zora-ai-<env> -c postgres --tail=50

# 3. Check current active connections (baseline)
kubectl exec zora-ai-postgres2-0 -n zora-ai-<env> -c postgres -- \
  psql -U postgres -c "SELECT usename, datname, state, COUNT(*) FROM pg_stat_activity WHERE state IS NOT NULL GROUP BY usename, datname, state ORDER BY usename, datname;"

# 4. Check app logs for any DB connection errors
for pod in $(kubectl get pods -n zora-ai-<env> -o name | grep -v postgres | grep -v redis | grep -v backup | grep -v idle); do
  echo "=== $pod ==="
  kubectl logs $pod -n zora-ai-<env> --tail=5 2>&1 | grep -iE "error|fatal|fail" || echo "  (clean)"
done
```

**Document any pre-existing issues** before proceeding — this avoids confusion about which errors are caused by the migration vs. pre-existing. For example, in QA the backend had a pre-existing CrashLoopBackOff (missing widget_prefabs.json in image) that was unrelated to the DB migration.

### Steps

**On the feature branch** (for dev2) or `main` (for all other envs):

1. **Update the init-db values file** for the target env — add the `secret`, `passwordsGeneration`, role-based user creation, and grant sections to `kubernetes/azure/<env>/values-zora-ai-postgres-init-db.yaml`. Use dev2 as reference. Adapt env-specific details (DB names, schemas, postgres secret key names).

2. **Ensure the ArgoCD app has `ignoreDifferences`** to prevent password regeneration on every sync. Edit `argocd/<env>/postgres-init-db.yaml`:
   ```yaml
   targetRevision: main
   ignoreDifferences:
     - group: ""
       kind: Secret
       name: zora-ai-db-users-secrets
       jsonPointers:
         - /data
   syncPolicy:
     syncOptions:
       - RespectIgnoreDifferences=true
   ```

3. **Commit and push** to `main`.

4. **ArgoCD syncs** — creates the secret and runs the init-db Job.

5. **Verify** — follow steps 3–7 in [Deployment Steps](#deployment-steps-new-environment).

### After feature branch merge (completed 2026-04-08)

1. ✅ Merged `ZORAAI-5140_create_postgres_users` → `main` (PR #62)
2. ✅ Updated all migrated env ArgoCD apps to `targetRevision: main` (dev2, dev3, qa, lab, demo)
3. ✅ All subsequent env migrations happen directly on `main` — no feature branch needed

---

## Lessons Learned

### Dev3 Migration (2026-04-01)

**Issues encountered during dev3 migration:**

1. **Password secret key names not following documentation** — Initial dev3 values files used incorrect secret key names that didn't match the documented standard in `DATABASE_USERS_RBAC.md` or the init-db script:
   - Engine: used `engine-password` instead of documented `engine-cfo-password`
   - RBAC apps: used `rbac-password` instead of documented `rbac-backend-password`
   - **Root cause:** Values files written without cross-checking against dev2 reference or documentation
   - **Fix:** Corrected secret key names to match documented standard (`engine-cfo-password`, `rbac-backend-password`)
   - **Prevention:** Always compare new env values against dev2 **before** committing; verify password keys match what init-db generates

2. **Engine database user inconsistencies** — Engine was partially configured with wrong users:
   - `skill_storage` was still using `postgres` superuser instead of `zora_engine_cfo_user`
   - `zora_config` was incorrectly changed to `zora_engine_cfo_user` when it should remain `postgres_read` (read-only, matches dev2 pattern)
   - **Root cause:** Inconsistent application of migration pattern; didn't reference dev2 engine config
   - **Fix:** Engine now uses `zora_engine_cfo_user` for `customer_data` (cfo_data schema) and `skill_storage`, `postgres_read` for `zora_config` (read-only)

3. **Missing dbSecretsVersion annotation** — Engine values file was missing `dbSecretsVersion: "2"` which dev2 has for tracking secret generation.
   - **Root cause:** Didn't do full diff of dev3 vs dev2 engine values
   - **Fix:** Added `dbSecretsVersion: "2"` to engine values for parity with dev2

4. **Environment-specific schemas not in dev2** — Dev3's `customer_data` database has additional schemas (`collection_advisory`, `payment_data_dictionary`) beyond dev2's `public`, `cfo_data`, `em_data`.
   - **Symptom:** Init-db script grants would fail on non-existent schemas if copied directly from dev2
   - **Detection:** Queried both dev2 and dev3 `customer_data` schemas before writing init-db script
   - **Fix:** Added grants for dev3-specific schemas in init-db script; developer user schema list updated to include all schemas

5. **Agent-skills Job blocked ArgoCD sync** — After updating `values-zora-agent-skills.yaml` with new DB credentials, ArgoCD couldn't sync because the old Job still existed.
   - **Root cause:** Kubernetes Jobs are immutable once created; changing the values file creates a conflict
   - **Symptom:** ArgoCD shows `OutOfSync` but sync fails or does nothing
   - **Fix:** Manually delete the old Job before syncing: `kubectl delete job zora-agent-skills-job-<old-hash> -n zora-ai-dev03`
   - **Prevention:** For future envs, delete any existing agent-skills job BEFORE updating the values file and syncing

**Verification process:**
- Used incremental testing — migrated 2 services first (backend + config-server), verified logs/connections, then proceeded with remaining 5 apps
- All 97 tables across 9 schemas successfully transferred ownership to designated service users
- Zero postgres superuser connections from applications after migration (only DBeaver and metrics exporter remain)

**Key takeaways:**
- **Always diff against reference environment before committing** — Run `diff kubernetes/azure/dev2/values-zora-ai-<app>.yaml kubernetes/azure/dev3/values-zora-ai-<app>.yaml` to catch structural mismatches (missing fields, wrong password keys)
- **Check secret key names match init-db script** — Password keys in app values must exactly match what init-db generates; run `grep "password:" kubernetes/azure/<env>/values-zora-ai-postgres-init-db.yaml` to see the canonical list
- **Check for env-specific schemas** — Query `\dn` in each database and compare to dev2; add grants as needed for extra schemas
- **Incremental deployment reduces blast radius** — Testing 2 apps before deploying all 7 caught password key issues early; would have affected all 7 apps otherwise

### Perf Migration Plan (2026-04-08)

**Pre-migration assessment (via Grafana metrics):**
- Cluster status: 18 pods Running (5 apps + 13 infra/jobs)
- Load: Backend CPU 1.3%, Engine CPU 1.2%, Frontend CPU 0.01%
- Network: ~5.1 KB/s ingress
- Active DB connections: 7 idle (3 rbac_db, 4 zora_app) — all using `postgres` superuser
- Pod uptime: Backend/Engine 1.1 days, other apps 4.5 days
- **Conclusion:** Nearly idle — ideal migration candidate

**Schema structure:**
- `customer_data` has only `public` schema (no cfo_data/em_data yet)
- Like dev2 — use 8-user model (not 10-user)
- Engine should use `zora_engine_cfo_user` for all databases (dev2 pattern)

**Migration approach:**
1. Update `kubernetes/azure/perf/values-zora-ai-postgres-init-db.yaml` — copy from dev2 (8 users, 3 schemas)
2. Commit directly to `main` (feature branch already merged)
3. Sync init-db job via ArgoCD → creates 8 role-based users
4. Transfer table ownership (5 databases) — see [One-Time Ownership Transfer](#one-time-ownership-transfer)
5. Update 6 app values files (backend, customer-data-server, configuration-server, engine, rbac-backend, agent-skills)
6. Commit to `main` and sync via ArgoCD
7. Verify: zero authentication errors, all connections use role-based users

**Apps to migrate:**
1. `zora-ai-backend` → `zora_backend_user` (owner of zora_app, read-write rbac_db, read customer_data/zora_config)
2. `zora-ai-customer-data-server` → `zora_customerdata_user` (owner of customer_data)
3. `zora-ai-configuration-server` → `zora_config_user` (owner of zora_config)
4. `zora-ai-engine` → `zora_engine_cfo_user` for customer_data + skill_storage, `postgres_read` for zora_config
5. `zora-ai-rbac-app` → `zora_rbac_backend_user` (owner of rbac_db)
6. `zora-agent-skills-job` → `zora_agent_skills_user` (owner of skill_storage)

**Risk:** 🟢 Low — idle cluster, 5 successful precedents, established procedure, fast rollback available

**Estimated duration:** 2–2.5 hours (all steps on main branch)

---

## Rollout Status

| Env | Status | Users | Apps | Last Updated | Notes |
|-----|--------|-------|------|--------------|-------|
| **dev2** | ✅ Complete | 8 | 7/7 | 2026-04-01 | All apps migrated. Zero postgres superuser connections from apps (only metrics exporter sidecar). |
| **dev3** | ✅ Complete | 10 | 7/7 | 2026-04-01 | All apps migrated. Includes env-specific schemas (collection_advisory, payment_data_dictionary). Zero authentication errors. |
| **qa** | ✅ Complete | 10 | 6/7 | 2026-04-02 | Backend has pre-existing CrashLoopBackOff (missing widget_prefabs.json) — old pod continues with postgres superuser; new credentials ready. |
| **lab** | ✅ Complete | 10 | 7/7 | 2026-04-03 | All apps migrated. Agent-skills job completed successfully with checksum-based naming. |
| **demo** | ✅ Complete | 10 | 7/7 | 2026-04-07 | All apps migrated. Pre-migration backup: 128M across 6 databases. |
| **perf** | ✅ Complete | 8 | 6/6 | 2026-04-08 | All apps migrated (backend, customer-data-server, configuration-server, engine, rbac-backend, agent-skills). Zero authentication errors. Pre-migration backup completed (16s). Dev2 pattern (8 users, customer_data.public only). |
| **nvidia/dev2** | ⏸️ Prepared | — | 0/7 | — | Init-db values prepared (8 users, 3 schemas) but apps not yet migrated. Still using postgres superuser. |
| **preprod** | ❌ Not started | — | — | — | Init-db not yet prepared. |
| **prod** | ❌ Not started | — | — | — | Init-db not yet prepared. |

**Summary:** 5 of 9 non-prod environments complete. All migrated envs now track `main` (feature branch merged 2026-04-08, PR #62).

## Related Files

- **Init-db values (per env):**
  - Dev2: `kubernetes/azure/dev2/values-zora-ai-postgres-init-db.yaml` (8 users, 3 schemas)
  - Dev3: `kubernetes/azure/dev3/values-zora-ai-postgres-init-db.yaml` (10 users, 5 schemas)
  - QA: `kubernetes/azure/qa/values-zora-ai-postgres-init-db.yaml` (10 users, 5 schemas)
  - Lab: `kubernetes/azure/lab/values-zora-ai-postgres-init-db.yaml` (10 users, 5 schemas)
  - Demo: `kubernetes/azure/demo/values-zora-ai-postgres-init-db.yaml` (10 users, 5 schemas)
  - Perf: `kubernetes/azure/perf/values-zora-ai-postgres-init-db.yaml` (old script, pending update)
  - Nvidia/dev2: `kubernetes/azure/nvidia/dev2/values-zora-ai-postgres-init-db.yaml` (8 users, 3 schemas, prepared)
- **Jobs chart:** `kubernetes/charts/zora-ai-jobs/`
- **Secret template:** `kubernetes/charts/zora-ai-jobs/templates/secret.yaml`
- **Documentation:**
  - User permissions matrix: `docs/DATABASE_USERS_RBAC.md`
  - This runbook: `docs/runbooks/postgres-users-runbook.md`
- **Branch:** `main` (feature branch `ZORAAI-5140_create_postgres_users` merged via PR #62 on 2026-04-08)
