# Langfuse Deployment – Quick Start Guide

Quick-reference for deploying Langfuse using the `zora-ai-langfuse` Helm chart via ArgoCD.

> For the full detailed runbook (Doppler config creation, blob storage strategy, per-cluster keys), see [deploy-langfuse.md](deploy-langfuse.md).

---

## Prerequisites

| Requirement | Details |
|-------------|---------|
| Helm 3.x | `brew install helm` or equivalent |
| kubectl | Configured for the target AKS/EKS/GKE cluster |
| ArgoCD access | UI or CLI for the target cluster |
| Doppler access | Project: `pllm-inference` |
| DNS access | To create/update A records |

---

## Repository Layout

```
kubernetes/
  charts/zora-ai-langfuse/          # Helm chart (shared across all clusters)
    Chart.yaml                       # v1.0.0, appVersion 3.0.0
    values.yaml                      # Default values
    templates/                       # K8s manifests (web, worker, postgres, redis, clickhouse, ingress, etc.)

  azure/<env>/langfuse/              # Per-cluster Azure values
    langfuse-values-azure.yaml

  aws/values/<env>/langfuse/         # Per-cluster AWS values
    langfuse-values-aws.yaml

argocd/<env>/langfuse.yaml           # ArgoCD Application manifest
```

---

## Components Deployed

| Component | Image | Port | Storage |
|-----------|-------|------|---------|
| Web (Next.js) | `langfuse/langfuse:3` | 3000 | — |
| Worker | `langfuse/langfuse-worker:3` | 3030 | — |
| PostgreSQL | Built-in StatefulSet | 5432 | 20Gi (`managed-premium`) |
| Redis | Built-in StatefulSet | 6379 | 8Gi (`managed-premium`) |
| ClickHouse | Built-in StatefulSet | 8123/9000 | 50Gi (`managed-premium`) |

---

## Secrets Management

Secrets flow: **Doppler → ClusterSecretStore (`doppler-zora-ai`) → ExternalSecret → Kubernetes Secret → Pod env vars**

The chart auto-bootstraps the Doppler token secret when `dopplerBootstrap.enabled: true`.

---

## Pre-Deployment: Azure Storage Account Setup

Create one Azure Storage Account and three Blob containers for Langfuse uploads.

```bash
# Variables
RESOURCE_GROUP="rg-zoraai-<env>"
STORAGE_ACCOUNT="zoraailangfuse<env>"   # Must be globally unique, lowercase, no hyphens
LOCATION="eastus2"

# Create Storage Account
az storage account create \
  --name "$STORAGE_ACCOUNT" \
  --resource-group "$RESOURCE_GROUP" \
  --location "$LOCATION" \
  --sku Standard_LRS \
  --kind StorageV2 \
  --min-tls-version TLS1_2

# Create the three containers
az storage container create --name langfuse-events  --account-name "$STORAGE_ACCOUNT"
az storage container create --name langfuse-media   --account-name "$STORAGE_ACCOUNT"
az storage container create --name langfuse-exports --account-name "$STORAGE_ACCOUNT"

# Get the access key (needed for Doppler)
az storage account keys list --account-name "$STORAGE_ACCOUNT" --resource-group "$RESOURCE_GROUP" --query "[0].value" -o tsv
```

| Container | Purpose |
|-----------|---------|
| `langfuse-events` | Trace event upload storage |
| `langfuse-media` | Media/file attachment uploads |
| `langfuse-exports` | Batch export output files |

---

## Pre-Deployment: Doppler Keys Reference

All keys below must exist in the per-cluster Doppler config (`pllm-inference` project). The chart's ExternalSecret pulls **every** key from the config automatically.

| # | Key | Value | How to Generate |
|---|-----|-------|-----------------|
| 1 | `NEXTAUTH_URL` | `<your-langfuse-url>` | Must match ingress/httpRoute host (e.g. `https://zoraai-langfuse.<env>.<domain>`) |
| 2 | `NEXTAUTH_SECRET` | `<nextauth-secret>` | `openssl rand -base64 32` |
| 3 | `SALT` | `<salt-value>` | `openssl rand -base64 32` |
| 4 | `ENCRYPTION_KEY` | `<encryption-key>` | `openssl rand -hex 32` |
| 5 | `DATABASE_URL` | `<postgres-connection-string>` | Format: `postgresql://<user>:<password>@postgres-service:5432/langfuse` |
| 6 | `CLICKHOUSE_PASSWORD` | `<clickhouse-password>` | Random strong password |
| 7 | `REDIS_AUTH` | `<redis-auth-password>` | Random strong password |
| 8 | `LANGFUSE_S3_EVENT_UPLOAD_ENDPOINT` | `<azure-blob-storage-endpoint>` | Format: `https://<storage-account>.blob.core.windows.net` |
| 9 | `LANGFUSE_S3_EVENT_UPLOAD_ACCESS_KEY_ID` | `<storage-account-name>` | Azure Storage Account name |
| 10 | `LANGFUSE_S3_EVENT_UPLOAD_SECRET_ACCESS_KEY` | `<storage-account-access-key>` | From Azure Portal → Storage Account → Access Keys |
| 11 | `LANGFUSE_S3_MEDIA_UPLOAD_ENDPOINT` | `<azure-blob-storage-endpoint>` | Same as row 8 |
| 12 | `LANGFUSE_S3_MEDIA_UPLOAD_ACCESS_KEY_ID` | `<storage-account-name>` | Same as row 9 |
| 13 | `LANGFUSE_S3_MEDIA_UPLOAD_SECRET_ACCESS_KEY` | `<storage-account-access-key>` | Same as row 10 |
| 14 | `LANGFUSE_S3_BATCH_EXPORT_ENDPOINT` | `<azure-blob-storage-endpoint>` | Same as row 8 |
| 15 | `LANGFUSE_S3_BATCH_EXPORT_ACCESS_KEY_ID` | `<storage-account-name>` | Same as row 9 |
| 16 | `LANGFUSE_S3_BATCH_EXPORT_SECRET_ACCESS_KEY` | `<storage-account-access-key>` | Same as row 10 |
| 17 | `LANGFUSE_S3_BATCH_EXPORT_EXTERNAL_ENDPOINT` | `<azure-blob-storage-endpoint>` | Same as row 8 (public-facing) |
| 18 | `LANGFUSE_INIT_USER_EMAIL` | `<admin-email-address>` | Bootstrap admin email |
| 19 | `LANGFUSE_INIT_USER_NAME` | `<admin-display-name>` | Bootstrap admin display name |
| 20 | `LANGFUSE_INIT_USER_PASSWORD` | `<admin-login-password>` | Strong password for initial login |
| 21 | `LANGFUSE_INIT_PROJECT_PUBLIC_KEY` | `<langfuse-project-public-key>` | Format: `pk-lf-<uuid>` |
| 22 | `LANGFUSE_INIT_PROJECT_SECRET_KEY` | `<langfuse-project-secret-key>` | Format: `sk-lf-<uuid>` |

> **Important:** For storage keys (rows 8–17), the `ENDPOINT` is the Azure Blob endpoint of your storage account, `ACCESS_KEY_ID` is the storage account name, and `SECRET_ACCESS_KEY` is the storage account access key. All three containers share the same storage account credentials.

---

## Deployment Steps

### Step 1: Prepare Doppler Config

1. Duplicate an existing Langfuse config in Doppler (`pllm-inference` project).
2. Rotate all per-cluster keys (see [deploy-langfuse.md § Per-cluster keys](deploy-langfuse.md)).
3. Generate a **read-only service token** for the new config.
4. Add the token to `ci_zora_ai` as `LANGFUSE_DOPPLER_TOKEN_<ENV>`.

### Step 2: Create/Update Values File

Example: `kubernetes/azure/demo/langfuse/langfuse-values-azure.yaml`

Key overrides:

```yaml
dopplerBootstrap:
  enabled: true
  remoteKey: LANGFUSE_DOPPLER_TOKEN_DEMO  # Must match Doppler key from Step 1

storage:
  useAzureBlob: true
  eventUpload:
    bucket: "langfuse-events"
    region: "eastus2"
```

#### Option A: Ingress (Azure / GCP clusters)

Use `ingress` when the cluster has an NGINX Ingress Controller with cert-manager:

```yaml
ingress:
  enabled: true
  className: "nginx-internal"
  annotations:
    cert-manager.io/cluster-issuer: "letsencrypt-prod"
    nginx.ingress.kubernetes.io/proxy-body-size: "20m"
    nginx.ingress.kubernetes.io/proxy-connect-timeout: "60"
    nginx.ingress.kubernetes.io/proxy-read-timeout: "600"
    nginx.ingress.kubernetes.io/proxy-send-timeout: "600"
  hosts:
    - host: zoraai-langfuse.<env>.<domain>.example.com
      paths:
        - path: /
          pathType: Prefix
  tls:
    - secretName: zoraai-langfuse-<env>-tls-secret
      hosts:
        - zoraai-langfuse.<env>.<domain>.example.com
```

#### Option B: HTTPRoute (AWS / Gateway API clusters)

Use `httpRoute` when the cluster uses the Gateway API (e.g., AWS ALB with Gateway controller):

```yaml
httpRoute:
  enabled: true
  host: zoraai-langfuse.<env>.<domain>.example.com
  path: "/"
  pathType: "PathPrefix"
  gatewayName: "apps-gateway-internal"
  gatewayNamespace: "ska-system"
  sectionName: ""  # Optional: specific listener on the gateway
```

> **Note:** Enable only one — set `ingress.enabled: false` when using `httpRoute`, or `httpRoute.enabled: false` when using `ingress`. The chart renders whichever is enabled.

### Step 3: Lint and Template Locally

```bash
# Lint the chart
helm lint kubernetes/charts/zora-ai-langfuse \
  -f kubernetes/azure/demo/langfuse/langfuse-values-azure.yaml

# Dry-run template rendering
helm template langfuse kubernetes/charts/zora-ai-langfuse \
  -f kubernetes/azure/demo/langfuse/langfuse-values-azure.yaml | less
```

### Step 4: Create ArgoCD Application

File: `argocd/demo/langfuse.yaml`

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-langfuse
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/charts/zora-ai-langfuse
    helm:
      valueFiles:
        - ../../azure/demo/langfuse/langfuse-values-azure.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-langfuse
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### Step 5: Commit and Push

```bash
git add argocd/<env>/langfuse.yaml kubernetes/azure/<env>/langfuse/
git commit -m "feat(<env>): deploy langfuse"
git pull --rebase origin main && git push origin main
```

### Step 6: Configure DNS

Point the Langfuse FQDN to the cluster's nginx-internal Ingress IP:

```bash
kubectl -n zora-ai-langfuse get ingress
```

Create an A record for the host (see [update-loadbalancer-dns.md](update-loadbalancer-dns.md)).

### Step 7: Verify

```bash
# Check ArgoCD sync status
argocd app get zora-ai-langfuse

# Check pods
kubectl -n zora-ai-langfuse get pods

# Check ingress/TLS
kubectl -n zora-ai-langfuse get ingress
kubectl -n zora-ai-langfuse get certificate
```

Open `https://zoraai-langfuse.<env>.<domain>.example.com` in a browser and sign in with the init user credentials from Doppler.

---

## Troubleshooting

| Symptom | Likely Cause | Fix |
|---------|--------------|-----|
| Pods stuck in `CrashLoopBackOff` | Missing Doppler secrets | Check ExternalSecret status: `kubectl -n zora-ai-langfuse get externalsecret` |
| `doppler-token-secret` not created | Token key missing in `ci_zora_ai` | Verify `LANGFUSE_DOPPLER_TOKEN_<ENV>` exists in Doppler `ci_zora_ai` config |
| TLS cert not issued | DNS not pointing to ingress IP | Check cert-manager logs and DNS resolution |
| Web returns 502 | Web pod not ready or migration in progress | Check web pod logs: `kubectl -n zora-ai-langfuse logs -l app.kubernetes.io/component=web` |
| ClickHouse OOM | Insufficient resources | Increase `clickhouse.resources.limits.memory` in values |
| Storage upload failures | Wrong blob credentials | Verify `LANGFUSE_S3_*` keys in Doppler match the storage account |

---

## Useful Commands

```bash
# View all resources in namespace
kubectl -n zora-ai-langfuse get all

# Check secret sync status
kubectl -n zora-ai-langfuse get externalsecret -o wide

# Restart web deployment after config change
kubectl -n zora-ai-langfuse rollout restart deployment langfuse-zora-ai-langfuse-web

# Restart worker deployment
kubectl -n zora-ai-langfuse rollout restart deployment langfuse-zora-ai-langfuse-worker

# Check ClickHouse disk usage
kubectl -n zora-ai-langfuse exec -it clickhouse-0 -- du -sh /var/lib/clickhouse

# Port-forward for local debugging (web UI)
kubectl -n zora-ai-langfuse port-forward svc/langfuse-zora-ai-langfuse-web 3000:3000
```

---

## Related Docs

- [deploy-langfuse.md](deploy-langfuse.md) — Full detailed runbook with Doppler key inventory
- [update-loadbalancer-dns.md](update-loadbalancer-dns.md) — DNS A-record procedure
- [add-new-cluster.md](add-new-cluster.md) — General new-cluster setup
