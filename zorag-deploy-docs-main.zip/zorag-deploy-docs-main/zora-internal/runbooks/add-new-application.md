# Add New Application Runbook

Deploy a new application (backend, frontend, or any other service) to Zora AI clusters using the universal Helm chart and ArgoCD GitOps workflow.

## Overview

Each application requires changes in **two repositories**:

1. **App repo** (`ext-<name>` or `aiq-zora-ai-<name>`) — CI/CD workflow + version file
2. **Deployment repo** (`aiq-zora-ai-deployment`) — Helm values + ArgoCD application manifest

---

## Part 1: App Repository

### 1.1 Create version file

The `get-version` reusable action reads the version from `app/__version__.py`:

```python
# app/__version__.py
__version__ = "0.0.1"
```

### 1.2 Create CI/CD workflow

Create `.github/workflows/ci.yml` based on the pattern from `aiq-zora-ai-backend` (the **canonical reference** — copy this rather than older per-branch `qa-ci.yaml` / `dev-ci.yaml` workflows).

The workflow is **`workflow_dispatch`-only** (manual trigger from the GitHub UI) — push triggers were retired during the ZORAAI-8143 standardization. Inputs include `branch`, `commit`, `environment` (choice), `release_tag`, and `confirm_deploy` ("type DEPLOY to confirm").

Key inputs to customize:

| Field | Description | Example |
|---|---|---|
| `app-name` | Must match the JFrog image repo and Helm values filename | `aiq-zora-collection-advisor-backend` |
| `helm-values-file` | Path in deployment repo (cloud-specific). Branch on `inputs.environment` to pick demo / demo-wus / qa / etc. | `kubernetes/azure/demo-wus/advisor/values-zora-ai-collections-backend.yaml` |
| `argocd-app-name` | Must match `metadata.name` in the ArgoCD manifest | `zora-ai-collection-advisor-backend` |
| `python-version` | **Use `"3.12.6"`** — `"3.12"` resolves to the latest minor and breaks reproducibility | `"3.12.6"` |
| `coverage-threshold` | Minimum test coverage % | `50` |

The workflow covers: `validate-access → test → sonarqube → mend-scan → ci-cd (build+push+xray) → update-helm-chart → force-sync-argocd → notify`.

#### Standard pytest args (must match `sonar-with-coverage` action)

The `run-tests-python` step must produce reports at the paths Sonar expects:

```yaml
- uses: Deloitte-US-Innovation-Technology/aiq-zora-ai-automations/run-tests-python@main
  with:
    python-version: '3.12.6'
    coverage-threshold: '50'
    pytest-args: '--junitxml=test-results.xml --cov-report=xml:coverage.xml'
```

The test job uploads `coverage.xml` + `test-results.xml` as artifact `coverage-report`. The `sonar-with-coverage` action **hardcodes** the download path to `coverage/`, so the app's `sonar-project.properties` must read:

```properties
sonar.python.coverage.reportPaths=coverage/coverage.xml
sonar.python.xunit.reportPath=coverage/test-results.xml
```

> **Common mistake:** older repos had `code_analysis/coverage/coverage.xml` or similar — the new pipeline silently fails the SonarQube job (exit 2, "no coverage to import") because the path doesn't match. Fix the `sonar-project.properties` in the source repo, not the workflow.

#### `continue-on-error` is intentional on SonarQube and Mend

Both `sonarqube` and `mend-scan` jobs use `continue-on-error: true` so non-blocking quality gates do not stop a deploy. Image build/push, Helm update, and ArgoCD sync still run on green if these fail. Old per-branch workflows had Mend/Sonar **commented out**, which masked latent issues — when migrating an old repo, expect the first run on the new pipeline to surface pre-existing test/coverage/SCA failures.

#### Per-environment deploy passwords

Some environments require a confirmation password input (so a wrong-button click on QA can't deploy to a client demo). The unified workflow already wires these up — pass them through to `validate-deploy-access`:

| Environment input | Password input | Secret consulted |
|---|---|---|
| `qa` | `qa_password` | `QA_DEPLOY_PASSWORD` |
| `demo-eus`, `demo-wus` | `demo_password` | `DEMO_DEPLOY_PASSWORD` (or `DEMO_WUS_DEPLOY_PASSWORD` if cluster has its own) |
| `dev2`, `dev3`, `lab`, `perf` | (none) | (none) |

#### Branched `values-path` per environment

For multi-cluster apps (digital workers), build the path with a chained ternary:

```yaml
values-path: ${{
  github.event.inputs.environment == 'demo-eus' && 'kubernetes/azure/demo/advisor' ||
  github.event.inputs.environment == 'demo-wus' && 'kubernetes/azure/demo-wus/advisor' ||
  github.event.inputs.environment == 'qa' && 'kubernetes/azure/qa' ||
  github.event.inputs.environment == 'lab' && 'kubernetes/azure/lab' ||
  '' }}
values-file: ${{
  github.event.inputs.environment == 'demo-eus' && 'values-zora-ai-collections-backend.yaml' ||
  github.event.inputs.environment == 'demo-wus' && 'values-zora-ai-collections-backend.yaml' ||
  'values-zora-ai-collection-advisor.yaml' }}
```

This keeps a single workflow file in sync across all clusters (see `aiq-zora-collection-advisor-backend/.github/workflows/ci.yml` for the full pattern).

### 1.3 Configure GitHub repository secrets

Secrets are **synced automatically from Doppler** — do not add them manually. You only need to add the new repo to the Doppler sync configuration.

**Doppler project:** `pllm-inference` → [dashboard.doppler.com](https://dashboard.doppler.com/workplace/e7743ba4df66a1c978ec/projects/pllm-inference)

Add the new GitHub repo to the sync target for the `ci` config so Doppler pushes the shared CI/CD secrets automatically.

#### Secrets synced to all app repos

| Secret | Purpose |
|---|---|
| `SVC_CI_JFROG_USERNAME` | JFrog login for docker push |
| `SVC_CI_JFROG_KEY` | JFrog password |
| `PAT_FOR_SVC_ACCOUNT` | GitHub PAT to update `aiq-zora-ai-deployment` values file |
| `SONAR_ACCESS_TOKEN` | SonarQube scan |
| `DEMO_DEPLOY_PASSWORD` | Confirmation gate for demo deployments |
| `ARGOCD_DEV02_TOKEN` | ArgoCD sync trigger — dev2 |
| `ARGOCD_DEV03_TOKEN` | ArgoCD sync trigger — dev3 |
| `ARGOCD_QA_TOKEN` | ArgoCD sync trigger — QA |
| `ARGOCD_LAB_TOKEN` | ArgoCD sync trigger — lab |
| `ARGOCD_DEMO_TOKEN` | ArgoCD sync trigger — demo |
| `ARGOCD_PERF_TOKEN` | ArgoCD sync trigger — perf |
| `TEAMS_WEBHOOK_DEV02` | Teams notifications — dev2 |
| `TEAMS_WEBHOOK_DEV03` | Teams notifications — dev3 |
| `TEAMS_WEBHOOK_QA` | Teams notifications — QA |
| `TEAMS_WEBHOOK_LAB` | Teams notifications — lab |
| `TEAMS_WEBHOOK_DEMO` | Teams notifications — demo |
| `TEAMS_WEBHOOK_PERF` | Teams notifications — perf |

#### Optional secrets (add only if the app needs them)

| Secret | When needed |
|---|---|
| `DB_PASSWORD_POSTGRES` | App has a PostgreSQL DB and runs DB-dependent tests in CI |
| `REDIS_PASSWORD` | App uses Redis in CI tests |
| `AZURE_LLM_API_KEY` / `AZURE_LLM_ENDPOINT` | App calls Azure OpenAI directly |
| `OIDC_CLIENT_SECRET` / `AZURE_AD_APP_CLIENT_ID` | App does OIDC authentication |

> **Verify:** After Doppler sync runs, confirm secrets are present with `gh secret list --repo <org>/<repo>`. A new repo with zero secrets means it hasn't been added to the Doppler sync yet.

---

## Part 2: Deployment Repository

Branch from `main`:

```bash
cd aiq-zora-ai-deployment
git checkout main && git pull
git checkout -b feat/add-<app-name>
```

### 2.1a Choose the right chart

| App type | Chart | Reference values file |
|---|---|---|
| Core platform service (FastAPI, React, etc.) | `kubernetes/charts/zora-ai-universal-chart` | `values-zora-ai-configuration-server.yaml` |
| Digital worker on `aiq-service` (Payment, Collection, EM2) | `kubernetes/charts/aiq-service` | `kubernetes/azure/demo-wus/advisor/values-zora-ai-payments-backend.yaml` |
| One-off / cron Job | `kubernetes/charts/zora-ai-jobs` | `values-zora-ai-postgres-init-db.yaml` |
| Per-worker dedicated DB | `kubernetes/charts/zora-ai-postgres` | `values-zora-ai-em2-postgres.yaml` |

> **Digital workers do NOT use the universal chart.** They use `aiq-service`, which has its own `SecretStore` (per-namespace, not `ClusterSecretStore`) and ConfigMap structure. See `kubernetes/azure/demo-wus/advisor/` for the canonical Payment + Collection layout, and `kubernetes/azure/demo-wus/values-zora-ai-em2-backend.yaml` for EM2.

### 2.1 Create Helm values file (universal chart)

Create `kubernetes/azure/dev2/values-<app-name>.yaml` (or `kubernetes/aws/values/` for AWS). Use `values-zora-ai-configuration-server.yaml` as a reference:

```yaml
# <app-name> - Dev02 Environment Values
# Chart: kubernetes/charts/zora-ai-universal-chart (cloud-agnostic)

app:
  replicaCount: 1

  dbSecretsVersion: "1"

  imagePullSecrets:
    - name: jfrog-registry-secret

  image:
    repository: artifacts.engineeringplatforms.deloitte.com/aiq-docker-scratch-local/<app-name>
    pullPolicy: Always
    tag: "0.0.1"

  service:
    type: ClusterIP
    port: 8000                   # match the port your app listens on

  ingress:
    enabled: false               # enable once hostname is confirmed
    className: nginx-internal
    secretName: <app-name>-dev02-tls-secret
    path: /
    host: <app-name>.dev02.zoraai.deloitteinnovation.us
    annotations:
      cert-manager.io/cluster-issuer: letsencrypt-prod
      nginx.ingress.kubernetes.io/proxy-connect-timeout: "60"
      nginx.ingress.kubernetes.io/proxy-read-timeout: "600"
      nginx.ingress.kubernetes.io/proxy-send-timeout: "600"

  livenessProbe:
    enabled: false               # enable once health endpoints are implemented
    httpGet:
      path: /api/v1/health/liveness
      port: http
    initialDelaySeconds: 10
    periodSeconds: 10
    timeoutSeconds: 2
    failureThreshold: 3

  readinessProbe:
    enabled: false               # enable once health endpoints are implemented
    httpGet:
      path: /api/v1/health/readiness
      port: http
    initialDelaySeconds: 10
    periodSeconds: 10
    timeoutSeconds: 2
    failureThreshold: 3

  resources:
    limits:
      cpu: "2"
      memory: 4Gi
    requests:
      cpu: "1"
      memory: 2Gi

  env:
    ENV: "dev"
    LOG_LEVEL: "DEBUG"
    # Add DB connection env vars here if the app has a database:
    # DATASOURCE_URL: "zora-ai-postgres2:5432"
    # DATASOURCE_DB_NAME: "<db-name>"
    # DATASOURCE_USERNAME: "<db-user>"
    # DATASOURCE_PASSWORD:
    #   secretKeyRef:
    #     name: zora-ai-db-users-secrets
    #     key: <password-key>

deployedAt: "2026-01-01T00:00:00Z"
```

#### Docker registry mapping by environment

| Environment | JFrog repo path |
|---|---|
| dev2, dev3 | `aiq-docker-scratch-local` |
| qa, lab, perf | `aiq-docker-staging-local` |
| demo | `aiq-docker-release-local` |

Update `repository` accordingly when adding values files for other environments.

### 2.2 Create ArgoCD application manifest

Create `argocd/dev2/<app-name>.yaml`:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: <app-name>
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/charts/zora-ai-universal-chart  # Cloud-agnostic unified chart
    helm:
      valueFiles:
        - ../../azure/dev2/values-<app-name>.yaml  # Cloud prefix added for Azure
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-dev02
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### 2.3 Validate locally

```bash
helm template <app-name> ./kubernetes/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/dev2/values-<app-name>.yaml
```

The output should include a `Deployment` and a `Service`. No errors → safe to commit.

### 2.4 Commit and push

```bash
git add kubernetes/azure/dev2/values-<app-name>.yaml argocd/dev2/<app-name>.yaml
git commit -m "feat(dev02): add <app-name> app"
git push -u origin feat/add-<app-name>
```

Open a PR targeting `main`. Title example: `Add <app-name> to dev02`.

---

## Part 3: Apply ArgoCD App to Cluster

After the deployment PR is merged, register the ArgoCD Application on the cluster. If the cluster uses the **app-of-apps** pattern, ArgoCD picks it up automatically once the parent app syncs. Otherwise, apply manually:

```bash
CONTEXT="zoraai-dev02-eus2-internal-admin"
kubectl --context "$CONTEXT" apply -f argocd/dev2/<app-name>.yaml
```

Verify the app appears in ArgoCD and syncs to `Healthy`.

---

## Part 4: Post-deployment checklist

- [ ] First Docker image pushed to JFrog (`aiq-docker-scratch-local/<app-name>`)
- [ ] ArgoCD app shows `Synced` + `Healthy`
- [ ] Enable health probes in values file once `/api/v1/health/liveness` and `/api/v1/health/readiness` are implemented
- [ ] Enable ingress and confirm TLS certificate is issued if the app needs external access
- [ ] Add `deployedAt` timestamp update to the values file to trigger rolling restarts when needed
- [ ] Repeat steps 2.1–2.2 for additional environments (dev3, qa, demo, etc.)

---

## Troubleshooting

**Pod stuck in `ImagePullBackOff`**
The Docker image hasn't been pushed yet, or the `jfrog-registry-secret` is missing.
```bash
kubectl --context "$CONTEXT" -n zora-ai-dev02 get secret jfrog-registry-secret
```

**ArgoCD shows `OutOfSync` but won't sync**
Force a hard refresh:
```bash
argocd app get <app-name> --hard-refresh
argocd app sync <app-name>
```

**Helm template render fails**
Run with `--debug` to see the full error:
```bash
helm template <app-name> ./kubernetes/charts/zora-ai-universal-chart \
  -f ./kubernetes/azure/dev2/values-<app-name>.yaml --debug
```

**CI/CD pipeline fails on `update-helm-chart` step**
Ensure `PAT_FOR_SVC_ACCOUNT` has write access to `aiq-zora-ai-deployment` and that the values file path in the workflow matches exactly.

**`update-helm-chart` step exits 128 in cleanup, but image push succeeded**
Look at the step log: `✅ Push successful` followed by `fatal: No url found for submodule path '.github/comserv-rbac' in .gitmodules`. This is the **post-job cleanup** failing on a stale submodule entry, not the deployment. Real failure → confirm by checking that the values file commit landed in `aiq-zora-ai-deployment` and ArgoCD started syncing. To silence: remove the orphaned submodule registration in `.gitmodules`.

**`mend-scan` exits 10 with `command 'c++' failed`**
Mend SCA runs `uv sync --no-dev` to enumerate deps; if the project has C-extension packages (e.g. `psycopg2-binary`) without prebuilt wheels, the `nbi` runner lacks `g++` and fails. Fallback path then tries `python -m pip list`, but the `nbi` runner only has `python3` on PATH (no `python` symlink), so it errors with `executable file not found in $PATH`. **Root cause is the runner image, not the app.** `continue-on-error: true` keeps the deploy moving. Real fixes (in order):
1. Switch to `psycopg[binary]` (psycopg3) which ships wheels for all common platforms, or
2. Add `apt-get install build-essential` to the runner, or
3. Symlink `python3 → python` on the runner.

**`force-sync-argocd` exits 56 (curl) but app is actually healthy**
The action polls every ~10s for up to 30 attempts. It can lose the network mid-poll (curl exit 56 = "Failure when receiving data"). For digital workers, this commonly happens when:
- App is `Synced + Progressing` (e.g. just rolled, pods coming up) and polling times out before they're Ready, OR
- Image-pull is blocked by Xray (`ImagePullBackOff`) so the app stays Progressing/Degraded forever.

**Always verify the actual cluster state** (`kubectl get app -n argocd <name>`, `kubectl get pods -n <ns>`) before treating this step as a real failure.

**Collection / Payment ImagePullBackOff in demo-wus**
Both backends pull from `aiq-docker-release-local` and were blocked by JFrog Xray's Critical-CVE policy during the May 2026 demo-wus bring-up. Old pods kept serving traffic; new pods stuck. Workaround: rebuild with a current base image and re-push (Xray re-scans), or have CloudOps grant a tag-level waiver. See [add-new-cluster.md → JFrog Xray](add-new-cluster.md#jfrog-xray-blocking-image-pull-403-forbidden--artifact-download-request-rejected).

**SonarQube job fails with "no coverage to import" / exit 2**
The `sonar.python.coverage.reportPaths` in `sonar-project.properties` doesn't match where the action extracted the coverage artifact. The action **always** downloads to `coverage/`, so set:

```properties
sonar.python.coverage.reportPaths=coverage/coverage.xml
sonar.python.xunit.reportPath=coverage/test-results.xml
```

Older repos that had Sonar commented out in `qa-ci.yaml` never caught this — the new unified workflow exposes it on first run.

**`Run Tests` job fails despite high coverage**
`pytest` returns non-zero on **any** test failure regardless of coverage. The action propagates that exit code (`if [ $TEST_EXIT_CODE -ne 0 ]; then exit 1`). Fix the failing tests in the source repo — there's no CI-side workaround.
