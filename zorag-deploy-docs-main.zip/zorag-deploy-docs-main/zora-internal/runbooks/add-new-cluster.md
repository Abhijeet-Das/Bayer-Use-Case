# Runbook: Add a New Cluster (Deploy Core Zora AI Platform)

End-to-end procedure to deploy the core Zora AI platform (backend, frontend, engine, configuration-server, customer-data-server, agent-skills, postgres, redis, RBAC) to a brand-new Kubernetes cluster.

> **Out of scope:** Creating the Kubernetes cluster itself (EKS/AKS provisioning, node pools, networking, Gateway API / ingress-nginx controller install, External Secrets Operator install, cert-manager install, ArgoCD install). This runbook assumes those are already in place.

**Reference implementations:**
- AWS `dev-advise` (EKS `zoraai-advise-eus`, `us-east-1`) — core platform bring-up, PR [#172](https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment/pull/172), JIRA `ZORAAI-6716`.
- Azure `demo-wus` (`zoraai-demo-wus-internal`, West US) — full stack with **all 4 digital workers** (Insights Navigator/CFO core, Expense Specialist/EM2, Payment Advisor, Collection Advisor), JIRA `ZORAAI-6934`. Use this as the reference when bringing up a cluster that must serve all four workers.

**Currently deployed environments:** dev2, dev3, dev4, qa, lab, perf, demo (eus), **demo-wus** (West US, all 4 workers), colgate-dev, colgate-prod, exxon-dev, nvidia-dev2, nvidia-qa, advise-dev, sut-dev, sut-qa, sut-ppd. See workspace `CLAUDE.md` → "Deployment Environments" for cluster, subscription, and LLM-backend mapping.

---

## Architecture Overview

Core platform + digital workers (all deployed to one namespace, e.g. `zora-ai-<env>`):


| Layer    | Component                                                             | Chart                                   |
| -------- | --------------------------------------------------------------------- | --------------------------------------- |
| Infra    | PostgreSQL (primary DB)                                               | `zora-ai-postgres`                      |
| Infra    | Redis (pub/sub + cache)                                               | `zora-ai-redis`                         |
| Infra    | LiteLLM proxy (model routing)                                         | raw manifests in `<env>/litellm/`       |
| Infra    | External Secrets (Doppler → K8s)                                      | raw manifests in `external-secrets-v1/` |
| Init Job | `postgres-init-db` (creates 5 DBs + 8 users)                          | `zora-ai-jobs`                          |
| Init Job | `zora-agent-skills` (DB migrations + skill ingestion)                 | `zora-ai-jobs`                          |
| App      | backend, frontend, engine, configuration-server, customer-data-server | `zora-ai-universal-chart`               |
| App      | RBAC backend (main + UI-dedicated instance)                           | `zora-ai-comserv-rbac-app`              |
| App      | RBAC UI                                                               | `zora-ai-comserv-rbac-ui`               |
| App      | RBAC API proxy (same-domain `/api` → RBAC backend)                    | raw HTTPRoute                           |
| Worker   | **Insights Navigator** (CFO) — runs on core engine                    | (no separate deployment)                |
| Worker   | **Expense Specialist** (EM2) — own backend + postgres + Milvus        | `aiq-service`, `zora-ai-postgres`, `zora-ai-milvus` |
| Worker   | **Payment Advisor** — own backend + postgres                          | `aiq-service`, `zora-ai-postgres`       |
| Worker   | **Collection Advisor** — own backend + postgres                       | `aiq-service`, `zora-ai-postgres`       |


All core apps point to `zora-ai-postgres:5432` and `zora-ai-redis-master:6379`. Each digital worker (EM2, Payment, Collection) brings its own dedicated PostgreSQL service (`zora-ai-em2-postgres`, `zora-ai-postgres-payment`, `zora-ai-collection-advisor-postgres`) so a worker rebuild can never wipe core platform data. All workers route LLM calls through the in-cluster `litellm:4000` proxy.

---

## Step 0 — Pick Up a JIRA Ticket

Before doing anything else, **create or pick up a JIRA ticket** (e.g. `ZORAAI-XXXX`). The ticket ID drives the branch name, commit scopes, and PR title. Do not start without one.

---

## Prerequisites

Verify before starting — each of these is assumed present on the cluster:

- `kubectl` + admin context for target cluster
- ArgoCD installed and configured to pull from `Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment`
- External Secrets Operator installed (v1 API)
- Gateway API CRDs + gateway controller (AWS: `apps-gateway-internal` in `ska-system`) — preferred. Or nginx-ingress on older Azure envs (deprecated, migrating to Gateway API).
- StorageClass for persistent volumes — check per cluster with `kubectl get storageclass`; pick an encrypted class with `Retain` reclaim policy for databases (examples: AWS `gp3-encrypted`, Azure `azuredisk-premium-milvus-retain`, but names vary)
- **DNS** — on Azure clusters, `external-dns` is typically pre-deployed in `ska-system` and auto-creates DNS records from ingress/HTTPRoute resources. Verify it's running and configured with the right domain filter before deploying apps. No manual DNS requests needed.
  ```bash
  kubectl get deployment external-dns -n ska-system
  kubectl logs -n ska-system deployment/external-dns --tail=20
  # Should show domain filter matching your env domain, and "All records are already up to date"
  ```
- TLS certs auto-provisioned (cert-manager or gateway-managed ACM)
- Doppler workspace access (`pllm-inference` project)

---

## Variables

Set these once for the whole runbook. Example uses `dev-advise` values.

```bash
ENV=dev-advise                                   # Directory name under kubernetes/<cloud>/values/
CLOUD=aws                                        # aws or azure
NAMESPACE=zora-ai-advise                         # K8s namespace
DOMAIN=adev.zoraai.eng.deloitte.com              # Wildcard DNS zone for this env
DOPPLER_CONFIG=dev_advise                        # Doppler config name under pllm-inference
JIRA=ZORAAI-XXXX                                 # From Step 0
BRANCH=${JIRA}_deploy_to_${ENV}
ARGOCD_DIR=argocd/${CLOUD}/${ENV}
VALUES_DIR=kubernetes/${CLOUD}/values/${ENV}/cfo # Product subdirectory (cfo, em, etc.)
```

---

## Step 1 — Create Directory Structure

```bash
cd aiq-zora-ai-deployment
git checkout main && git pull
git checkout -b ${BRANCH}

mkdir -p ${VALUES_DIR}/external-secrets-v1
mkdir -p ${VALUES_DIR}/rbac-api-proxy
mkdir -p ${ARGOCD_DIR}
```

Copy values files + ArgoCD apps from a similar environment (AWS QA or Azure dev2):

```bash
# AWS reference: kubernetes/aws/values/qa/cfo/ + argocd/aws/qa/cfo/
# Azure reference: kubernetes/azure/dev2/ + argocd/dev2/
SOURCE_VALUES=kubernetes/aws/values/qa/cfo
SOURCE_ARGOCD=argocd/aws/qa/cfo

cp ${SOURCE_VALUES}/values-zora-ai-*.yaml ${VALUES_DIR}/
cp ${SOURCE_VALUES}/values-zora-agent-skills.yaml ${VALUES_DIR}/
cp -r ${SOURCE_VALUES}/external-secrets-v1/* ${VALUES_DIR}/external-secrets-v1/
cp -r ${SOURCE_VALUES}/rbac-api-proxy/* ${VALUES_DIR}/rbac-api-proxy/

cp ${SOURCE_ARGOCD}/*.yaml ${ARGOCD_DIR}/
```

> **Edit the copied ArgoCD apps** — see [Step 4b](#step-4b--edit-argocd-app-manifests). The copied manifests still reference the source env's values paths and namespace; they must be adjusted for the new env.

---

## Step 2 — Configure Doppler Secrets

The platform pulls **7 secrets** from Doppler via ExternalSecrets. Create them in Doppler (`pllm-inference` project → `${DOPPLER_CONFIG}` config) **before** applying anything to the cluster.


| Doppler key                  | Used by                                 | Source / format                                                                                     |
| ---------------------------- | --------------------------------------- | --------------------------------------------------------------------------------------------------- |
| `JFROG_DOCKERCONFIGJSON`     | `jfrog-registry-secret` imagePullSecret | Base64 `.dockerconfigjson` for `artifacts.engineeringplatforms.deloitte.com`                        |
| `DB_PASSWORD_POSTGRES`       | postgres admin password                 | Random 32+ chars                                                                                    |
| `DB_PASSWORD_POSTGRES_READ`  | `postgres_read` read-only user          | Random 32+ chars                                                                                    |
| `DB_PASSWORD_ZORA_DEVELOPER` | `zora_developer` shared dev user        | Random 32+ chars                                                                                    |
| `REDIS_PASSWORD`             | Redis AUTH                              | Random 32+ chars                                                                                    |
| `AZURE_LLM_API_KEY`          | Engine → Azure AI Foundry               | Get from LLM project owner                                                                          |
| `OIDC_CLIENT_SECRET`         | RBAC backend Azure AD OIDC              | **Shared across all envs today** because every env uses the same Azure AD app registration `12ccfc85-dd2c-4d1f-af13-5abe46b99921`. Copy from any existing env's Doppler config. May change if envs get their own app registrations in the future. |


**Not in Doppler** — the 7 role-based database user passwords (`backend-password`, `customerdata-password`, `config-password`, `engine-cfo-password`, `engine-em-password`, `rbac-backend-password`, `agent-skills-password`) are auto-generated by the `zora-ai-jobs` Helm chart into `zora-ai-db-users-secrets`.

---

## Step 3 — Bootstrap Doppler Service Token

Create a Doppler service token scoped to `pllm-inference / ${DOPPLER_CONFIG}`, then seed it manually into the cluster so ExternalSecrets can authenticate. This is the **only manual `kubectl` step** in the whole procedure — everything else is GitOps via ArgoCD.

> **Namespace:** The token secret must be created in the namespace where the **External Secrets Operator pod runs** — typically `ska-system`, NOT in `${NAMESPACE}`. The `ClusterSecretStore` references it there. The app namespace itself will be auto-created by ArgoCD (`CreateNamespace=true` syncOption).

```bash
# Find ESO namespace
kubectl get pods -A | grep external-secrets
# → ska-system   external-secrets-xxx   1/1   Running

kubectl create secret generic doppler-token-zora-ai \
  --namespace ska-system \
  --from-literal=dopplerToken='dp.st.<YOUR_TOKEN>'
```

> **Reusing an existing config?** If the new env shares a Doppler config with another env (e.g. `ci_zora_ai`), you can copy the token secret from that cluster's `ska-system` instead of generating a new one. Both approaches work; a dedicated token per cluster is preferred for independent rotation.

Edit `${VALUES_DIR}/external-secrets-v1/cluster-secret-store.yaml` to match:

```yaml
apiVersion: external-secrets.io/v1
kind: ClusterSecretStore
metadata:
  name: doppler-zora-ai
spec:
  provider:
    doppler:
      project: pllm-inference
      config: dev_advise                            # ← match ${DOPPLER_CONFIG}
      auth:
        secretRef:
          dopplerToken:
            name: doppler-zora-ai-token-secret
            key: dopplerToken
            namespace: zora-ai-advise               # ← match ${NAMESPACE}
```

Every ExternalSecret in `zora-ai-external-secrets.yaml` must reference this same `ClusterSecretStore` and the same `${NAMESPACE}`.

> **External Secrets directory:** Most environments share `kubernetes/azure/external-secrets-v1/` (used by demo, lab, perf, colgate, etc.) — this is acceptable when all envs use the same Doppler project/config (`ci_zora_ai`). Only create a per-env `external-secrets-v1/` (e.g. `kubernetes/azure/dev3/external-secrets-v1/`) when the environment needs a different Doppler config or namespace. In that case, copy the shared directory and update the `config:` and `namespace:` fields.

---

## Step 4 — Edit Values Files

For every copied `values-zora-ai-*.yaml`, update cluster-specific fields:

**All apps (universal chart):**

- **Pick `httpRoute` OR `ingress` — not both.** `httpRoute` (Gateway API) is preferred; `ingress` (nginx) is deprecated. Set `enabled: true` on the chosen one with `host` + related fields; set `enabled: false` on the other and leave it empty (no host/path/annotations under the disabled block).
- `app.image.tag` → match the reference env (see "Version Alignment" below)
- `app.resources` → size for the target nodes (see "Resource Sizing" below)
- `app.env.*_URL` → cross-service URLs using new hostnames when external, internal `http://zora-ai-<svc>:<port>` otherwise

Example (AWS, Gateway API):

```yaml
app:
  ingress:
    enabled: false
  httpRoute:
    enabled: true
    host: zora-ai-backend.${DOMAIN}
    path: /
    pathType: PathPrefix
    gatewayName: apps-gateway-internal
    gatewayNamespace: ska-system
    sectionName: apps-gateway-internal-https
```

**Postgres (`values-zora-ai-postgres.yaml`):**

- `persistence.storageClass` → cluster's encrypted storage class (verify with `kubectl get storageclass`)
- `service.type` → `ClusterIP` (internal) unless external access needed
- On Azure, set `service.loadBalancerIP` once IP is known — see [update-loadbalancer-dns.md](update-loadbalancer-dns.md)

**Redis (`values-zora-ai-redis.yaml`):**

- `persistence.storageClass`, `service.type`, LB annotations
- AWS uses NLB: `service.beta.kubernetes.io/aws-load-balancer-type: nlb`

**RBAC backend / backend-ui (`values-zora-ai-rbac-backend*.yaml`):**

- `ISSUER`, `JWT_ISSUER`, `ALLOWED_AUDIENCES` → `https://zora-ai-rbac-backend.${DOMAIN}`
- `LOCALHOST_ENDPOINT` → main frontend on the backend instance, RBAC UI on the UI instance
- `OIDC_CALLBACKURL` → see Step 7 (must match URIs registered in Azure AD)
- `OIDC_ISSUER`/`OIDC_CLIENTID` → Azure AD tenant + app ID (check with existing envs; current tenant `36da45f1-dd2c-4d1f-af13-5abe46b99921`, app `12ccfc85-5a4c-4172-9f39-9d0cafe8d3f9`)

**RBAC frontend (`values-zora-ai-rbac-frontend.yaml`):**

- `REACT_APP_API_URL` → `https://zora-ai-rbac-frontend.${DOMAIN}/api` (proxied by HTTPRoute to `zora-ai-rbac-app-ui`)
- `REACT_CC_PROD_DOMAIN` → `zora-ai-rbac-frontend.${DOMAIN}`

**RBAC API proxy (`rbac-api-proxy/ingress.yaml`):**

- `hostnames` + `namespace` match the RBAC UI

**postgres-init-db (`values-zora-ai-postgres-init-db.yaml`):**

- Leave `passwordsGeneration: 1` for a new cluster (only bump when rotating passwords on an existing cluster)
- Script content and user list rarely need changes
- **Set `restartPolicy: Never`** so failed pods are kept for debugging instead of being deleted immediately. Also set `ttlSecondsAfterFinished: 604800` (7 days). Without this, a failed job's pod is cleaned up before you can run `kubectl logs` on it.

**Engine (`values-zora-ai-engine.yaml`):**

- `AZURE_LLM_ENDPOINT`, `DEF_MODEL`, `DB_AGENT_MODEL_NAME` → LLM routing for the env
- `REDIS_CHANNEL_USER_REQUEST: user_request` + `REDIS_CHANNEL_AGENT_RESPONSE: agent_response` — must match backend's channels

### Version Alignment

Image tags change frequently — **always copy current tags from the reference env** instead of hardcoding:

```bash
grep -h "tag:" kubernetes/aws/values/qa/cfo/values-zora-ai-*.yaml
grep -h "tag:" kubernetes/azure/dev2/values-zora-ai-*.yaml
```

Exception — **pinned infrastructure tags** (don't change without explicit need):

- Postgres: `17.7-2026.02.09-1842` (textsearch image)
- Redis: `7.4-2026.02.19-1340` (redis-stack-server)

### Resource Sizing

Start from the reference env's `resources.requests` / `resources.limits`, then sanity-check against the target cluster:

```bash
# Node allocatable capacity
kubectl describe nodes | grep -A5 Allocatable

# Actual usage (once apps are running)
kubectl top pods -n ${NAMESPACE}
```

Aim for total `requests` across all pods to stay below ~80% of aggregate node allocatable. See the `/helm-argocd` skill's **Resources** section for the full sizing methodology (Prometheus queries for historical peak usage, QoS tier selection, guidance on `requests` vs `limits`). If a pod ends up Pending or OOMKilled, see [Common Issues](#pod-pending-or-oomkilled-any-app) below.

---

## Step 4b — Edit ArgoCD App Manifests

The ArgoCD app manifests copied in Step 1 still reference the source env — adjust each one:

- `metadata.name` — drop the old env suffix (e.g. `-qa` → no suffix, or `-${ENV}`)
- `spec.source.path` — leave pointing at `kubernetes/charts/<chart>`; this rarely changes
- `spec.source.helm.valueFiles` — path **relative to the chart directory**, NOT the repo root (this is the #1 cause of "path not found" ArgoCD errors). Example: `../../aws/values/${ENV}/cfo/values-zora-ai-backend.yaml`
- `spec.destination.namespace` — set to `${NAMESPACE}`
- `spec.source.targetRevision` — set to `main` (see Step 5 for why)
- **`postgres-init-db.yaml` needs an `ignoreDifferences` block** — if the source env doesn't already have it, add it now:

  ```yaml
  spec:
    ignoreDifferences:
      - group: ""
        kind: Secret
        name: zora-ai-db-users-secrets
        jsonPointers:
          - /data
    syncPolicy:
      syncOptions:
        - RespectIgnoreDifferences=true
  ```

  **Why:** The init-db Job generates random passwords with `randAlphaNum(32)` and writes them to `zora-ai-db-users-secrets`. Helm's `lookup()` (which normally preserves existing secrets) doesn't work in ArgoCD — `helm template` has no cluster access. Without this block, every sync regenerates the passwords and breaks every app that holds the old ones.

Commit all values and ArgoCD app edits to `${BRANCH}`:

```bash
git checkout ${BRANCH}
git add ${VALUES_DIR} ${ARGOCD_DIR}
git commit -m "feat(${ENV}): configure core Zora AI platform"
git push -u origin ${BRANCH}
```

---

## Step 5 — Deploy via GitOps (No Manual kubectl)

**Everything ArgoCD-managed goes through Git — no `kubectl apply` on manifests.**

### The two-branch `targetRevision` rule

ArgoCD on the cluster only watches `main`. To deploy **now** from the feature branch while keeping `main` clean for merge, the ArgoCD apps live on **both** branches at the same time with different `targetRevision`s:


| Branch                | `targetRevision` in ArgoCD app | When it's active                                                                                                  |
| --------------------- | ------------------------------ | ----------------------------------------------------------------------------------------------------------------- |
| `${BRANCH}` (feature) | `main`                         | After PR merge — at merge time these overwrite `main` and ArgoCD keeps syncing from `main` with zero manual flips |
| `main`                | `${BRANCH}`                    | **Now**, during bring-up — ArgoCD syncs from `${BRANCH}` so you can iterate on values without merging             |


**So:** on the feature branch, edits should always show `targetRevision: main`. On `main`, each wave commits the same app file but with `targetRevision: ${BRANCH}` so ArgoCD renders it from the feature branch. When the PR merges, the feature-branch version (with `targetRevision: main`) replaces the `${BRANCH}`-pointing one on `main` — ArgoCD keeps syncing, now from `main`.

### Promote helper

Use this to move an app from the feature branch into `main` with the `targetRevision` rewritten:

```bash
promote_to_main () {
  local file=$1
  local content
  content=$(git show ${BRANCH}:${file}) || return 1
  if ! echo "$content" | grep -q '^\s*targetRevision: main\s*$'; then
    echo "ERROR: ${file} on ${BRANCH} does not contain 'targetRevision: main'. Fix the feature branch first." >&2
    return 1
  fi
  echo "$content" | sed "s|targetRevision: main|targetRevision: ${BRANCH}|" > ${file}
  git add ${file}
}
```

The helper refuses to promote anything that doesn't have `targetRevision: main` on the feature branch. This catches the case where someone accidentally committed `targetRevision: ${BRANCH}` back to the feature branch — if the helper silently copied that value through, post-merge `main` would point at the deleted feature branch and every app would go OutOfSync.

### Bootstrap app-of-apps

Before deploying any waves, apply the app-of-apps manifest to ArgoCD. This is the one `kubectl apply` allowed in Step 5 — it bootstraps ArgoCD's awareness of the new environment.

```bash
# On main branch (or wherever you stored app-of-apps/demo-wus.yaml)
kubectl apply -f argocd/app-of-apps/${ENV}.yaml -n argocd
```

> **app-of-apps `targetRevision` must be `main`** — it watches the `argocd/${ENV}/` directory on main, which is where you commit wave files. Do NOT set it to the feature branch, or ArgoCD will see all apps at once and sync everything before you're ready.

After each wave commit, app-of-apps auto-syncs within ~1 minute. If it doesn't pick up new apps, trigger a hard refresh:
```bash
kubectl -n argocd patch app zora-ai-app-of-apps \
  -p '{"metadata":{"annotations":{"argocd.argoproj.io/refresh":"hard"}}}' --type merge
```

### Deploy in 3 waves

Waves 2 and 3 can be merged if you're confident — they're split to give a clear recovery point between DB readiness and everything that depends on it.

#### Wave 1 — Infrastructure (external-secrets + postgres + redis + init-db)

Bootstrap all the stateful + secret-plumbing apps together. External Secrets is in this wave because postgres/redis ExternalSecrets must resolve before the StatefulSets start — but the ESO ClusterSecretStore / ExternalSecret manifests are part of the same app tree, so committing them in one wave is simpler than splitting.

```bash
git checkout main && git pull
for f in external-secrets postgres redis postgres-init-db; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
git commit -m "feat(${ENV}): deploy infra (external-secrets, postgres, redis, init-db)"
git pull --rebase origin main && git push
```

> **Double-check the `ignoreDifferences` block is present on `postgres-init-db.yaml`** (see [Step 4b](#step-4b--edit-argocd-app-manifests)) before this wave — without it, passwords get regenerated on every sync.

Rotating passwords later: delete the secret, bump `passwordsGeneration` in values, wait for re-sync.

Verify resources synced in the target namespace before moving on:

```bash
kubectl get externalsecret -n ${NAMESPACE}                             # all Synced
kubectl -n ${NAMESPACE} rollout status statefulset/zora-ai-postgres
kubectl -n ${NAMESPACE} rollout status statefulset/zora-ai-redis-master

kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- psql -U postgres -c '\l' | \
  grep -E 'customer_data|zora_app|zora_config|rbac_db|skill_storage'
kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- psql -U postgres -c '\du' | \
  grep -E 'zora_|postgres_read'
```

Expected: 5 databases + 9 users (`zora_backend_user`, `zora_customerdata_user`, `zora_config_user`, `zora_engine_cfo_user`, `zora_engine_em_user`, `zora_rbac_backend_user`, `zora_agent_skills_user`, `zora_developer`, `postgres_read`).

> **uuid-ossp gotcha:** The init script grants `CREATE ON DATABASE skill_storage TO zora_agent_skills_user` so agent-skills migrations can install the `uuid-ossp` extension. Without this, migrations fail with "permission denied for database".

#### Wave 2 — RBAC + core apps

> **⚠️ RBAC backend must be in the same wave as backend** — the backend runs `seed_rbac_data()` on startup which inserts into RBAC tables (`public.application`, etc.). If RBAC backend hasn't run its migrations yet, the backend crashes on startup with `UndefinedTable`. Deploy RBAC backend in Wave 2, not Wave 3.

```bash
for f in agent-skills configuration-server customer-data-server rbac-backend rbac-backend-ui rbac-frontend rbac-api-proxy backend engine frontend; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
git commit -m "feat(${ENV}): deploy core apps and RBAC"
git pull --rebase origin main && git push
```

> **Expected startup order:** RBAC backend starts first and runs DB migrations (creates tables in `rbac_db`). Backend then starts and seeds RBAC data successfully. If backend starts before RBAC migrations complete it will CrashLoopBackOff a few times then self-heal — this is normal. Do not restart pods manually; wait for the next backoff cycle.

**After Wave 2 is healthy — re-run init-db:**

App migrations in Wave 2 create schemas that init-db needs to grant permissions on. Because those schemas didn't exist at Wave 1 time, those grants were skipped. Known cases:

| Schema | Database | Created by | Grants needed for |
|--------|----------|------------|-------------------|
| `cfo_data` | `customer_data` | `customer-data-server` | `zora_engine_cfo_user` |
| `em_data` | `customer_data` | `customer-data-server` | `zora_engine_em_user` |

This pattern applies to any future app that creates a new schema in a database init-db manages — always re-run init-db after Wave 2 on a new cluster.

```bash
# Delete the completed/failed job — ArgoCD will re-create it immediately
kubectl delete job -n ${NAMESPACE} -l app.kubernetes.io/instance=zora-ai-postgres-jobs
```

Wait for the new job to complete, then verify:

```bash
kubectl get pods -n ${NAMESPACE} | grep postgres-jobs   # Completed

kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- \
  psql -U postgres -d customer_data -c \
  "SELECT has_schema_privilege('zora_engine_cfo_user', 'cfo_data', 'USAGE');"
# → t
```

#### Wave 3 — Backup + advisors (optional)

```bash
for f in postgres-backup postgres-idle-cleaner; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
# Add advisor apps here if applicable
git commit -m "feat(${ENV}): deploy backup and advisors"
git pull --rebase origin main && git push
```

Verify all pods Running + Ready:

```bash
kubectl -n ${NAMESPACE} get pods
kubectl get application -n argocd | grep ${ENV}
```

---

## Step 5b — Deploy Additional Digital Workers (Optional)

Deploy additional digital workers after the core platform is healthy. Which workers to install depends on the use case for the new environment.

> **Reference:** demo-wus has all 4 workers deployed — see `kubernetes/azure/demo-wus/` (EM2 at top level, Payment + Collection under `advisor/`) and `argocd/demo-wus/`.

### EM2 (Expense Management v2)

EM2 requires 3 dedicated components (all in `${NAMESPACE}`, same as core platform):

| Component | Chart | Values file |
|-----------|-------|-------------|
| PostgreSQL | `zora-ai-postgres` | `values-zora-ai-em2-postgres.yaml` |
| Milvus | `zora-ai-milvus` | `values-zora-ai-em2-milvus.yaml` |
| Backend | `aiq-service` | `values-zora-ai-em2-backend.yaml` |

Copy values files from an existing env that uses EM2 (lab, colgate, perf):
```bash
SOURCE_EM2=kubernetes/azure/lab   # or colgate, perf — pick the closest to your target env
cp ${SOURCE_EM2}/values-zora-ai-em2-backend.yaml kubernetes/azure/${ENV}/values-zora-ai-em2-backend.yaml
cp ${SOURCE_EM2}/values-zora-ai-em2-postgres.yaml kubernetes/azure/${ENV}/values-zora-ai-em2-postgres.yaml
cp ${SOURCE_EM2}/values-zora-ai-em2-milvus.yaml kubernetes/azure/${ENV}/values-zora-ai-em2-milvus.yaml
```

#### EM2 Variables

```bash
EM2_DOPPLER_CONFIG=stg_${ENV}_em2   # Create in pllm-inference project, duplicate from stg_em2
```

Key values to update in `values-zora-ai-em2-backend.yaml`:

1. **Ingress host**: `zoraai-emv2.${DOMAIN}`
2. **dopplerTokenSecretName**: `doppler-token-secret-em2` (use distinct name to avoid conflicts with core platform token)
3. **External secrets**: enable both `secretStore` and `externalSecret`
4. **Milvus URI**: `http://zora-ai-em2-milvus-standalone-service:19530` (**port 19530, NOT 443** — 443 is the Attu UI service)
5. **Redis channels** — must match `digital_workers.channel` in `zora_app` DB:
   ```yaml
   REDIS_CHANNEL_USER_REQUEST: "em_user_request_memory_dev"
   REDIS_CHANNEL_AGENT_RESPONSE: "em_agent_response_memory_dev"
   ```
6. **Azure LLM endpoint** — add to ConfigMap (not in Doppler), copy from a reference env (lab/colgate):
   ```yaml
   AZURE_LLM_ENDPOINT: "<Azure AI Foundry models endpoint>"
   AZURE_EMBEDDING_ENDPOINT: "<Azure AI Foundry embedding endpoint>"
   AZURE_EMBEDDING_DEPLOYMENT: "text-embedding-3-small"
   AZURE_EMBEDDING_DIMENSIONS: "1536"
   DEF_MODEL: "gpt-oss-120b"
   DEF_MODEL_PROVIDER: "openai"
   PROTOCOL_PARSER_ENABLED: "true"
   ```
7. **Storage class**: `managed-premium-class` (check `kubectl get storageclass` for the default)
8. **Postgres service type**: `ClusterIP` (not LoadBalancer — EM2 postgres is internal only)
9. **Image**: `artifacts.engineeringplatforms.deloitte.com/aiq-docker-staging/aiq-em-v2-qa:v2.2.20`

### EM2 Doppler Bootstrap

Create a dedicated Doppler config and token — do not reuse the core platform token:

```bash
# 1. In Doppler dashboard: create config '${EM2_DOPPLER_CONFIG}' in pllm-inference project
#    Duplicate from stg_em2 — it contains all required secrets:
#    AZURE_LLM_API_KEY, AZURE_EMBEDDING_API_KEY, MILVUS_PASSWORD,
#    UNIFIED_DB_HOST/PORT/NAME/USER/PASSWORD, REDIS_HOST/PASSWORD, LITELLM_KEY, etc.

# 2. Generate service token scoped to pllm-inference / ${EM2_DOPPLER_CONFIG}

# 3. Create secret in the APP namespace (NOT ska-system — aiq-service uses a per-namespace SecretStore)
kubectl create secret generic doppler-token-secret-em2 \
  --namespace ${NAMESPACE} \
  --from-literal=dopplerToken='dp.st.<YOUR_TOKEN>'
```

> **Key difference from core platform**: Core platform token (`doppler-token-zora-ai`) goes in `ska-system` because it uses a `ClusterSecretStore`. EM2 uses a per-namespace `SecretStore` (created by `aiq-service` chart), so its token must be in `${NAMESPACE}`.

### Deploy EM2

```bash
git checkout ${BRANCH}
# Add values files to feature branch, commit and push

git checkout main
for f in em2-postgres em2-milvus em2-backend; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
git commit -m "feat(${ENV}): deploy EM2 (postgres, milvus, backend)"
git pull --rebase origin main && git push
```

Verify:
```bash
kubectl get pods -n ${NAMESPACE} | grep em2    # all Running
kubectl get externalsecret -n ${NAMESPACE} | grep em2   # SecretSynced True
```

### EM2 Digital Worker Routing

The backend routes messages based on which digital worker is assigned to the workspace, using a **first-match priority** map in `app/services/message_service.py`. Since "Insights Navigator" comes first in the map, if both Insights Navigator and Expense Specialist are in the same workspace, ALL messages will go to Insights Navigator.

**Workaround**: Create a dedicated workspace with **only Expense Specialist** assigned. Do not mix CFO and EM2 workers in the same workspace.

### Payment Advisor

Payment Advisor requires 2 components in `${NAMESPACE}`:

| Component | Chart | Values file (demo-wus reference) |
|-----------|-------|----------------------------------|
| PostgreSQL | `zora-ai-postgres` | `advisor/values-zora-ai-payments-postgres.yaml` |
| Backend | `aiq-service` | `advisor/values-zora-ai-payments-backend.yaml` |

Copy from the `demo-wus` reference:

```bash
mkdir -p kubernetes/azure/${ENV}/advisor
cp kubernetes/azure/demo-wus/advisor/values-zora-ai-payments-*.yaml kubernetes/azure/${ENV}/advisor/
cp argocd/demo-wus/payment-advisor-backend.yaml argocd/${ENV}/
cp argocd/demo-wus/postgres-payments.yaml argocd/${ENV}/
```

Key values to update in `values-zora-ai-payments-backend.yaml`:

1. **Image**: `artifacts.engineeringplatforms.deloitte.com/aiq-docker-release-local/aiq-zora-payment-advisor-backend:<tag>` — use `qa` for non-prod, semantic version (e.g. `2.0.1`) for releases.
2. **Ingress host**: `zora-ai-paymentadv-backend.${DOMAIN}` (use `httpRoute` instead on AWS / Gateway-API clusters).
3. **dopplerTokenSecretName**: `doppler-token-secret-pay` (must be unique per worker — see [doppler-token-namespacing](#doppler-token-namespacing-for-aiq-service-workers)).
4. **DB connection**: points to its **own dedicated postgres** (`DB_HOST: zora-ai-postgres-payment`), NOT the core `zora-ai-postgres`. Keeps payment data isolated.
5. **LLM**: `AZURE_LLM_ENDPOINT: "http://litellm:4000/v1/"`, `DB_AGENT_MODEL_NAME: "gpt-oss-120b-dgx"` (or `-azure` / `-aws` per cluster).
6. **API key**: `AZURE_LLM_API_KEY` from `secretKeyRef: { name: litellm-creds, key: master-key }` — not from the worker's own Doppler secret. Reuses the cluster-wide LiteLLM master key.

#### Payment Doppler Bootstrap

Create a dedicated Doppler config:

```bash
PAY_DOPPLER_CONFIG=ci_${ENV}_payment   # or reuse ci_payment if shared

# 1. In Doppler dashboard: duplicate from an existing payment config
# 2. Generate service token scoped to pllm-inference / ${PAY_DOPPLER_CONFIG}
# 3. Create the token secret in the APP namespace
kubectl create secret generic doppler-token-secret-pay \
  --namespace ${NAMESPACE} \
  --from-literal=dopplerToken='dp.st.<TOKEN>'
```

#### Deploy Payment Advisor

```bash
# On main:
for f in postgres-payments payment-advisor-backend; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
git commit -m "feat(${ENV}): deploy Payment Advisor"
git pull --rebase origin main && git push
```

Verify:
```bash
kubectl get pods -n ${NAMESPACE} | grep payment    # backend + postgres Running
kubectl get externalsecret -n ${NAMESPACE} | grep payment   # SecretSynced True
```

### Collection Advisor

Same structure as Payment Advisor:

| Component | Chart | Values file (demo-wus reference) |
|-----------|-------|----------------------------------|
| PostgreSQL | `zora-ai-postgres` | `advisor/values-zora-ai-collection-postgres.yaml` |
| Backend | `aiq-service` | `advisor/values-zora-ai-collections-backend.yaml` |

Copy from demo-wus:
```bash
cp kubernetes/azure/demo-wus/advisor/values-zora-ai-collection*.yaml kubernetes/azure/${ENV}/advisor/
cp kubernetes/azure/demo-wus/advisor/values-zora-ai-collections-backend.yaml kubernetes/azure/${ENV}/advisor/
cp argocd/demo-wus/collection-advisor-backend.yaml argocd/${ENV}/
cp argocd/demo-wus/postgres-collections.yaml argocd/${ENV}/
```

Key values to update in `values-zora-ai-collections-backend.yaml`:

1. **Image**: `aiq-docker-release-local/aiq-zora-collection-advisor-backend:<tag>`
2. **Ingress host**: `zora-ai-collectionadv-backend.${DOMAIN}`
3. **dopplerTokenSecretName**: `doppler-token-secret-col`
4. **DB connection**: dedicated postgres `DB_HOST: zora-ai-collection-advisor-postgres`
5. **LLM**: same LiteLLM proxy setup as Payment.

#### Collection Doppler Bootstrap

```bash
COL_DOPPLER_CONFIG=ci_${ENV}_collection
kubectl create secret generic doppler-token-secret-col \
  --namespace ${NAMESPACE} \
  --from-literal=dopplerToken='dp.st.<TOKEN>'
```

#### Deploy Collection Advisor

```bash
# On main:
for f in postgres-collections collection-advisor-backend; do
  promote_to_main ${ARGOCD_DIR}/${f}.yaml
done
git commit -m "feat(${ENV}): deploy Collection Advisor"
git pull --rebase origin main && git push
```

### Doppler Token Namespacing for `aiq-service` Workers

Every worker deployed via the `aiq-service` chart (EM2, Payment, Collection) creates its own per-namespace `SecretStore`. Each store needs its **own** Doppler token secret — they must NOT share names:

| Worker | Doppler token secret name |
|--------|---------------------------|
| EM2 | `doppler-token-secret-em2` |
| Payment | `doppler-token-secret-pay` |
| Collection | `doppler-token-secret-col` |

If two workers share a token secret name, only the first worker's `SecretStore` will own it; the second's ExternalSecret will fail to sync.

> **Why per-namespace SecretStore?** `aiq-service` workers use `kind: SecretStore` (namespace-scoped) instead of `ClusterSecretStore`, so the token must live in the same namespace as the worker. Core platform uses `ClusterSecretStore` and the token lives in `ska-system`.

### Channel Routing for All 4 Workers

Each worker reads from / writes to specific Redis pub/sub channels. The values must exactly match the `digital_workers.channel` column in the `zora_app` DB so the backend dispatches messages to the right worker:

| Worker | `REDIS_CHANNEL_USER_REQUEST` | `REDIS_CHANNEL_AGENT_RESPONSE` |
|--------|------------------------------|--------------------------------|
| Insights Navigator (CFO) | `user_request` | `agent_response` |
| Expense Specialist (EM2) | `em_user_request_memory_dev` | `em_agent_response_memory_dev` |
| Payment Advisor | (configured in worker's Doppler secret — verify match in DB) | |
| Collection Advisor | (configured in worker's Doppler secret — verify match in DB) | |

After all workers are deployed, verify channels:
```bash
# Inspect channels seeded in the zora_app DB:
kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- \
  psql -U postgres -d zora_app -c "SELECT name, channel FROM digital_workers ORDER BY name;"

# Confirm engine + each worker are subscribed:
kubectl -n ${NAMESPACE} exec zora-ai-redis-master-0 -c redis -- redis-cli \
  -a "$(kubectl -n ${NAMESPACE} get secret zora-ai-redis -o jsonpath='{.data.redis-password}' | base64 -d)" \
  PUBSUB CHANNELS '*'
```

### Per-Worker Health Check

After each worker is deployed:
```bash
kubectl -n ${NAMESPACE} get pods -l app=<worker>     # Running
kubectl -n ${NAMESPACE} logs -f deploy/<worker>      # No CrashLoop, no LLM auth errors
kubectl -n ${NAMESPACE} get ingress | grep <worker>  # Hostname registered
```

End-to-end test (per worker, in UI):
1. Create workspace with **only that worker** (avoid first-match-priority bug — see "EM2 Digital Worker Routing" above).
2. Ask a domain-specific question (Payment: "Why is invoice X past due?"; Collection: "What's our DSO trend?").
3. Tail engine + worker backend logs to confirm message round-trip via Redis.

---

## Step 6 — Register OIDC Redirect URIs in Azure AD

SSO login will fail with `AADSTS50011: redirect URI mismatch` until the two new callback URIs are added to the Azure AD app registration.

**Self-service portal:** [https://appreg.iam.deloitteresources.com/appAuthentication/12ccfc85-5a4c-4172-9f39-9d0cafe8d3f9](https://appreg.iam.deloitteresources.com/appAuthentication/12ccfc85-5a4c-4172-9f39-9d0cafe8d3f9)

> Requires access from the internal Deloitte network (office or VPN).

**URIs to register (client type: Web):**

- `https://zora-ai.${DOMAIN}/rbac/authentication/login/callback` (main frontend login)
- `https://zora-ai-rbac-frontend.${DOMAIN}/api/authentication/login/callback` (RBAC UI login)

If the self-service portal doesn't work, fall back to opening a CloudOps ticket.

---

## Step 7 — Assign RBAC Roles to a Test User

New users are auto-created on first SSO login (`ALLOW_AUTO_USER_CREATION: "true"`) and auto-assigned `RBAC-ROOT` via `DEFAULT_ROLE_KEY`. `RBAC-ROOT` grants only RBAC admin permissions — users need additional application-specific roles to use Zora features (create workspace, add digital workers, ask questions).

Follow [rbac-user-role-assignment.md](rbac-user-role-assignment.md):

1. The test user logs in to the frontend via SSO once (this auto-creates their record in `users`).
2. Find the user's ID:
  ```bash
   kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- \
     psql -U postgres -d rbac_db -c \
     "SELECT id, resource->>'username' AS email FROM users ORDER BY id DESC LIMIT 10;"
  ```
3. Query available roles (IDs come from seed data and vary by env):
   ```bash
   kubectl -n ${NAMESPACE} exec zora-ai-postgres-0 -c postgres -- \
     psql -U postgres -d rbac_db -c \
     "SELECT id, key FROM roles ORDER BY id;"
   ```
4. Assign `RBAC-ROOT` (RBAC admin permissions) + a Zora feature role appropriate for the product, e.g. `financial_reporting_analyst` (CFO Insights + Expense Management). Other feature roles typically seeded: `senior_finance_leadership`, `operational_finance`, `collections_manager`, `payments_manager`, `forward_deployment_engineer`. See [rbac-user-role-assignment.md](rbac-user-role-assignment.md) for the exact INSERT statements.
5. User logs out and back in to refresh the JWT.

---

## Step 8 — Smoke Test

### 8a — Infrastructure checks

```bash
# Frontend loads + SSO redirects to Azure AD
open https://zora-ai.${DOMAIN}

# Backend readiness (includes DB pool ping)
kubectl -n ${NAMESPACE} port-forward svc/zora-ai-backend 8000:8000 &
curl -sf http://localhost:8000/api/v1/health/readiness

# Engine skills loaded
kubectl -n ${NAMESPACE} logs deploy/zora-ai-engine --tail=100 | grep -i skill

# Redis pub/sub wired up
kubectl -n ${NAMESPACE} exec zora-ai-redis-master-0 -c redis -- redis-cli \
  -a "$(kubectl -n ${NAMESPACE} get secret zora-ai-redis -o jsonpath='{.data.redis-password}' | base64 -d)" \
  PUBSUB CHANNELS '*'
# Expect: user_request, agent_response, agent_response_streaming
```

### 8b — Create workspace + assign digital workers, then test

In the UI (as the test user from Step 7):

1. **Create a workspace.** UI → "Create workspace" → pick a name.
2. **Assign digital workers** to the workspace. Available types correspond to the module the env is set up for:
  - **Insights Navigator** — CFO domain (uses Redis channel `user_request` / `agent_response`)
  - **Expense Specialist** — Expense Management domain (uses channel `em_user_request_memory_dev`)
  - Plus others enabled by the feature role (check the workspace config page for the current list)
3. **Only after a digital worker is assigned** can the user click "Ask Zora" and type a question.
4. Ask a test query that matches the worker's domain, e.g. for Insights Navigator: *"What is our total revenue?"*.

Tail logs during the query:

```bash
kubectl -n ${NAMESPACE} logs -f deploy/zora-ai-engine
kubectl -n ${NAMESPACE} logs -f deploy/zora-ai-backend
```

Expected flow: UI → backend → Redis publish `user_request` → engine consumes → LLM call → SQL on `customer_data.cfo_data` → response on `agent_response` → UI renders.

---

## Step 9 — Additional Testing, Then Merge

Before merging to `main`, exercise the system more broadly:

- Tail `zora-ai-backend`, `zora-ai-engine`, `zora-ai-configuration-server`, `zora-ai-customer-data-server` logs — no error spam
- `zora-ai-postgres` logs — no auth failures, connection resets
- `zora-ai-redis-master` logs — no replica lag warnings
- `zora-ai-rbac-app` + `zora-ai-rbac-app-ui` logs — no 500s on token validation
- Run a manual postgres-backup job once and confirm the dump lands in the backup location (see [postgres-restore.md](postgres-restore.md))
- Ask 2–3 different questions per digital worker type to exercise SQL paths, hallucination guardrails, error handling
- Log in as a second test user to confirm multi-tenant isolation (roles + workspaces)

When satisfied, open the PR:

```bash
gh pr create --title "Add core Zora AI platform to ${ENV}" --body "..."
```

### What happens when the PR merges

Up until merge:

- `main` has ArgoCD apps with `targetRevision: ${BRANCH}` → ArgoCD syncs from the feature branch (current live state).
- `${BRANCH}` has ArgoCD apps with `targetRevision: main` → these will become the new `main` after merge.

At merge time, the feature-branch version (pointing at `main`) overwrites the `${BRANCH}`-pointing one on `main`. ArgoCD picks up the change and from then on syncs from `main`. **No manual flip, no extra commits.**

**Invariant that makes this work:** on `${BRANCH}`, ArgoCD apps must *always* have `targetRevision: main`. Only the versions committed to `main` during waves (Step 5) carry `targetRevision: ${BRANCH}`. The `promote_to_main` helper rewrites in that single direction (`main` → `${BRANCH}`) when copying from the feature branch to `main`; never commit `targetRevision: ${BRANCH}` back onto the feature branch.

---

## Step 10 — Grafana Dashboards and Alerts

Dashboards and alerts are pushed to Grafana via its HTTP API — not synced through ArgoCD. The **[/grafana skill](../../.claude/skills/grafana/SKILL.md)** handles cluster switching, dashboard upload, and alert rule application; use it rather than hand-crafting curl calls.

1. **Add the cluster to `grafana/.clusters.env`** (gitignored) with its Grafana URL + API token, then switch context:
   ```bash
   ./grafana/switch-grafana.sh ${ENV}
   ```
2. **Upload dashboards** (JSON sources in `grafana/dashboards/`, pushed to the `Zora-AI` folder via Grafana API — see the `/grafana` skill for the exact call):
   - `zora-ai-kubernetes-metrics.json` — per-pod CPU/memory/restarts
   - `zora-ai-logs.json` — Loki log search across all pods
   - `zora-ai-postgresql.json` — Postgres USE metrics
   - `zora-ai-redis.json` — Redis USE metrics
3. **Apply alert rules** from `grafana/alerts/zora-ai.json`. Ask Claude `apply Zora-AI alerts to ${ENV}` — the skill invokes the ruler API (`POST /api/ruler/grafana/api/v1/rules/Zora-AI`) and replaces the whole group.
4. **Verify** firing alerts are empty (`ALERTS{grafana_folder="Zora-AI"}` returns nothing) and the Teams contact point is reachable (send a test alert).
5. Commit any env-specific dashboard tweaks back to `grafana/dashboards/`.

See the [/grafana skill](../../.claude/skills/grafana/SKILL.md) for contact-point + notification-policy setup (Grafana v10 vs v12 API differences) and alert rule structure.

---

## Common Issues

### `permission denied for schema public` (RBAC backend crash on new cluster)

RBAC backend fails migration with `permission denied for schema public` because the `zora_rbac_backend_user` was never granted permissions — the init-db script died early before reaching those grants.

**Root cause:** The init-db script uses `set -e` and calls `grant_read_schema` (which uses `ON_ERROR_STOP=1`) for the `cfo_data` and `em_data` schemas. On a fresh cluster those schemas don't exist yet (created later by customer-data-server migrations), so the script exits at that point without completing the RBAC user grants.

**Fix:** Ensure the init-db values file uses `grant_read_schema_safe` (tolerates missing schemas) for `cfo_data` and `em_data`. Then delete the failed job and let ArgoCD re-create it:

```bash
# After fixing the values file and pushing to feature branch:
kubectl -n argocd patch app zora-ai-postgres-init-db \
  -p '{"metadata":{"annotations":{"argocd.argoproj.io/refresh":"hard"}}}' --type merge
# Wait for refresh to pull the new script, then:
kubectl delete job -n ${NAMESPACE} -l app.kubernetes.io/instance=zora-ai-postgres-jobs
```

ArgoCD will re-create the job with the fixed script. Verify it completes:
```bash
kubectl get pods -n ${NAMESPACE} | grep postgres-jobs   # should show Completed
```

Once the job completes, RBAC backend will self-heal on the next restart cycle.

### `password authentication failed for user "zora_<role>_user"`

The init-db job regenerated passwords but secrets weren't updated (or vice versa). Usually means `ignoreDifferences` is missing from the postgres-init-db ArgoCD app. **Fix:** add `ignoreDifferences` (Step 5 Wave 1), delete `zora-ai-db-users-secrets`, bump `passwordsGeneration`, let init-db re-sync, then restart app pods.

### init-db job failed but pod logs are gone

If the init-db job fails and the pod is already deleted before you can check logs, it means `restartPolicy` is set to `Always` or `OnFailure` (default). With `backoffLimit: 1` the pod gets cleaned up after 1 retry.

**Fix:** Set `restartPolicy: Never` and `ttlSecondsAfterFinished: 604800` in the init-db values file (see Step 4). This keeps failed pods in `Error` status for 7 days so you can run `kubectl logs`.

### `AADSTS50011: redirect URI mismatch`

Redirect URI in Azure AD app doesn't match `OIDC_CALLBACKURL`. See Step 6.

### UI request hangs, no response

Several possible causes (check in order):

1. **No digital worker assigned** to the workspace — the user must pick one before "Ask Zora" works (Step 8b).
2. **Channel mismatch** — verify backend and engine use the same Redis channel names (CFO: `user_request`/`agent_response`; EM: `em_user_request_memory_dev`). Set via `REDIS_CHANNEL_`* env vars.
3. **Engine not consuming** — check `kubectl logs deploy/zora-ai-engine` for subscription errors or LLM failures.

### `openai.AuthenticationError: 401`

`AZURE_LLM_API_KEY` is empty or wrong in Doppler. Check:

```bash
kubectl -n ${NAMESPACE} get secret zora-ai-engine-secrets -o jsonpath='{.data.AZURE_LLM_API_KEY}' | base64 -d | wc -c
```

Must be > 0. If zero, update Doppler `AZURE_LLM_API_KEY` and wait for refresh (5m) or delete the ExternalSecret to force re-sync.

### JFrog Xray blocking image pull (`403 Forbidden — Artifact download request rejected`)

Xray scanning policy is blocking a specific image tag. This is a JFrog Xray policy enforced on the `aiq-docker-release-local` repository. The error looks like:

```
failed to pull image: unexpected status code 403 Forbidden - Server message:
"Artifact download request rejected: aiq-zora-ai-engine/2026.04.05-1544/manifest.json
was not downloaded due to the download blocking policy configured in Xray"
```

**Affected workers (observed during demo-wus bring-up, May 2026):** Payment Advisor and Collection Advisor failed `aiq-docker-release-local` download with Critical CVEs (Python `tarfile`, `libsqlite3-0`). Old pods kept serving traffic; new pods stuck `ImagePullBackOff`. EM2 was unaffected (different base image).

**Fix options (in order of preference):**
1. Use a newer image tag — Xray policies often block older tags with known CVEs. Check what tag is deployed on a healthy recent cluster (`kubectl get deployment -n zora-ai-demo -o yaml | grep image:`).
2. Upgrade the worker's Docker base image (e.g. bump from old Python slim to a recent Debian/Ubuntu base) and rebuild — the Xray scan re-runs on push.
3. Request CloudOps to whitelist the specific tag in Xray policy (last resort — does not fix the underlying CVE).

### `uuid-ossp` extension missing / agent-skills migration fails

`zora_agent_skills_user` needs `CREATE ON DATABASE skill_storage`. The init script grants this, but if it was skipped, run:

```sql
GRANT CREATE ON DATABASE skill_storage TO zora_agent_skills_user;
```

### Pod Pending or OOMKilled (any app)

Cluster doesn't have enough memory/CPU to schedule the pod, OR the pod exceeded its memory limit at runtime. Applies to every app, not just RBAC. Options:

1. **Reduce other apps' `resources.requests`** to free up room — check actual usage with `kubectl top pods -n ${NAMESPACE}` and set requests to ~2x observed steady-state.
2. **Add nodes** to the cluster (if you control it).
3. **Raise the app's memory limit** if it's genuinely OOMing under real load (not just over-provisioned requests).

> **RBAC chart quirk:** `zora-ai-comserv-rbac-app/templates/deployment.yaml` hardcodes `requests.memory: 8Gi` / `limits.memory: 16Gi`. It does NOT read from values. If RBAC pods won't fit, reduce OTHER apps' requests — don't edit the chart (it's copied from the upstream `comserv-rbac` repo).

---

## Related Runbooks

- [rbac-user-role-assignment.md](rbac-user-role-assignment.md) — assigning roles to users
- [update-loadbalancer-dns.md](update-loadbalancer-dns.md) — Postgres/Redis LoadBalancer IP + Azure DNS (Azure only)
- [postgres-restore.md](postgres-restore.md) — restoring database from backup

## Reference

- **PR example:** [#172 — Add CFO platform deployment to AWS DEV Advise](https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment/pull/172)
- **Azure AD app self-service:** [https://appreg.iam.deloitteresources.com/appAuthentication/12ccfc85-5a4c-4172-9f39-9d0cafe8d3f9](https://appreg.iam.deloitteresources.com/appAuthentication/12ccfc85-5a4c-4172-9f39-9d0cafe8d3f9) (internal Deloitte network required)
- **CloudOps:** for ArgoCD issues, VPN, cluster access, and Azure AD fallback
- **Confluence:** [Environments - Technical Specifications](https://confluence.tools.deloitteinnovation.us/pages/viewpage.action?pageId=424053106)

