# Restore customer_data Database in Colgate (ArgoCD Method)

This runbook describes how to restore the `customer_data` database in the Colgate environment using ArgoCD when you don't have kubectl access.

## Problem

Frontend and engine are reporting: `"error": "Database query failed: (psycopg2.errors.UndefinedTable) relation "cfo_data.world_flash_report_display" does not exist"`

This indicates the `customer_data` database is missing tables that should exist.

## Solution

Restore the `customer_data` database from the latest automated backup using a one-shot Kubernetes Job deployed via ArgoCD.

## Prerequisites

1. **Confirm backup exists:**
   - The `zora-ai-postgres-backup` CronJob runs daily at 02:00 UTC in Colgate
   - Backups are stored in the `zora-ai-postgres-backup` PVC
   - Files are named `customer_data_YYYYMMDD_HHMMSS.dump`

2. **Access required:**
   - ArgoCD UI access to Colgate cluster
   - Permission to create/sync ArgoCD Applications
   - Ability to scale down deployments (via ArgoCD or CloudOps)

3. **Coordination:**
   - Notify users that customer-data-server and engine will be down during restore
   - Estimated downtime: 5-15 minutes depending on database size

## Step 1: Scale Down Affected Applications

**CRITICAL:** Scale down apps before restoring to prevent connection conflicts.

### Option A: Via ArgoCD UI

1. Navigate to ArgoCD Colgate cluster
2. Find these applications:
   - `zora-ai-customer-data-server`
   - `zora-ai-engine`
   - `zora-ai-backend` (if it uses customer_data)
   - `zora-ai-frontend` (optional but recommended)
3. For each app:
   - Click APP DETAILS → PARAMETERS
   - Find `replicaCount` parameter
   - Edit and set to `0`
   - Save and sync

### Option B: Via Git Commit

1. Edit these files in the deployment repo:
   - `kubernetes/azure/colgate/values-zora-ai-customer-data-server.yaml`
   - `kubernetes/azure/colgate/values-zora-ai-engine.yaml`
2. Set `replicaCount: 0` in each file
3. Commit and push to `main` branch
4. Wait for ArgoCD to sync (or trigger manual sync)

### Option C: Request CloudOps Assistance

If you can't scale down via ArgoCD:
```bash
# Ask CloudOps to run this (requires kubectl access):
kubectl scale deployment zora-ai-customer-data-server --replicas=0 -n zora-ai-colgate
kubectl scale deployment zora-ai-engine --replicas=0 -n zora-ai-colgate
kubectl scale deployment zora-ai-backend --replicas=0 -n zora-ai-colgate
kubectl scale deployment zora-ai-frontend --replicas=0 -n zora-ai-colgate
```

### Verify Scale Down

Wait until all pods are terminated. In ArgoCD UI:
- Go to each application → Resource Tree
- Confirm no pods are running (or ask CloudOps to verify)

## Step 2: Deploy the Restore Job via ArgoCD

1. **Commit the restore manifests** (if not already committed):
   ```bash
   cd aiq-zora-ai-deployment
   git add argocd/colgate/postgres-restore-customer-data.yaml
   git add kubernetes/azure/colgate/values-zora-ai-postgres-restore-customer-data.yaml
   git commit -m "feat(colgate): add postgres restore job for customer_data"
   git push origin main
   ```

2. **Create the ArgoCD Application:**
   - Navigate to ArgoCD UI → Colgate cluster
   - Click **+ NEW APP**
   - Click **EDIT AS YAML**
   - Paste contents from `argocd/colgate/postgres-restore-customer-data.yaml`
   - Click **SAVE** → **CREATE**

3. **Trigger the sync:**
   - Click **SYNC** on the new application
   - Review the resources that will be created (Job, ConfigMap)
   - Click **SYNCHRONIZE**

## Step 3: Monitor the Restore Job

### Via ArgoCD UI

1. Open the `zora-ai-postgres-restore-customer-data` application
2. View the Job resource in the Resource Tree
3. Click the Job → View logs
4. Monitor the restore progress in real-time

### Key Log Messages to Watch For

**Success indicators:**
```
--- Finding latest backup for customer_data ...
    Found: /backups/customer_data_YYYYMMDD_HHMMSS.dump (XXX MB)
--- Creating pre-restore snapshot ...
    OK: Pre-restore snapshot saved
--- Dropping database customer_data ...
    OK: Database dropped
--- Recreating database customer_data ...
    OK: Database created
--- Restoring from /backups/customer_data_YYYYMMDD_HHMMSS.dump ...
    OK: Restore completed successfully
--- Checking for missing table: cfo_data.world_flash_report_display ...
    ✓ SUCCESS: Table cfo_data.world_flash_report_display exists
=== Restore completed successfully ===
```

**Expected warnings (can be ignored):**
```
WARNING: role "some_user" does not exist
```
These are normal when using `--no-owner` flag.

**Failure indicators:**
```
ERROR: No backup files found for customer_data
ERROR: pg_restore exited with code X
✗ ERROR: Table cfo_data.world_flash_report_display still missing after restore!
```

## Step 4: Verify the Restore

### Check Job Status in ArgoCD

- Job status should show "Completed" (green checkmark)
- If "Failed" (red X), check logs for errors

### Request Verification from Someone with kubectl Access

Ask CloudOps or a team member with kubectl to run:
```bash
# Connect to postgres and verify table exists
kubectl exec -it zora-ai-postgres2-0 -n zora-ai-colgate -- \
  psql -U postgres -d customer_data -c \
  "SELECT COUNT(*) FROM cfo_data.world_flash_report_display;"
```

Expected: Should return a row count (not an error).

## Step 5: Scale Up Applications

Reverse the scale-down from Step 1.

### Option A: Via ArgoCD UI

For each app scaled down earlier:
1. APP DETAILS → PARAMETERS
2. Find `replicaCount` parameter
3. Edit and set back to original value (usually `1` or `2`)
4. Save and sync

### Option B: Via Git Commit

1. Edit the values files modified in Step 1
2. Restore `replicaCount` to original values
3. Commit and push
4. Wait for ArgoCD sync

### Option C: Request CloudOps Assistance

```bash
kubectl scale deployment zora-ai-customer-data-server --replicas=1 -n zora-ai-colgate
kubectl scale deployment zora-ai-engine --replicas=1 -n zora-ai-colgate
kubectl scale deployment zora-ai-backend --replicas=1 -n zora-ai-colgate
kubectl scale deployment zora-ai-frontend --replicas=1 -n zora-ai-colgate
```

## Step 6: Test the Applications

1. Wait for all pods to reach "Running" state (check ArgoCD UI)
2. Test frontend: Navigate to the application and verify no database errors
3. Test engine: Submit a query that would use `cfo_data.world_flash_report_display`
4. Check application logs for any remaining database errors

## Step 7: Clean Up the Restore Job

Once restore is verified successful:

1. In ArgoCD UI, find `zora-ai-postgres-restore-customer-data` app
2. Click **DELETE**
3. Confirm deletion (this removes the completed Job and ConfigMap)

Alternatively, commit a deletion:
```bash
git rm argocd/colgate/postgres-restore-customer-data.yaml
git commit -m "chore(colgate): remove completed postgres restore job"
git push origin main
```

## Troubleshooting

### Job Never Completes (Stays in "Running" State)

**Cause:** Application pods still connected to database.

**Fix:**
1. Verify all apps are scaled to 0 replicas
2. Delete the failed Job via ArgoCD
3. Wait 2 minutes for connections to close
4. Re-sync the restore job

### Job Fails: "No backup files found"

**Cause:** Backup CronJob hasn't run yet or failed.

**Fix:**
1. Check the `zora-ai-postgres-backup` CronJob status in ArgoCD
2. Look for recent successful job runs
3. If no backups exist, you'll need to:
   - Manually trigger the backup CronJob, OR
   - Restore from an external backup source, OR
   - Re-initialize the database from scratch (data loss)

### Job Fails: "Table still missing after restore"

**Cause:** The backup doesn't contain the missing table (backup was taken when database was already corrupted).

**Fix:**
1. Check older backups by listing files in the PVC:
   - Ask CloudOps to run: `kubectl exec -it <restore-job-pod> -n zora-ai-colgate -- ls -lh /backups/`
2. If older backups exist, modify the restore script to use a specific backup file:
   - Edit `values-zora-ai-postgres-restore-customer-data.yaml`
   - In the script, change `LATEST_BACKUP` line to use a specific file
3. If no good backups exist, you need to source the data from elsewhere:
   - Copy from another environment (dev02, qa)
   - Re-seed from original data source
   - Contact data team for backup

### Job Fails: "Database is being accessed by other users"

**Cause:** Connections still active (apps not fully scaled down).

**Fix:**
1. Verify all pods scaled to 0
2. Job script includes `pg_terminate_backend` but may need manual intervention
3. Ask CloudOps to force-terminate connections:
   ```bash
   kubectl exec -it zora-ai-postgres2-0 -n zora-ai-colgate -- \
     psql -U postgres -c \
     "SELECT pg_terminate_backend(pid) FROM pg_stat_activity WHERE datname = 'customer_data';"
   ```

### Restore Succeeds but Applications Still Show Errors

**Possible causes:**
1. **Wrong database restored:** Verify you restored `customer_data` not another DB
2. **Apps cached old connections:** Restart pods:
   - Scale down to 0, wait 10 seconds, scale back up
3. **Apps pointing to wrong database:** Check connection strings in app configs
4. **Permissions issue:** Restore uses `--no-owner` so ownership may differ
   - Usually not a problem but check app logs for permission errors

### Need to Rollback the Restore

The job creates a pre-restore snapshot: `customer_data_pre_restore_YYYYMMDD_HHMMSS.dump`

To rollback:
1. Follow this same runbook but modify the restore script to use the snapshot file
2. Or ask CloudOps to run the restore manually using the snapshot

## Notes

- **Backup retention:** Backups are kept for 7 days (configurable in backup job)
- **Backup schedule:** Daily at 02:00 UTC
- **Backup location:** PVC `zora-ai-postgres-backup` in `zora-ai-colgate` namespace
- **Safety net:** Job creates a pre-restore snapshot before dropping the database

## Related Documentation

- [postgres-restore.md](postgres-restore.md) - Full restore runbook (requires kubectl)
- [postgres-backup values](../kubernetes/azure/colgate/values-zora-ai-postgres-backup.yaml)
- [postgres2 values](../kubernetes/azure/colgate/values-zora-ai-postgres2.yaml)

## Contact

If this runbook doesn't work or you need assistance:
- **CloudOps POC:** Vikram M G (vimg@deloitte.com) for kubectl access, ArgoCD issues
- **Team:** Zora AI DevOps team for database/restore questions
