# PostgreSQL Restore Runbook

Restore a database from a backup created by the `zora-ai-postgres-backup` CronJob.

## Prerequisites

- `kubectl` access to the target cluster (admin context)
- The backup PVC `zora-ai-postgres-backup` contains `.dump` files
- The `postgres` superuser password (from `zora-ai-postgres-secrets`)

## 1. Identify the backup to restore

List available backups on the PVC:

```bash
CONTEXT="zoraai-dev02-eus2-internal-admin"
NAMESPACE="zora-ai-dev02"

kubectl --context "$CONTEXT" -n "$NAMESPACE" run restore-shell --rm -it \
  --image=busybox --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "restore-shell",
        "image": "busybox",
        "command": ["ls", "-lhS", "/backups/"],
        "volumeMounts": [{"name": "backup-storage", "mountPath": "/backups"}]
      }],
      "volumes": [{
        "name": "backup-storage",
        "persistentVolumeClaim": {"claimName": "zora-ai-postgres-backup"}
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }'
```

Backup files are named `<database>_<YYYYMMDD_HHMMSS>.dump`.
Pick the file you want to restore, e.g. `mydb_20260310_020015.dump`.

## 2. Snapshot the current state (before restoring)

Before overwriting an existing database, create a local backup so you can
roll back if the restore produces unexpected results:

```bash
CONTEXT="zoraai-dev02-eus2-internal-admin"
NAMESPACE="zora-ai-dev02"
TARGET_DB="mydb"                         # <-- change this
PG_IMAGE="artifacts.engineeringplatforms.deloitte.com/aiq-docker-scratch-local/postgres-textsearch:17.7-2026.02.09-1842"

# 2a. Dump current state to the backup PVC as a safety net
kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-pre-snapshot --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-pre-snapshot",
        "image": "'"$PG_IMAGE"'",
        "command": ["sh", "-c",
          "STAMP=$(date +%Y%m%d_%H%M%S); FILE=/backups/'"$TARGET_DB"'_pre_restore_${STAMP}.dump; echo \"Snapshotting '"$TARGET_DB"' -> $FILE ...\"; pg_dump -h zora-ai-postgres2 -p 5432 -U postgres -Fc '"$TARGET_DB"' -f \"$FILE\" && echo \"OK: $(du -h $FILE | cut -f1)\" || { echo 'ERROR: snapshot failed'; exit 1; }"
        ],
        "env": [{
          "name": "PGPASSWORD",
          "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}
        }],
        "volumeMounts": [{"name": "backup-storage", "mountPath": "/backups"}]
      }],
      "volumes": [{
        "name": "backup-storage",
        "persistentVolumeClaim": {"claimName": "zora-ai-postgres-backup"}
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }'

# 2b. Record table/row counts before restore (save output for comparison)
kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-before --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-before",
        "image": "'"$PG_IMAGE"'",
        "command": ["psql", "-h", "zora-ai-postgres2", "-U", "postgres", "-d", "'"$TARGET_DB"'",
                    "-c", "SELECT schemaname, relname AS table, n_live_tup AS row_count FROM pg_stat_user_tables ORDER BY 1, 2;"],
        "env": [{"name": "PGPASSWORD", "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}}]
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }' 
```

> **Tip:** Copy the "before" output and compare it with the "after" output
> from step 5 to confirm the restore changed what you expected.

## 3. Restore a single database

Run a one-off pod with `pg_restore` that mounts the backup PVC and connects
to PostgreSQL as the `postgres` superuser:

```bash
DUMP_FILE="mydb_20260310_020015.dump"   # <-- change this

kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-restore --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-restore",
        "image": "'"$PG_IMAGE"'",
        "command": ["sh", "-c",
          "pg_restore -h zora-ai-postgres2 -p 5432 -U postgres -d '"$TARGET_DB"' --clean --if-exists --no-owner --verbose /backups/'"$DUMP_FILE"' 2>&1; RC=$?; echo EXIT_CODE=$RC; exit $RC"
        ],
        "env": [{
          "name": "PGPASSWORD",
          "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}
        }],
        "volumeMounts": [{"name": "backup-storage", "mountPath": "/backups"}]
      }],
      "volumes": [{
        "name": "backup-storage",
        "persistentVolumeClaim": {"claimName": "zora-ai-postgres-backup"}
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }'
```

### pg_restore flags explained

| Flag | Purpose |
|------|---------|
| `--clean` | DROP objects before recreating them |
| `--if-exists` | Don't error if objects don't exist yet |
| `--no-owner` | Skip original ownership (uses the connecting user) |
| `--verbose` | Print each object as it's restored |

## 4. Restore to a new (empty) database

If you want to restore into a fresh database instead of overwriting:

```bash
# 1. Create the new database first
kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-createdb --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-createdb",
        "image": "'"$PG_IMAGE"'",
        "command": ["psql", "-h", "zora-ai-postgres2", "-U", "postgres",
                    "-c", "CREATE DATABASE mydb_restored;"],
        "env": [{"name": "PGPASSWORD", "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}}]
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }' 

# 2. Restore into it (same command as step 3 but with TARGET_DB=mydb_restored)
TARGET_DB="mydb_restored"
# ... run the pg-restore pod from step 3
```

## 5. Restore all databases

To restore every `.dump` file from a specific timestamp:

```bash
TIMESTAMP="20260310_020015"   # <-- change this

kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-restore-all --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-restore-all",
        "image": "'"$PG_IMAGE"'",
        "command": ["sh", "-c", "FAILED=0; set -- /backups/*_'"$TIMESTAMP"''".dump; [ -f \"$1\" ] || { echo 'No dump files found for timestamp '"$TIMESTAMP"''; exit 1; }; for f in /backups/*_'"$TIMESTAMP"'.dump; do DB=$(basename \"$f\" | sed \"s/_'"$TIMESTAMP"'.dump//\"); echo \"=== Restoring $DB from $f ===\"; pg_restore -h zora-ai-postgres2 -p 5432 -U postgres -d \"$DB\" --clean --if-exists --no-owner \"$f\" || FAILED=$((FAILED+1)); done; echo \"Done. Failures: $FAILED\"; exit $FAILED"],
        "env": [{
          "name": "PGPASSWORD",
          "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}
        }],
        "volumeMounts": [{"name": "backup-storage", "mountPath": "/backups"}]
      }],
      "volumes": [{
        "name": "backup-storage",
        "persistentVolumeClaim": {"claimName": "zora-ai-postgres-backup"}
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }'
```

## 6. Verify the restore

Compare the database state after restore with the "before" snapshot from
step 2b. Use `\dt+ *.*` (not `\dt+`) to list tables across **all schemas** —
many databases have multiple schemas (e.g. `customer_data` has `cfo_data`,
`em_data`, `payment_data_dictionary`):

```bash
kubectl --context "$CONTEXT" -n "$NAMESPACE" run pg-verify --rm -it \
  --image="$PG_IMAGE" --restart=Never \
  --overrides='{
    "spec": {
      "containers": [{
        "name": "pg-verify",
        "image": "'"$PG_IMAGE"'",
        "command": ["psql", "-h", "zora-ai-postgres2", "-U", "postgres", "-d", "'"$TARGET_DB"'",
                    "-c", "\\\\dt+ *.*",
                    "-c", "SELECT schemaname, relname AS table, n_live_tup AS row_count FROM pg_stat_user_tables ORDER BY 1, 2;"],
        "env": [{"name": "PGPASSWORD", "valueFrom": {"secretKeyRef": {"name": "zora-ai-postgres-secrets", "key": "postgres-password"}}}]
      }],
      "imagePullSecrets": [{"name": "jfrog-registry-secret"}]
    }
  }' 
```

Compare the row counts with the step 2b output. Expected outcomes:
- **Restore over same DB:** row counts should match the backup timestamp
  (may differ from "before" if data changed since the backup was taken)
- **Restore to new DB:** row counts should exactly match the source database
  at backup time

## Environment reference

| Environment | Context | Namespace | PG service | PVC |
|-------------|---------|-----------|------------|-----|
| dev02 | `zoraai-dev02-eus2-internal-admin` | `zora-ai-dev02` | `zora-ai-postgres2:5432` | `zora-ai-postgres-backup` |
| dev03 | `zoraai-dev03-eus2-internal-admin` | `zora-ai-dev03` | `zora-ai-postgres2:5432` | `zora-ai-postgres-backup` |
| demo | `zoraai-demo-eus-internal-admin` | `zora-ai-demo` | `zora-ai-postgres2:5432` | `zora-ai-postgres-backup` |
| lab | `zoraai-lab-eus-internal-admin` | `zora-ai-lab` | `zora-ai-postgres2:5432` | `zora-ai-postgres-backup` |
| qa | `zoraai-qa-eus2-internal-admin` | `zora-ai-qa` | `zora-ai-postgres2:5432` | `zora-ai-postgres-backup` |

## Troubleshooting

**"role X does not exist" warnings during restore**
Normal when using `--no-owner`. The restore still succeeds; ownership defaults
to the `postgres` user.

**"database is being accessed by other users"**
Scale down the application deployments that use the database before restoring:
```bash
kubectl --context "$CONTEXT" -n "$NAMESPACE" scale deployment <app> --replicas=0
# ... run restore ...
kubectl --context "$CONTEXT" -n "$NAMESPACE" scale deployment <app> --replicas=1
```

**PVC is ReadWriteOnce and bound to another pod**
The backup PVC uses `ReadWriteOnce`, so only one pod can mount it at a time.
If the CronJob is running, wait for it to finish or delete the running job pod
before starting a restore pod.

**Partial restore (only specific tables)**
Use `pg_restore --list` to generate a TOC, edit it, then restore with `--use-list`:
```bash
# Inside a restore pod:
pg_restore --list /backups/mydb_20260310_020015.dump > /tmp/toc.list
# Edit /tmp/toc.list — remove lines you don't want
pg_restore -h zora-ai-postgres2 -U postgres -d mydb --use-list=/tmp/toc.list /backups/mydb_20260310_020015.dump
```
