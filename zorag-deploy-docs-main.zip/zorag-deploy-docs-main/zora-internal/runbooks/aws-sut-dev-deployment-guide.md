# Zora AI Platform - AWS SUT Dev Environment Deployment Guide

**Document Version:** 1.0  
**Last Updated:** May 2026  
**Target Environment:** AWS SUT Development Cluster

---

## Quick Reference

| Item | Value |
|------|-------|
| **Namespace** | `zora-ai-sut` |
| **AWS Region** | `us-east-1` |
| **Database** | `aurora-zoraaisut-dev.cluster-XXXXXXXXXXX.us-east-1.rds.amazonaws.com` |
| **Repository** | `https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment` |
| **Values Path** | `kubernetes/aws/values/dev/sut/` |
| **ArgoCD Path** | `argocd/aws/dev/sut/` |

---

## Table of Contents

### Phase 1: Setup (Steps 1-3)
| Step | Description | Time |
|------|-------------|------|
| [Step 1](#step-1-prerequisites--cluster-access) | Prerequisites & Cluster Access | 15-30 min |
| [Step 2](#step-2-create-namespace) | Create Namespace | 2 min |
| [Step 3](#step-3-configure-doppler-secrets--azure-ad) | Configure Doppler Secrets & Azure AD | 30-60 min |

### Phase 2: Configuration (Steps 4-7)
| Step | Description | Time |
|------|-------------|------|
| [Step 4](#step-4-prepare-external-secrets-files) | Prepare External Secrets Files | 10 min |
| [Step 5](#step-5-confirm-network-routing-type) | Confirm Network Routing Type | 5 min |
| [Step 6](#step-6-prepare-service-values-files) | Prepare Service Values Files | 30-60 min |
| [Step 7](#step-7-configure-rbac-services) | Configure RBAC Services | 30 min |

### Phase 3: Deployment (Steps 8-10)
| Step | Description | Time |
|------|-------------|------|
| [Step 8](#step-8-prepare-argocd-application-manifests) | Prepare ArgoCD Application Manifests | 20 min |
| [Step 9](#step-9-integrate-github-with-argocd) | Integrate GitHub with ArgoCD | 10 min |
| [Step 10](#step-10-deploy-app-of-apps) | Deploy App-of-Apps | 10 min |

### Phase 4: Verification (Step 11)
| Step | Description | Time |
|------|-------------|------|
| [Step 11](#step-11-verify-deployment) | Verify Deployment | 15 min |

### Appendix
- [A. Architecture Overview](#appendix-a-architecture-overview)
- [B. Service Summary](#appendix-b-service-summary)
- [C. Quick Reference Commands](#appendix-c-quick-reference-commands)

---

# Phase 1: Setup

## Step 1: Prerequisites & Cluster Access

> **Time:** 15-30 minutes

### 1.1 Prerequisites Checklist

Before starting, ensure you have:

| # | Requirement | How to Verify | Status |
|---|-------------|---------------|--------|
| 1 | AWS CLI installed | `aws --version` | ☐ |
| 2 | kubectl installed | `kubectl version --client` | ☐ |
| 3 | Doppler service token | Contact project admin | ☐ |
| 4 | Git repository access | Clone the repo | ☐ |
| 5 | ArgoCD admin access | Login to ArgoCD UI | ☐ |

### 1.2 Configure AWS CLI Access

Contact your CloudOps team to obtain AWS credentials, then configure:

```bash
# Step 1: Configure AWS credentials
aws configure

# Step 2: Update kubeconfig for EKS cluster
aws eks update-kubeconfig --region us-east-1 --name <cluster-name>

# Step 3: Verify cluster access
kubectl cluster-info
kubectl get nodes
```

### 1.3 Verify Cluster Connectivity

```bash
# Confirm you can access the cluster
kubectl get namespaces
```

✅ **Checkpoint:** You should see a list of namespaces in the cluster.

---

## Step 2: Create Namespace

> **Time:** 2 minutes

### 2.1 Create Application Namespace

```bash
kubectl create namespace zora-ai-sut
```

### 2.2 Verify Namespace

```bash
kubectl get namespace zora-ai-sut
```

✅ **Checkpoint:** Namespace `zora-ai-sut` should exist with status `Active`.

---

## Step 3: Configure Doppler Secrets & Azure AD

> **Time:** 30-60 minutes

### 3.1 Required Doppler Keys

Configure these **6 keys** in your Doppler project **before deployment**:

| # | Doppler Key | Description | How to Obtain |
|---|-------------|-------------|---------------|
| 1 | `JFROG_DOCKERCONFIGJSON` | Base64-encoded Docker registry credentials | JFrog Artifactory → User Profile → Generate Token |
| 2 | `DB_PASSWORD_POSTGRES` | PostgreSQL admin/service password | Generate strong password (20+ chars) |
| 3 | `DB_PASSWORD_POSTGRES_READ` | PostgreSQL read-only password | Generate strong password (20+ chars) |
| 4 | `REDIS_PASSWORD` | Redis authentication password | Generate strong password (20+ chars) |
| 5 | `AZURE_LLM_API_KEY` | Azure OpenAI or LiteLLM API key | Azure Portal → Azure OpenAI → Keys |
| 6 | `OIDC_CLIENT_SECRET` | Azure AD client secret for RBAC | Azure Portal → App Registrations → Certificates & Secrets |

### 3.2 Create Doppler Token Secret in Kubernetes

```bash
kubectl create secret generic doppler-token-secret-sut-backend \
  --namespace zora-ai-sut \
  --from-literal=dopplerToken=<YOUR_DOPPLER_SERVICE_TOKEN>
```

### 3.3 How Doppler Keys Map to Kubernetes Secrets

| Kubernetes Secret | Doppler Key(s) | Used By |
|-------------------|----------------|---------|
| `jfrog-registry-secret` | `JFROG_DOCKERCONFIGJSON` | All services (image pull) |
| `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES`, `DB_PASSWORD_POSTGRES_READ` | Backend, Engine, Config Server, RBAC |
| `zora-ai-redis` | `REDIS_PASSWORD` | Engine, Backend |
| `zora-ai-engine-secrets` | `AZURE_LLM_API_KEY` | Engine |
| `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | RBAC Backend |

✅ **Checkpoint:** All 6 Doppler keys are configured in the Doppler dashboard.

### 3.4 Configure Azure AD App Registration (OIDC)

> **⚠️ Important:** This step must be completed **before deployment**. The OIDC callback URLs must be registered in Azure AD for SSO authentication to work.

#### 🔑 Azure AD App Registration Setup

> **Contact:** For Azure AD configuration assistance, reach out to **Michel from the iReal team**.

For SSO to work, you must register **both callback URLs** in your Azure AD App Registration:

| Callback URL | Purpose |
|--------------|---------|
| `https://zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/rbac/authentication/login/callback` | Zora Frontend SSO redirect |
| `https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/api/authentication/login/callback` | RBAC Backend direct login |

#### Steps to Configure in Azure Portal

1. Go to **Azure Portal** → **App Registrations** → **Your App**
2. Navigate to **Authentication** → **Platform configurations**
3. Under **Web** → **Redirect URIs**, add both callback URLs above
4. Click **Save**

#### Example URLs

| URL Type | Example |
|----------|---------|
| Zora Frontend | `zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| RBAC Admin UI | `rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |

> **⚠️ Important:** The callback URLs must **exactly match** what you configured in `values-zora-ai-rbac-backend.yaml` and `values-zora-ai-rbac-backend-ui.yaml` for SSO to work properly.

✅ **Checkpoint:** Both callback URLs are registered in Azure AD App Registration.

---

# Phase 2: Configuration

## Step 4: Prepare External Secrets Files

> **Time:** 10 minutes

### 4.1 File Location

```
kubernetes/aws/values/dev/sut/external-secrets-v1/
├── cluster-secret-store.yaml     # Connects to Doppler
└── zora-ai-external-secrets.yaml # Defines secrets to sync
```

### 4.2 Files to Review/Update

| File | What to Check |
|------|---------------|
| `cluster-secret-store.yaml` | Verify `namespace` matches where External Secrets Operator runs |
| `zora-ai-external-secrets.yaml` | Verify all Doppler key names match your configuration |

### 4.3 Verify External Secrets Configuration

The `zora-ai-external-secrets.yaml` should contain these 5 ExternalSecret resources:

| # | ExternalSecret Name | Syncs From Doppler | Creates K8s Secret |
|---|---------------------|--------------------|--------------------|
| 1 | `jfrog-registry-secret` | `JFROG_DOCKERCONFIGJSON` | `jfrog-registry-secret` |
| 2 | `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES`, `DB_PASSWORD_POSTGRES_READ` | `zora-ai-postgres-secrets` |
| 3 | `zora-ai-redis` | `REDIS_PASSWORD` | `zora-ai-redis` |
| 4 | `zora-ai-engine-secrets` | `AZURE_LLM_API_KEY` | `zora-ai-engine-secrets` |
| 5 | `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | `zora-ai-rbac-secrets` |

✅ **Checkpoint:** External secrets files are configured correctly.

---

## Step 5: Confirm Network Routing Type

> **Time:** 5 minutes

### 5.1 AWS SUT Uses HTTPRoute

| Parameter | Value |
|-----------|-------|
| Routing Type | **HTTPRoute** (Gateway API) |
| Gateway Name | `apps-gateway-internal` |
| Gateway Namespace | `ska-system` |
| Section Name | `apps-gateway-internal-https` |

### 5.2 HTTPRoute Configuration

In all values files, set:

```yaml
# Disable nginx Ingress
ingress:
  enabled: false

# Enable HTTPRoute
httpRoute:
  enabled: true
  host: your-service.dev.sut.zoraai.eng.deloitte.com
  gatewayName: apps-gateway-internal
  gatewayNamespace: ska-system
  sectionName: apps-gateway-internal-https
```

✅ **Checkpoint:** Confirmed HTTPRoute is the routing method for AWS SUT.

---

## Step 6: Prepare Service Values Files

> **Time:** 30-60 minutes

### 6.1 Values Files Location

```
kubernetes/aws/values/dev/sut/
```

### 6.2 All Values Files to Configure

| # | Service | Values File | Chart |
|---|---------|-------------|-------|
| 1 | Backend | `values-zora-ai-sut-backend.yaml` | `aiq-service` |
| 2 | Frontend | `values-zora-ai-sut-frontend.yaml` | `aiq-service` |
| 3 | Engine | `values-zora-ai-sut-engine.yaml` | `aiq-service` |
| 4 | Config Server | `values-zora-ai-configuration-server.yaml` | Universal Chart |
| 5 | Customer Data | `values-zora-ai-customer-data-server.yaml` | `aiq-service` |
| 6 | Redis | `values-zora-ai-redis.yaml` | `zora-ai-redis` |
| 7 | Milvus | `values-zora-ai-sut-milvus.yaml` | `zora-ai-milvus` |
| 8 | Agent Skills | `values-zora-ai-sut-agentskills.yaml` | `zora-ai-jobs` |
| 9 | Document Scraping | `values-zora-ai-sut-document-scrapping.yaml` | `aiq-service` |

### 6.3 Common Parameters to Update

For **each values file**, update these parameters:

| Parameter | Description | Example Value |
|-----------|-------------|---------------|
| `image.tag` | Service version | `2026.05.15-1149` |
| `httpRoute.host` | Service DNS name | `zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| `resources.limits` | CPU/Memory limits | `cpu: "4"`, `memory: 32Gi` |
| `resources.requests` | CPU/Memory requests | `cpu: "2"`, `memory: 10Gi` |

### 6.4 Environment-Specific Values

| Parameter | AWS SUT Dev Value |
|-----------|-------------------|
| Database Host | `aurora-zoraaisut-dev.cluster-c4fmqg84uuws.us-east-1.rds.amazonaws.com` |
| Database Port | `5432` |
| Database Username | `svc_user` |
| Redis Host | `zora-ai-redis-master` |
| Redis Port | `6379` |
| LLM Gateway | `https://llmgateway-litellm.dev.sut.zoraai.eng.deloitte.com` |

✅ **Checkpoint:** All 9 values files are configured with correct hostnames and database endpoints.

---

## Step 7: Configure RBAC Services

> **Time:** 30 minutes

### 7.1 RBAC Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    RBAC Authentication Flow                      │
│                                                                   │
│  User → RBAC Frontend → API Proxy (/api/*) → RBAC Backend       │
│                              │                     │              │
│                              │                     ▼              │
│                              │              Azure AD (OIDC)       │
│                              │                     │              │
│                              ▼                     ▼              │
│                         PostgreSQL (rbac_db)                      │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 RBAC Configuration Files Summary

All RBAC files are located in: `kubernetes/aws/values/dev/sut/`

| # | Component | File Path | Chart |
|---|-----------|-----------|-------|
| 1 | RBAC Backend | `values-zora-ai-rbac-backend.yaml` | `zora-ai-comserv-rbac-app` |
| 2 | RBAC Backend UI | `values-zora-ai-rbac-backend-ui.yaml` | `zora-ai-comserv-rbac-app` |
| 3 | RBAC Frontend | `values-zora-ai-rbac-frontend.yaml` | `aiq-service` |
| 4 | RBAC API Proxy | `rbac-api-proxy/ingress.yaml` | Raw HTTPRoute |

### 7.3 RBAC Backend Configuration

📁 **File:** `kubernetes/aws/values/dev/sut/values-zora-ai-rbac-backend.yaml`

**Purpose:** API server for main Zora app SSO

Update with these parameters:

```yaml
deployment:
  env:
    # OIDC Endpoints (update with your URLs)
    ISSUER: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    JWT_ISSUER: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    LOCALHOST_ENDPOINT: https://zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/sso/callback
    ALLOWED_AUDIENCES: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    
    # Azure AD Configuration (get from Azure Portal)
    OIDC_ISSUER: "https://login.microsoftonline.com/<TENANT_ID>/v2.0"
    OIDC_AUTHURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/authorize"
    OIDC_TOKENURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/token"
    OIDC_USERINFOURL: "https://graph.microsoft.com/oidc/userinfo"
    OIDC_CLIENTID: "<YOUR_AZURE_AD_APP_CLIENT_ID>"
    OIDC_CALLBACKURL: "https://zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/rbac/authentication/login/callback"
    OIDC_SCOPE: "openid profile email"
    
    # Database
    DB_HOST: aurora-zoraaisut-dev.cluster-c4fmqg84uuws.us-east-1.rds.amazonaws.com
    DB_PORT: "5432"
    DB_USER: "svc_user"
    DB_DATABASE: rbac_db
```

### 7.4 RBAC Backend UI Configuration

📁 **File:** `kubernetes/aws/values/dev/sut/values-zora-ai-rbac-backend-ui.yaml`

**Purpose:** API server for RBAC admin UI SSO

> **Note:** This is a second RBAC backend instance dedicated to the RBAC UI. The key difference is `LOCALHOST_ENDPOINT` and `OIDC_CALLBACKURL` point to the RBAC UI domain, so after SSO the user lands on the RBAC UI (not the main Zora app). Both instances share the same database.

```yaml
deployment:
  env:
    # OIDC Endpoints (RBAC UI specific - different from main backend)
    ISSUER: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    JWT_ISSUER: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    LOCALHOST_ENDPOINT: https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/sso/callback  # Points to RBAC UI
    ALLOWED_AUDIENCES: https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
    
    # Azure AD Configuration (same as main backend)
    OIDC_ISSUER: "https://login.microsoftonline.com/<TENANT_ID>/v2.0"
    OIDC_AUTHURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/authorize"
    OIDC_TOKENURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/token"
    OIDC_USERINFOURL: "https://graph.microsoft.com/oidc/userinfo"
    OIDC_CLIENTID: "<YOUR_AZURE_AD_APP_CLIENT_ID>"
    OIDC_CALLBACKURL: "https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/api/authentication/login/callback"  # RBAC UI callback
    OIDC_SCOPE: "openid profile email"
    
    # Database (shared with main RBAC backend)
    DB_HOST: aurora-zoraaisut-dev.cluster-c4fmqg84uuws.us-east-1.rds.amazonaws.com
    DB_PORT: "5432"
    DB_USER: "svc_user"
    DB_DATABASE: rbac_db
    
    # Authentication Settings
    LOGIN_ENABLED: "true"
    ALLOW_AUTO_USER_CREATION: "true"
    DEFAULT_ROLE_KEY: RBAC-ROOT
    INTERNAL_DOMAIN: "deloitte.com"
```

#### Key Differences: RBAC Backend vs RBAC Backend UI

| Parameter | RBAC Backend (Main App) | RBAC Backend UI (RBAC Admin) |
|-----------|-------------------------|------------------------------|
| `LOCALHOST_ENDPOINT` | `https://zora-sut-dev.../sso/callback` | `https://rbac-zora-sut-dev.../sso/callback` |
| `OIDC_CALLBACKURL` | `https://zora-sut-dev.../rbac/authentication/login/callback` | `https://rbac-zora-sut-dev.../api/authentication/login/callback` |
| **Purpose** | SSO redirects to main Zora app | SSO redirects to RBAC admin UI |

### 7.5 RBAC Frontend Configuration

📁 **File:** `kubernetes/aws/values/dev/sut/values-zora-ai-rbac-frontend.yaml`

**Purpose:** React RBAC admin interface

Update with these parameters:

```yaml
env:
  REACT_APP_API_URL: https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com/api
  REACT_CC_PROD_DOMAIN: rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com

httpRoute:
  enabled: true
  host: rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com
```

### 7.6 RBAC API Proxy Configuration

📁 **File:** `kubernetes/aws/values/dev/sut/rbac-api-proxy/ingress.yaml`

**Purpose:** Routes `/api/*` requests to RBAC Backend UI for cookie handling

Update with these parameters:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: zora-ai-rbac-api-proxy
  namespace: zora-ai-sut
spec:
  hostnames:
  - rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com  # Update hostname
  parentRefs:
  - name: apps-gateway-internal
    namespace: ska-system
    sectionName: apps-gateway-internal-https
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /api
    backendRefs:
    - name: zora-ai-rbac-app-ui
      port: 80
```

### 7.7 RBAC Secrets Required

| Secret | Doppler Key | Purpose |
|--------|-------------|---------|
| `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | Azure AD authentication |
| `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES` | Database access |

✅ **Checkpoint:** All 4 RBAC configuration files are updated (Backend, Backend UI, Frontend, API Proxy).

---

# Phase 3: Deployment

## Step 8: Prepare ArgoCD Application Manifests

> **Time:** 20 minutes

### 8.1 ArgoCD Apps Location

```
argocd/aws/dev/sut/
```

### 8.2 All ArgoCD Application Files

| # | ArgoCD App File | Deploys | Chart |
|---|-----------------|---------|-------|
| 1 | `external-secrets.yaml` | External Secrets | Raw manifests |
| 2 | `sut-backend.yaml` | Backend service | `aiq-service` |
| 3 | `sut-frontend.yaml` | Frontend service | `aiq-service` |
| 4 | `sut-engine.yaml` | AI Engine | `aiq-service` |
| 5 | `sut-configuration-server.yaml` | Config Server | Universal Chart |
| 6 | `sut-customer-data-server.yaml` | Customer Data | `aiq-service` |
| 7 | `sut-rbac-backend.yaml` | RBAC Backend | `zora-ai-comserv-rbac-app` |
| 8 | `sut-rbac-backend-ui.yaml` | RBAC Backend UI | `zora-ai-comserv-rbac-app` |
| 9 | `sut-rbac-frontend.yaml` | RBAC Frontend | `aiq-service` |
| 10 | `sut-rbac-api-proxy.yaml` | RBAC API Proxy | Raw HTTPRoute |
| 11 | `sut-redis.yaml` | Redis | `zora-ai-redis` |
| 12 | `sut-milvus.yaml` | Milvus | `zora-ai-milvus` |
| 13 | `sut-agentskills.yaml` | Agent Skills Job | `zora-ai-jobs` |
| 14 | `sut-document-scrapping.yaml` | Doc Scraping | `aiq-service` |
| 15 | `sut-dw-agent-engine.yaml` | DW Agent Engine | `aiq-service` |
| 16 | `langfuse.yaml` | Langfuse | Custom |

### 8.3 ArgoCD Application Structure

Each ArgoCD app manifest should have:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-sut-<service>      # App name
  namespace: argocd                 # Always argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/charts/<chart-name>
    helm:
      valueFiles:
        - ../../aws/values/dev/sut/<values-file>.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-sut          # Target namespace
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### 8.4 Sync Policy Explained

| Setting | Value | Description |
|---------|-------|-------------|
| `automated.prune` | `false` | Don't auto-delete resources not in Git |
| `automated.selfHeal` | `true` | Auto-fix drift from desired state |
| `CreateNamespace` | `true` | Create namespace if missing |

✅ **Checkpoint:** All 16 ArgoCD application files are configured.

---

## Step 9: Integrate GitHub with ArgoCD

> **Time:** 10 minutes

### 9.1 Repository Information

| Parameter | Value |
|-----------|-------|
| Repository URL | `https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment` |
| Target Branch | `main` |
| Authentication | GitHub App or SSH Key (configured by platform team) |

### 9.2 Repository Structure

```
aiq-zora-ai-deployment/
├── argocd/
│   └── aws/dev/sut/           # ArgoCD Application manifests
├── kubernetes/
│   ├── charts/                 # Helm charts (shared)
│   └── aws/values/dev/sut/    # Environment-specific values
```

### 9.3 Verify GitHub Connection in ArgoCD

1. Login to ArgoCD UI
2. Go to **Settings** → **Repositories**
3. Verify `aiq-zora-ai-deployment` repository is connected
4. Status should show **Successful**

✅ **Checkpoint:** GitHub repository is connected to ArgoCD.

---

## Step 10: Deploy App-of-Apps

> **Time:** 10 minutes

### 10.1 What is App-of-Apps?

App-of-Apps is an ArgoCD pattern where **one parent Application manages multiple child Applications**. This allows deploying the entire platform with a single command.

### 10.2 Parent Application Manifest

Location: `argocd/app-of-apps/aws/dev/application.yaml`

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-app-of-apps
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    path: argocd/aws/dev/sut    # Points to folder with all app manifests
    targetRevision: main
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-sut
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
```

### 10.3 Deploy the App-of-Apps

```bash
kubectl apply -f argocd/app-of-apps/aws/dev/application.yaml
```

### 10.4 What Happens After Deployment

1. ArgoCD creates the parent `zora-ai-app-of-apps` Application
2. Parent Application discovers all child Application manifests in `argocd/aws/dev/sut/`
3. ArgoCD creates all 16 child Applications
4. Each child Application syncs its Helm chart with values
5. Kubernetes resources are created in `zora-ai-sut` namespace

✅ **Checkpoint:** App-of-Apps is deployed to ArgoCD.

---

# Phase 4: Verification

## Step 11: Verify Deployment

> **Time:** 15 minutes

### 11.1 Check ArgoCD Status

In ArgoCD UI:

| Application | Expected Status |
|-------------|-----------------|
| `zora-ai-app-of-apps` | ✅ Synced, ✅ Healthy |
| All child applications | ✅ Synced, ✅ Healthy |

### 11.2 Check Kubernetes Pods

```bash
kubectl get pods -n zora-ai-sut
```

**Expected output:**
```
NAME                                            READY   STATUS    RESTARTS   AGE
zora-ai-sut-backend-xxxxx                       1/1     Running   0          5m
zora-ai-sut-frontend-xxxxx                      1/1     Running   0          5m
zora-ai-sut-engine-xxxxx                        1/1     Running   0          5m
zora-ai-configuration-server-xxxxx              1/1     Running   0          5m
zora-ai-customer-data-server-xxxxx              1/1     Running   0          5m
zora-ai-rbac-app-xxxxx                          1/1     Running   0          5m
zora-ai-rbac-app-ui-xxxxx                       1/1     Running   0          5m
zora-ai-rbac-ui-xxxxx                           1/1     Running   0          5m
zora-ai-redis-master-0                          1/1     Running   0          5m
```

### 11.3 Check External Secrets

```bash
kubectl get externalsecrets -n zora-ai-sut
```

All secrets should show `SecretSynced` status.

### 11.4 Access Application URLs

| Service | URL |
|---------|-----|
| **Frontend** | `https://zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| **Backend API** | `https://zora-sut-dev-backend.dev.sut.zoraai.eng.deloitte.com` |
| **RBAC Admin** | `https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| **Config Server** | `https://zora-ai-dev-configuration-server.dev.sut.zoraai.eng.deloitte.com` |

✅ **Deployment Complete!**

---

# Appendix A: Architecture Overview

## How It Works

```
┌──────────────────────────────────────────────────────────────────────┐
│                        GitOps Deployment Flow                         │
└──────────────────────────────────────────────────────────────────────┘

    ┌─────────┐         ┌─────────┐         ┌─────────────┐
    │ GitHub  │────────▶│ ArgoCD  │────────▶│ Kubernetes  │
    │  Repo   │         │ Server  │         │   Cluster   │
    └─────────┘         └─────────┘         └─────────────┘
         │                   │                     │
         │  1. Push code     │  2. Detect change   │  3. Apply manifests
         │                   │                     │
         ▼                   ▼                     ▼
    ┌─────────┐         ┌─────────┐         ┌─────────────┐
    │ Values  │         │  Sync   │         │   Running   │
    │  Files  │         │ Compare │         │    Pods     │
    └─────────┘         └─────────┘         └─────────────┘
```

## Component Interaction

1. **External Secrets Operator** → Syncs secrets from Doppler to Kubernetes
2. **ArgoCD** → Monitors Git repository for changes
3. **Helm Charts** → Rendered with environment-specific values
4. **HTTPRoute** → Exposes services via Gateway API
5. **Services** → Connect to Aurora PostgreSQL and Redis

## Self-Healing Behavior

- ArgoCD continuously monitors cluster state
- Manual changes are automatically reverted to match Git
- New commits trigger automatic deployments
- Failed deployments are rolled back automatically

---

# Appendix B: Service Summary

## All Deployed Services

| # | Service | Chart | Description |
|---|---------|-------|-------------|
| 1 | Backend | `aiq-service` | Core API services |
| 2 | Frontend | `aiq-service` | Web UI application |
| 3 | Engine | `aiq-service` | AI/ML processing engine |
| 4 | Config Server | Universal Chart | Configuration management |
| 5 | Customer Data | `aiq-service` | Customer data APIs |
| 6 | RBAC Backend | `zora-ai-comserv-rbac-app` | Authentication API (OIDC) |
| 7 | RBAC Backend UI | `zora-ai-comserv-rbac-app` | RBAC backend component |
| 8 | RBAC Frontend | `aiq-service` | RBAC admin interface |
| 9 | RBAC API Proxy | HTTPRoute | Routes /api/* for cookies |
| 10 | Redis | `zora-ai-redis` | In-memory data store |
| 11 | Milvus | `zora-ai-milvus` | Vector database |
| 12 | Agent Skills | `zora-ai-jobs` | Skills initialization job |
| 13 | Document Scraping | `aiq-service` | Document processing |
| 14 | DW Agent Engine | `aiq-service` | Digital Worker agent |
| 15 | Langfuse | Custom | LLM observability |

## DNS Endpoints

| Service | URL |
|---------|-----|
| Frontend | `https://zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| Backend API | `https://zora-sut-dev-backend.dev.sut.zoraai.eng.deloitte.com` |
| RBAC Admin UI | `https://rbac-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| RBAC API | `https://rbac-api-zora-sut-dev.dev.sut.zoraai.eng.deloitte.com` |
| Config Server | `https://zora-ai-dev-configuration-server.dev.sut.zoraai.eng.deloitte.com` |

---

# Appendix C: Quick Reference Commands

```bash
# Check deployment status
kubectl get pods -n zora-ai-sut

# View ArgoCD applications
kubectl get applications -n argocd | grep sut

# Check External Secrets
kubectl get externalsecrets -n zora-ai-sut

# View logs for a service
kubectl logs -f deployment/zora-ai-sut-backend -n zora-ai-sut

# Check service endpoints
kubectl get svc -n zora-ai-sut

# Describe pod for troubleshooting
kubectl describe pod <pod-name> -n zora-ai-sut

# Check HTTPRoutes
kubectl get httproutes -n zora-ai-sut
```

---

## Support

For deployment issues or questions, contact:
- **Platform Team:** Cloud Operations
- **Repository:** [aiq-zora-ai-deployment](https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment)

---

*Document maintained by Zora AI DevOps Team*
