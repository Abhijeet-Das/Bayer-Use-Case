# PostgreSQL Migration Plan: old postgres → postgres2

Migrating apps from the legacy `postgresql-service` (old `zora-ai-postgres` chart) to the new `zora-ai-postgres2` (CloudPirates chart).

## Migration Status (as of 2026-03-11)

| Env | Apps on postgres2 | Old postgres | Status |
|-----|-------------------|-------------|--------|
| **dev2** | All 7 apps | replicaCount: 0 | **Migrated** |
| **dev3** | All 7 apps | replicaCount: 0 | **Migrated** |
| **demo** | All 6 apps (no benchmarks) | replicaCount: 0 | **Migrated** |
| **lab** | All 6 apps (no benchmarks) | replicaCount: 0 | **Migrated** |
| **qa** | All 6 apps | replicaCount: 0 | **Migrated** — `zora-ai-postgres2` at `10.185.65.27`, DNS records updated |

---

## Prerequisites

- kubectl access to the target cluster
- VPN connectivity
- Know the old postgres pod name and new postgres2 pod/statefulset name
- Identify all databases to migrate

## Variables (set per environment)

```bash
# Kubectl context
CTX=zoraai-dev03-eus2-internal-admin

# Namespace
NS=zora-ai-dev03

# Old postgres pod (find via: kubectl --context $CTX -n $NS get pods | grep postgres)
OLD_POD=zora-ai-postgres-postgres-c7fdd975c-82g2t

# New postgres2 statefulset pod
NEW_POD=zora-ai-postgres2-0
NEW_CONTAINER=postgres

# Databases to migrate (list all from old postgres)
DATABASES="customer_data customer_data_old rbac_db skill_storage synthetic_data synthetic_data_v3 zora_app zora_config"
```

---

## Step 0 — Pre-migration health check

Before starting the migration, verify the current state of all apps and their database connectivity. This establishes a baseline so pre-existing issues aren't confused with migration problems.

**Check app and pod status:**
```bash
kubectl --context $CTX -n $NS get pods -o wide
```

**Check app logs for DB-related errors:**
```bash
for app in backend configuration-server customer-data-server engine benchmarks; do
  echo "=== zora-ai-$app ==="
  kubectl --context $CTX -n $NS logs deploy/zora-ai-$app --tail=100 2>/dev/null \
    | grep -i -E "error|exception|connection refused|timeout|could not connect" \
    || echo "  (no DB errors)"
  echo
done

for app in zora-ai-rbac-app zora-ai-rbac-app-ui; do
  echo "=== $app ==="
  kubectl --context $CTX -n $NS logs deploy/$app --tail=100 2>/dev/null \
    | grep -i -E "error|exception|connection refused|timeout|could not connect" \
    || echo "  (no DB errors)"
  echo
done
```

**Check old postgres is healthy and list databases:**
```bash
kubectl --context $CTX -n $NS exec $OLD_POD -- \
  psql -U postgres -c "SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname;"
```

**Record any pre-existing issues** (e.g., asyncpg event-loop errors in customer-data-server) so they aren't attributed to the migration later.

---

## Step 1 — Scale apps to 0

Edit `replicaCount: 0` in all postgres-dependent app values files:

**Apps (7 in dev3):**
- `values-zora-ai-backend.yaml`
- `values-zora-ai-configuration-server.yaml`
- `values-zora-ai-customer-data-server.yaml`
- `values-zora-ai-engine.yaml`
- `values-zora-ai-benchmarks.yaml`
- `values-zora-ai-rbac-backend.yaml`
- `values-zora-ai-rbac-backend-ui.yaml`

Commit & push. Wait for ArgoCD to sync (pods should go to 0/0).

**Verify:**
```bash
kubectl --context $CTX -n $NS get pods | grep -v postgres | grep -v redis
```

> **Note:** If ArgoCD shows `Synced` but pods don't scale down, force sync:
> ```bash
> kubectl --context $CTX -n argocd patch application <app-name> \
>   -p '{"operation":{"initiatedBy":{"username":"admin"},"sync":{}}}' --type merge
> ```

## Step 2 — Dump globals + all databases from old postgres

```bash
# Dump global objects (roles, tablespaces)
kubectl --context $CTX -n $NS exec $OLD_POD -- \
  pg_dumpall -U postgres --globals-only --clean > globals.sql

# Dump each database in custom format
for db in $DATABASES; do
  echo "Dumping $db..."
  kubectl --context $CTX -n $NS exec $OLD_POD -- \
    pg_dump -U postgres -Fc "$db" > "${db}.dump"
  echo "Done: $(ls -lh ${db}.dump | awk '{print $5}')"
done
```

## Step 3 — Restore to postgres2

```bash
# Restore globals first (roles, passwords)
kubectl --context $CTX exec -i -n $NS $NEW_POD -c $NEW_CONTAINER -- \
  psql -U postgres < globals.sql

# Restore each database
for db in $DATABASES; do
  echo "Restoring $db..."
  kubectl --context $CTX exec -i -n $NS $NEW_POD -c $NEW_CONTAINER -- \
    pg_restore -U postgres -d postgres --clean --if-exists --create < "${db}.dump"
  echo "Done: $db"
done
```

> **Note:** The `--clean --create` flags mean `pg_restore` will **drop and recreate** each database on the destination if it already exists. This ensures a clean, consistent copy of the source data. Any pre-existing data in the destination DB with the same name will be replaced.
>
> `pg_restore` may show warnings about objects that already exist or don't exist to drop — this is normal.

## Step 3.5 — Validate data sync between old and new postgres

After restore, compare both instances to confirm data integrity before switching apps.

**Compare database list:**
```bash
echo "=== OLD postgres ==="
kubectl --context $CTX -n $NS exec $OLD_POD -- \
  psql -U postgres -t -c "SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname;"

echo "=== NEW postgres2 ==="
kubectl --context $CTX -n $NS exec $NEW_POD -c $NEW_CONTAINER -- \
  psql -U postgres -t -c "SELECT datname FROM pg_database WHERE datistemplate = false ORDER BY datname;"
```

**Compare tables and row counts per database:**
```bash
for db in $DATABASES; do
  echo ""
  echo "========== $db =========="

  echo "--- OLD ---"
  kubectl --context $CTX -n $NS exec $OLD_POD -- \
    psql -U postgres -d "$db" -t -c "
      SELECT schemaname || '.' || relname AS table, n_live_tup AS rows
      FROM pg_stat_user_tables
      ORDER BY schemaname, relname;"

  echo "--- NEW ---"
  kubectl --context $CTX -n $NS exec $NEW_POD -c $NEW_CONTAINER -- \
    psql -U postgres -d "$db" -t -c "
      SELECT schemaname || '.' || relname AS table, n_live_tup AS rows
      FROM pg_stat_user_tables
      ORDER BY schemaname, relname;"
done
```

> **Note:** `pg_stat_user_tables.n_live_tup` is an estimate. For exact counts, run `ANALYZE` on both sides first, or use `SELECT count(*) FROM <table>` for critical tables.

**Compare roles:**
```bash
echo "=== OLD roles ==="
kubectl --context $CTX -n $NS exec $OLD_POD -- \
  psql -U postgres -t -c "SELECT rolname FROM pg_roles WHERE rolname NOT LIKE 'pg_%' ORDER BY rolname;"

echo "=== NEW roles ==="
kubectl --context $CTX -n $NS exec $NEW_POD -c $NEW_CONTAINER -- \
  psql -U postgres -t -c "SELECT rolname FROM pg_roles WHERE rolname NOT LIKE 'pg_%' ORDER BY rolname;"
```

**Check Alembic migration versions (if applicable):**
```bash
for db in $DATABASES; do
  echo "=== $db ==="
  kubectl --context $CTX -n $NS exec $NEW_POD -c $NEW_CONTAINER -- \
    psql -U postgres -d "$db" -t -c "SELECT version_num FROM alembic_version;" 2>/dev/null \
    || echo "  (no alembic_version table)"
done
```

**If any discrepancies are found**, investigate before proceeding:
- Missing database → re-run `pg_restore` for that specific DB
- Row count mismatch → likely stale `pg_stat` estimates — run `ANALYZE` and recheck
- Missing roles → re-run globals restore

---

## Step 4 — Switch apps to postgres2 in values files

Replace the old hostname with the new one in all values files:

| Values file | Fields to change |
|---|---|
| `values-zora-ai-backend.yaml` | `RBAC_DATASOURCE_URL`, `DATASOURCE_URL` — change `postgresql-service:5432` → `zora-ai-postgres2:5432` |
| `values-zora-ai-configuration-server.yaml` | `DATASOURCE_URL` — change `postgresql-service:5432` → `zora-ai-postgres2:5432` |
| `values-zora-ai-customer-data-server.yaml` | `DATASOURCE_URL` — change `postgresql-service:5432` → `zora-ai-postgres2:5432` |
| `values-zora-ai-engine.yaml` | `DB_HOST_ZORA_AI_SYNTHETIC_CUSTOMER_DATA_DB`, `DB_HOST_ZORA_AI_CONFIGURATION_DB`, `DB_HOST_ZORA_AI_SKILL_STORAGE_DB` — change `postgresql-service` → `zora-ai-postgres2` |
| `values-zora-ai-benchmarks.yaml` | `DB_HOST` — change `postgresql-service` → `zora-ai-postgres2` |
| `values-zora-ai-rbac-backend.yaml` | `postgresqlHost`, `DB_HOST` — change `postgresql-service` → `zora-ai-postgres2` |
| `values-zora-ai-rbac-backend-ui.yaml` | `postgresqlHost`, `DB_HOST` — change `postgresql-service` → `zora-ai-postgres2` |


## Step 5 — Scale apps back to 1

Edit `replicaCount: 1` in all 7 values files.

Commit & push. Wait for ArgoCD sync.

**Verify pods are running:**
```bash
kubectl --context $CTX -n $NS get pods
```

## Step 6 — Scale old postgres to 0

Edit `values-zora-ai-postgres.yaml`: set `postgres.replicaCount: 0`

Commit & push.

## Step 7 — Verify via logs

```bash
# Check each app for DB connection errors
for app in backend configuration-server customer-data-server engine benchmarks; do
  echo "=== zora-ai-$app ==="
  kubectl --context $CTX -n $NS logs deploy/zora-ai-$app --tail=50 2>/dev/null | grep -i -E "error|exception|connection" || echo "  (no errors)"
done

# RBAC apps
for app in zora-ai-rbac-app zora-ai-rbac-app-ui; do
  echo "=== $app ==="
  kubectl --context $CTX -n $NS logs deploy/$app --tail=50 2>/dev/null | grep -i -E "error|exception|connection" || echo "  (no errors)"
done
```

---

## Step 8 — Pin LoadBalancer IP and update DNS

Follow **[update-loadbalancer-dns.md](update-loadbalancer-dns.md)** to pin `loadBalancerIP` in the `values-zora-ai-postgres2.yaml` values file and update the Azure DNS A records for the environment.

---

## Related Runbooks

- **[update-loadbalancer-dns.md](update-loadbalancer-dns.md)** — Pin `loadBalancerIP` and update Azure DNS A records after migration.

---

## Lessons Learned (dev3 migration)

1. **Alembic revision mismatch:** `customer-data-server` had `alembic_version` revision `005` in the DB but the app image only knew up to `002`. This caused `CrashLoopBackOff` initially but resolved on pod restart.

2. **Pre-existing asyncpg bug:** `customer-data-server` has intermittent `RuntimeError: Event loop is closed` errors from SQLAlchemy's asyncpg pool. This is a pre-existing app bug, not migration-related.

3. **Dump file sizes:** The dumps are small (KB–MB range for dev environments). The entire operation takes ~10 minutes excluding ArgoCD sync wait time.
