# Zora AI Platform - GCP Dev Environment Deployment Guide

**Document Version:** 1.0  
**Last Updated:** May 2026  
**Target Environment:** GCP Development Cluster

---

## Quick Reference

| Item | Value |
|------|-------|
| **Namespace** | `zora-ai-dev` |
| **GCP Region** | Contact CloudOps for region details |
| **Database** | `zora-ai-postgres:5432` (in-cluster) |
| **Repository** | `https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment` |
| **Values Path** | `kubernetes/gcp/dev/` |
| **ArgoCD Path** | `argocd/gcp/dev/` |

---

## Table of Contents

### Phase 1: Setup (Steps 1-3)
| Step | Description | Time |
|------|-------------|------|
| [Step 1](#step-1-prerequisites--cluster-access) | Prerequisites & Cluster Access | 15-30 min |
| [Step 2](#step-2-create-namespace) | Create Namespace | 2 min |
| [Step 3](#step-3-configure-doppler-secrets--azure-ad) | Configure Doppler Secrets & Azure AD | 30-60 min |

### Phase 2: Configuration (Steps 4-7)
| Step | Description | Time |
|------|-------------|------|
| [Step 4](#step-4-prepare-external-secrets-files) | Prepare External Secrets Files | 10 min |
| [Step 5](#step-5-confirm-network-routing-type) | Confirm Network Routing Type | 5 min |
| [Step 6](#step-6-prepare-service-values-files) | Prepare Service Values Files | 30-60 min |
| [Step 7](#step-7-configure-rbac-services) | Configure RBAC Services | 30 min |

### Phase 3: Deployment (Steps 8-10)
| Step | Description | Time |
|------|-------------|------|
| [Step 8](#step-8-prepare-argocd-application-manifests) | Prepare ArgoCD Application Manifests | 20 min |
| [Step 9](#step-9-integrate-github-with-argocd) | Integrate GitHub with ArgoCD | 10 min |
| [Step 10](#step-10-deploy-app-of-apps) | Deploy App-of-Apps | 10 min |

### Phase 4: Verification (Step 11)
| Step | Description | Time |
|------|-------------|------|
| [Step 11](#step-11-verify-deployment) | Verify Deployment | 15 min |

### Appendix
- [A. Architecture Overview](#appendix-a-architecture-overview)
- [B. Service Summary](#appendix-b-service-summary)
- [C. Quick Reference Commands](#appendix-c-quick-reference-commands)

---

# Phase 1: Setup

## Step 1: Prerequisites & Cluster Access

> **Time:** 15-30 minutes

### 1.1 Prerequisites Checklist

Before starting, ensure you have:

| # | Requirement | How to Verify | Status |
|---|-------------|---------------|--------|
| 1 | gcloud CLI installed | `gcloud --version` | ☐ |
| 2 | kubectl installed | `kubectl version --client` | ☐ |
| 3 | Doppler service token | Contact project admin | ☐ |
| 4 | Git repository access | Clone the repo | ☐ |
| 5 | ArgoCD admin access | Login to ArgoCD UI | ☐ |

### 1.2 Configure GCP CLI Access

Contact your CloudOps team to obtain GCP credentials, then configure:

```bash
# Step 1: Authenticate with GCP
gcloud auth login

# Step 2: Set the project
gcloud config set project <PROJECT_ID>

# Step 3: Get cluster credentials
gcloud container clusters get-credentials <CLUSTER_NAME> --region <REGION>

# Step 4: Verify cluster access
kubectl cluster-info
kubectl get nodes
```

### 1.3 Verify Cluster Connectivity

```bash
# Confirm you can access the cluster
kubectl get namespaces
```

✅ **Checkpoint:** You should see a list of namespaces in the cluster.

---

## Step 2: Create Namespace

> **Time:** 2 minutes

### 2.1 Create Application Namespace

```bash
kubectl create namespace zora-ai-dev
```

### 2.2 Verify Namespace

```bash
kubectl get namespace zora-ai-dev
```

✅ **Checkpoint:** Namespace `zora-ai-dev` should exist with status `Active`.

---

## Step 3: Configure Doppler Secrets & Azure AD

> **Time:** 30-60 minutes

### 3.1 Required Doppler Keys

Configure these **7 keys** in your Doppler project **before deployment**:

| # | Doppler Key | Description | How to Obtain |
|---|-------------|-------------|---------------|
| 1 | `JFROG_DOCKERCONFIGJSON` | Base64-encoded Docker registry credentials | JFrog Artifactory → User Profile → Generate Token |
| 2 | `DB_PASSWORD_POSTGRES` | PostgreSQL admin/service password | Generate strong password (20+ chars) |
| 3 | `DB_PASSWORD_POSTGRES_READ` | PostgreSQL read-only password | Generate strong password (20+ chars) |
| 4 | `DB_PASSWORD_ZORA_DEVELOPER` | PostgreSQL developer password | Generate strong password (20+ chars) |
| 5 | `REDIS_PASSWORD` | Redis authentication password | Generate strong password (20+ chars) |
| 6 | `AZURE_LLM_API_KEY` | Azure OpenAI or LiteLLM API key | Azure Portal → Azure OpenAI → Keys |
| 7 | `OIDC_CLIENT_SECRET` | Azure AD client secret for RBAC | Azure Portal → App Registrations → Certificates & Secrets |

### 3.2 Create Doppler Token Secret in Kubernetes

```bash
kubectl create secret generic doppler-token-secret \
  --namespace zora-ai-dev \
  --from-literal=dopplerToken=<YOUR_DOPPLER_SERVICE_TOKEN>
```

### 3.3 How Doppler Keys Map to Kubernetes Secrets

| Kubernetes Secret | Doppler Key(s) | Used By |
|-------------------|----------------|---------|
| `jfrog-registry-secret` | `JFROG_DOCKERCONFIGJSON` | All services (image pull) |
| `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES`, `DB_PASSWORD_POSTGRES_READ`, `DB_PASSWORD_ZORA_DEVELOPER` | Backend, Engine, Config Server, RBAC |
| `zora-ai-redis` | `REDIS_PASSWORD` | Engine, Backend |
| `zora-ai-engine-secrets` | `AZURE_LLM_API_KEY` | Engine |
| `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | RBAC Backend |

✅ **Checkpoint:** All 7 Doppler keys are configured in the Doppler dashboard.

### 3.4 Configure Azure AD App Registration (OIDC)

> **⚠️ Important:** This step must be completed **before deployment**. The OIDC callback URLs must be registered in Azure AD for SSO authentication to work.

#### 🔑 Azure AD App Registration Setup

> **Contact:** For Azure AD configuration assistance, reach out to **Michel from the iReal team**.

For SSO to work, you must register **both callback URLs** in your Azure AD App Registration:

| Callback URL | Purpose |
|--------------|---------|
| `https://zora-ai.zoraaigcp-dev.eng.deloitte.com/rbac/authentication/login/callback` | Zora Frontend SSO redirect |
| `https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com/api/authentication/login/callback` | RBAC Backend direct login |

#### Steps to Configure in Azure Portal

1. Go to **Azure Portal** → **App Registrations** → **Your App**
2. Navigate to **Authentication** → **Platform configurations**
3. Under **Web** → **Redirect URIs**, add both callback URLs above
4. Click **Save**

#### Example URLs

| URL Type | Example |
|----------|---------|
| Zora Frontend | `zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| RBAC Admin UI | `rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com` |

> **⚠️ Important:** The callback URLs must **exactly match** what you configured in `values-zora-ai-rbac-backend.yaml` and `values-zora-ai-rbac-backend-ui.yaml` for SSO to work properly.

✅ **Checkpoint:** Both callback URLs are registered in Azure AD App Registration.

---

# Phase 2: Configuration

## Step 4: Prepare External Secrets Files

> **Time:** 10 minutes

### 4.1 File Location

```
kubernetes/gcp/dev/external-secrets-v1/
├── cluster-secret-store.yaml     # Connects to Doppler
└── zora-ai-external-secrets.yaml # Defines secrets to sync
```

### 4.2 Files to Review/Update

| File | What to Check |
|------|---------------|
| `cluster-secret-store.yaml` | Verify `namespace` matches where External Secrets Operator runs |
| `zora-ai-external-secrets.yaml` | Verify all Doppler key names match your configuration |

### 4.3 Verify External Secrets Configuration

The `zora-ai-external-secrets.yaml` should contain these 5 ExternalSecret resources:

| # | ExternalSecret Name | Syncs From Doppler | Creates K8s Secret |
|---|---------------------|--------------------|--------------------|
| 1 | `jfrog-registry-secret` | `JFROG_DOCKERCONFIGJSON` | `jfrog-registry-secret` |
| 2 | `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES`, `DB_PASSWORD_POSTGRES_READ`, `DB_PASSWORD_ZORA_DEVELOPER` | `zora-ai-postgres-secrets` |
| 3 | `zora-ai-redis` | `REDIS_PASSWORD` | `zora-ai-redis` |
| 4 | `zora-ai-engine-secrets` | `AZURE_LLM_API_KEY` | `zora-ai-engine-secrets` |
| 5 | `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | `zora-ai-rbac-secrets` |

✅ **Checkpoint:** External secrets files are configured correctly.

---

## Step 5: Confirm Network Routing Type

> **Time:** 5 minutes

### 5.1 GCP Dev Uses HTTPRoute

| Parameter | Value |
|-----------|-------|
| Routing Type | **HTTPRoute** (Gateway API) |
| Gateway Name | `apps-gateway-internal` |
| Gateway Namespace | `ska-system` |
| Section Name | `apps-gateway-internal-https` |

### 5.2 HTTPRoute Configuration

In all values files, set:

```yaml
# Disable nginx Ingress
ingress:
  enabled: false

# Enable HTTPRoute
httpRoute:
  enabled: true
  host: your-service.zoraaigcp-dev.eng.deloitte.com
  gatewayName: apps-gateway-internal
  gatewayNamespace: ska-system
  sectionName: apps-gateway-internal-https
```

✅ **Checkpoint:** Confirmed HTTPRoute is the routing method for GCP Dev.

---

## Step 6: Prepare Service Values Files

> **Time:** 30-60 minutes

### 6.1 Values Files Location

```
kubernetes/gcp/dev/
```

### 6.2 All Values Files to Configure

| # | Service | Values File | Chart |
|---|---------|-------------|-------|
| 1 | Backend | `values-zora-ai-backend.yaml` | Universal Chart |
| 2 | Frontend | `values-zora-ai-frontend.yaml` | Universal Chart |
| 3 | Engine | `values-zora-ai-engine.yaml` | Universal Chart |
| 4 | Config Server | `values-zora-ai-configuration-server.yaml` | Universal Chart |
| 5 | Customer Data | `values-zora-ai-customer-data-server.yaml` | Universal Chart |
| 6 | PostgreSQL | `values-zora-ai-postgres.yaml` | `zora-ai-postgres` |
| 7 | Redis | `values-zora-ai-redis.yaml` | `zora-ai-redis` |
| 8 | Agent Skills | `values-zora-agent-skills.yaml` | `zora-ai-jobs` |
| 9 | Postgres Backup | `values-zora-ai-postgres-backup.yaml` | `zora-ai-jobs` |
| 10 | Postgres Init DB | `values-zora-ai-postgres-init-db.yaml` | `zora-ai-jobs` |
| 11 | Postgres Idle Cleaner | `values-zora-ai-postgres-idle-cleaner.yaml` | `zora-ai-jobs` |

### 6.3 Common Parameters to Update

For **each values file**, update these parameters:

| Parameter | Description | Example Value |
|-----------|-------------|---------------|
| `image.tag` | Service version | `2026.05.08-0220` |
| `httpRoute.host` | Service DNS name | `zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| `resources.limits` | CPU/Memory limits | `cpu: "4"`, `memory: 32Gi` |
| `resources.requests` | CPU/Memory requests | `cpu: "2"`, `memory: 10Gi` |

### 6.4 Environment-Specific Values

| Parameter | GCP Dev Value |
|-----------|---------------|
| Database Host | `zora-ai-postgres` |
| Database Port | `5432` |
| Database Username | `postgres` |
| Redis Host | `zora-ai-redis-master` |
| Redis Port | `6379` |

> **Note:** GCP Dev uses an **in-cluster PostgreSQL** deployment (`zora-ai-postgres`) instead of a managed database service.

✅ **Checkpoint:** All 11 values files are configured with correct hostnames and database endpoints.

---

## Step 7: Configure RBAC Services

> **Time:** 30 minutes

### 7.1 RBAC Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                    RBAC Authentication Flow                      │
│                                                                   │
│  User → RBAC Frontend → API Proxy (/api/*) → RBAC Backend       │
│                              │                     │              │
│                              │                     ▼              │
│                              │              Azure AD (OIDC)       │
│                              │                     │              │
│                              ▼                     ▼              │
│                         PostgreSQL (rbac_db)                      │
└─────────────────────────────────────────────────────────────────┘
```

### 7.2 RBAC Configuration Files Summary

All RBAC files are located in: `kubernetes/gcp/dev/`

| # | Component | File Path | Chart |
|---|-----------|-----------|-------|
| 1 | RBAC Backend | `values-zora-ai-rbac-backend.yaml` | `zora-ai-comserv-rbac-app` |
| 2 | RBAC Backend UI | `values-zora-ai-rbac-backend-ui.yaml` | `zora-ai-comserv-rbac-app` |
| 3 | RBAC Frontend | `values-zora-ai-rbac-frontend.yaml` | `zora-ai-comserv-rbac-ui` |
| 4 | RBAC API Proxy | `rbac-api-proxy/ingress.yaml` | Raw HTTPRoute |

### 7.3 RBAC Backend Configuration

📁 **File:** `kubernetes/gcp/dev/values-zora-ai-rbac-backend.yaml`

**Purpose:** API server for main Zora app SSO

Update with these parameters:

```yaml
deployment:
  env:
    # OIDC Endpoints (update with your URLs)
    ISSUER: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    JWT_ISSUER: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    LOCALHOST_ENDPOINT: https://zora-ai.zoraaigcp-dev.eng.deloitte.com/sso/callback
    ALLOWED_AUDIENCES: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    
    # Azure AD Configuration (get from Azure Portal)
    OIDC_ISSUER: "https://login.microsoftonline.com/<TENANT_ID>/v2.0"
    OIDC_AUTHURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/authorize"
    OIDC_TOKENURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/token"
    OIDC_USERINFOURL: "https://graph.microsoft.com/oidc/userinfo"
    OIDC_CLIENTID: "<YOUR_AZURE_AD_APP_CLIENT_ID>"
    OIDC_CALLBACKURL: "https://zora-ai.zoraaigcp-dev.eng.deloitte.com/rbac/authentication/login/callback"
    OIDC_SCOPE: "openid profile email"
    
    # Database (in-cluster PostgreSQL)
    DB_HOST: zora-ai-postgres
    DB_PORT: "5432"
    DB_USER: "postgres"
    DB_DATABASE: rbac_db
```

### 7.4 RBAC Backend UI Configuration

📁 **File:** `kubernetes/gcp/dev/values-zora-ai-rbac-backend-ui.yaml`

**Purpose:** API server for RBAC admin UI SSO

> **Note:** This is a second RBAC backend instance dedicated to the RBAC UI. The key difference is `LOCALHOST_ENDPOINT` and `OIDC_CALLBACKURL` point to the RBAC UI domain, so after SSO the user lands on the RBAC UI (not the main Zora app). Both instances share the same database.

```yaml
deployment:
  env:
    # OIDC Endpoints (RBAC UI specific - different from main backend)
    ISSUER: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    JWT_ISSUER: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    LOCALHOST_ENDPOINT: https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com/sso/callback  # Points to RBAC UI
    ALLOWED_AUDIENCES: https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com
    
    # Azure AD Configuration (same as main backend)
    OIDC_ISSUER: "https://login.microsoftonline.com/<TENANT_ID>/v2.0"
    OIDC_AUTHURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/authorize"
    OIDC_TOKENURL: "https://login.microsoftonline.com/<TENANT_ID>/oauth2/v2.0/token"
    OIDC_USERINFOURL: "https://graph.microsoft.com/oidc/userinfo"
    OIDC_CLIENTID: "<YOUR_AZURE_AD_APP_CLIENT_ID>"
    OIDC_CALLBACKURL: "https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com/api/authentication/login/callback"  # RBAC UI callback
    OIDC_SCOPE: "openid profile email"
    
    # Database (shared with main RBAC backend)
    DB_HOST: zora-ai-postgres
    DB_PORT: "5432"
    DB_USER: "postgres"
    DB_DATABASE: rbac_db
    
    # Authentication Settings
    LOGIN_ENABLED: "true"
    ALLOW_AUTO_USER_CREATION: "true"
    DEFAULT_ROLE_KEY: RBAC-END-USER
    INTERNAL_DOMAIN: "deloitte.com"
```

#### Key Differences: RBAC Backend vs RBAC Backend UI

| Parameter | RBAC Backend (Main App) | RBAC Backend UI (RBAC Admin) |
|-----------|-------------------------|------------------------------|
| `LOCALHOST_ENDPOINT` | `https://zora-ai.../sso/callback` | `https://rbac-zora-ai.../sso/callback` |
| `OIDC_CALLBACKURL` | `https://zora-ai.../rbac/authentication/login/callback` | `https://rbac-zora-ai.../api/authentication/login/callback` |
| **Purpose** | SSO redirects to main Zora app | SSO redirects to RBAC admin UI |

### 7.5 RBAC Frontend Configuration

📁 **File:** `kubernetes/gcp/dev/values-zora-ai-rbac-frontend.yaml`

**Purpose:** React RBAC admin interface

Update with these parameters:

```yaml
deployment:
  env:
    REACT_APP_API_URL: https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com/api
    REACT_CC_PROD_DOMAIN: rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com

httpRoute:
  enabled: true
  host: rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com
```

### 7.6 RBAC API Proxy Configuration

📁 **File:** `kubernetes/gcp/dev/rbac-api-proxy/ingress.yaml`

**Purpose:** Routes `/api/*` requests to RBAC Backend UI for cookie handling

Update with these parameters:

```yaml
apiVersion: gateway.networking.k8s.io/v1
kind: HTTPRoute
metadata:
  name: zora-ai-rbac-api-proxy
  namespace: zora-ai-dev
spec:
  hostnames:
  - rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com  # Update hostname
  parentRefs:
  - name: apps-gateway-internal
    namespace: ska-system
    sectionName: apps-gateway-internal-https
  rules:
  - matches:
    - path:
        type: PathPrefix
        value: /api
    filters:
    - type: URLRewrite
      urlRewrite:
        path:
          type: ReplacePrefixMatch
          replacePrefixMatch: /
    backendRefs:
    - name: zora-ai-rbac-app-ui
      port: 80
```

### 7.7 RBAC Secrets Required

| Secret | Doppler Key | Purpose |
|--------|-------------|---------|
| `zora-ai-rbac-secrets` | `OIDC_CLIENT_SECRET` | Azure AD authentication |
| `zora-ai-postgres-secrets` | `DB_PASSWORD_POSTGRES` | Database access |

✅ **Checkpoint:** All 4 RBAC configuration files are updated (Backend, Backend UI, Frontend, API Proxy).

---

# Phase 3: Deployment

## Step 8: Prepare ArgoCD Application Manifests

> **Time:** 20 minutes

### 8.1 ArgoCD Apps Location

```
argocd/gcp/dev/
```

### 8.2 All ArgoCD Application Files

| # | ArgoCD App File | Deploys | Chart |
|---|-----------------|---------|-------|
| 1 | `external-secrets.yaml` | External Secrets | Raw manifests |
| 2 | `backend.yaml` | Backend service | Universal Chart |
| 3 | `frontend.yaml` | Frontend service | Universal Chart |
| 4 | `engine.yaml` | AI Engine | Universal Chart |
| 5 | `configuration-server.yaml` | Config Server | Universal Chart |
| 6 | `customer-data-server.yaml` | Customer Data | Universal Chart |
| 7 | `rbac-backend.yaml` | RBAC Backend | `zora-ai-comserv-rbac-app` |
| 8 | `rbac-backend-ui.yaml` | RBAC Backend UI | `zora-ai-comserv-rbac-app` |
| 9 | `rbac-frontend.yaml` | RBAC Frontend | `zora-ai-comserv-rbac-ui` |
| 10 | `rbac-api-proxy.yaml` | RBAC API Proxy | Raw HTTPRoute |
| 11 | `postgres.yaml` | PostgreSQL | `zora-ai-postgres` |
| 12 | `redis.yaml` | Redis | `zora-ai-redis` |
| 13 | `agent-skills.yaml` | Agent Skills Job | `zora-ai-jobs` |
| 14 | `postgres-init-db.yaml` | DB Init Job | `zora-ai-jobs` |
| 15 | `postgres-backup.yaml` | Backup Job | `zora-ai-jobs` |
| 16 | `postgres-idle-cleaner.yaml` | Idle Cleaner | `zora-ai-jobs` |
| 17 | `langfuse.yaml` | Langfuse | Custom |

### 8.3 ArgoCD Application Structure

Each ArgoCD app manifest should have:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-<service>          # App name
  namespace: argocd                 # Always argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/charts/<chart-name>
    helm:
      valueFiles:
        - ../../gcp/dev/<values-file>.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-dev          # Target namespace
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### 8.4 Sync Policy Explained

| Setting | Value | Description |
|---------|-------|-------------|
| `automated.prune` | `false` | Don't auto-delete resources not in Git |
| `automated.selfHeal` | `true` | Auto-fix drift from desired state |
| `CreateNamespace` | `true` | Create namespace if missing |

✅ **Checkpoint:** All 17 ArgoCD application files are configured.

---

## Step 9: Integrate GitHub with ArgoCD

> **Time:** 10 minutes

### 9.1 Repository Information

| Parameter | Value |
|-----------|-------|
| Repository URL | `https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment` |
| Target Branch | `main` |
| Authentication | GitHub App or SSH Key (configured by platform team) |

### 9.2 Repository Structure

```
aiq-zora-ai-deployment/
├── argocd/
│   └── gcp/dev/               # ArgoCD Application manifests
├── kubernetes/
│   ├── charts/                 # Helm charts (shared)
│   └── gcp/dev/               # Environment-specific values
```

### 9.3 Verify GitHub Connection in ArgoCD

1. Login to ArgoCD UI
2. Go to **Settings** → **Repositories**
3. Verify `aiq-zora-ai-deployment` repository is connected
4. Status should show **Successful**

✅ **Checkpoint:** GitHub repository is connected to ArgoCD.

---

## Step 10: Deploy App-of-Apps

> **Time:** 10 minutes

### 10.1 What is App-of-Apps?

App-of-Apps is an ArgoCD pattern where **one parent Application manages multiple child Applications**. This allows deploying the entire platform with a single command.

### 10.2 Parent Application Manifest

Location: `argocd/app-of-apps/gcp/dev/application.yaml`

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-gcp-app-of-apps
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    path: argocd/gcp/dev    # Points to folder with all app manifests
    targetRevision: main
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-dev
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
```

### 10.3 Deploy the App-of-Apps

```bash
kubectl apply -f argocd/app-of-apps/gcp/dev/application.yaml
```

### 10.4 What Happens After Deployment

1. ArgoCD creates the parent `zora-ai-gcp-app-of-apps` Application
2. Parent Application discovers all child Application manifests in `argocd/gcp/dev/`
3. ArgoCD creates all 17 child Applications
4. Each child Application syncs its Helm chart with values
5. Kubernetes resources are created in `zora-ai-dev` namespace

✅ **Checkpoint:** App-of-Apps is deployed to ArgoCD.

---

# Phase 4: Verification

## Step 11: Verify Deployment

> **Time:** 15 minutes

### 11.1 Check ArgoCD Status

In ArgoCD UI:

| Application | Expected Status |
|-------------|-----------------|
| `zora-ai-gcp-app-of-apps` | ✅ Synced, ✅ Healthy |
| All child applications | ✅ Synced, ✅ Healthy |

### 11.2 Check Kubernetes Pods

```bash
kubectl get pods -n zora-ai-dev
```

**Expected output:**
```
NAME                                            READY   STATUS    RESTARTS   AGE
zora-ai-backend-xxxxx                           1/1     Running   0          5m
zora-ai-frontend-xxxxx                          1/1     Running   0          5m
zora-ai-engine-xxxxx                            1/1     Running   0          5m
zora-ai-configuration-server-xxxxx              1/1     Running   0          5m
zora-ai-customer-data-server-xxxxx              1/1     Running   0          5m
zora-ai-rbac-app-xxxxx                          1/1     Running   0          5m
zora-ai-rbac-app-ui-xxxxx                       1/1     Running   0          5m
zora-ai-rbac-ui-xxxxx                           1/1     Running   0          5m
zora-ai-postgres-0                              1/1     Running   0          5m
zora-ai-redis-master-0                          1/1     Running   0          5m
```

### 11.3 Check External Secrets

```bash
kubectl get externalsecrets -n zora-ai-dev
```

All secrets should show `SecretSynced` status.

### 11.4 Access Application URLs

| Service | URL |
|---------|-----|
| **Frontend** | `https://zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| **Backend API** | `https://zora-ai-backend.zoraaigcp-dev.eng.deloitte.com` |
| **RBAC Admin** | `https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| **Config Server** | `https://zora-ai-configuration-server.zoraaigcp-dev.eng.deloitte.com` |

✅ **Deployment Complete!**

---

# Appendix A: Architecture Overview

## How It Works

```
┌──────────────────────────────────────────────────────────────────────┐
│                        GitOps Deployment Flow                         │
└──────────────────────────────────────────────────────────────────────┘

    ┌─────────┐         ┌─────────┐         ┌─────────────┐
    │ GitHub  │────────▶│ ArgoCD  │────────▶│ Kubernetes  │
    │  Repo   │         │ Server  │         │   Cluster   │
    └─────────┘         └─────────┘         └─────────────┘
         │                   │                     │
         │  1. Push code     │  2. Detect change   │  3. Apply manifests
         │                   │                     │
         ▼                   ▼                     ▼
    ┌─────────┐         ┌─────────┐         ┌─────────────┐
    │ Values  │         │  Sync   │         │   Running   │
    │  Files  │         │ Compare │         │    Pods     │
    └─────────┘         └─────────┘         └─────────────┘
```

## Component Interaction

1. **External Secrets Operator** → Syncs secrets from Doppler to Kubernetes
2. **ArgoCD** → Monitors Git repository for changes
3. **Helm Charts** → Rendered with environment-specific values
4. **HTTPRoute** → Exposes services via Gateway API
5. **Services** → Connect to in-cluster PostgreSQL and Redis

## Self-Healing Behavior

- ArgoCD continuously monitors cluster state
- Manual changes are automatically reverted to match Git
- New commits trigger automatic deployments
- Failed deployments are rolled back automatically

## GCP vs AWS Differences

| Component | GCP Dev | AWS SUT Dev |
|-----------|---------|-------------|
| Database | In-cluster PostgreSQL | Aurora PostgreSQL (managed) |
| Namespace | `zora-ai-dev` | `zora-ai-sut` |
| Domain | `*.zoraaigcp-dev.eng.deloitte.com` | `*.dev.sut.zoraai.eng.deloitte.com` |
| Routing | HTTPRoute (Gateway API) | HTTPRoute (Gateway API) |

---

# Appendix B: Service Summary

## All Deployed Services

| # | Service | Chart | Description |
|---|---------|-------|-------------|
| 1 | Backend | Universal Chart | Core API services |
| 2 | Frontend | Universal Chart | Web UI application |
| 3 | Engine | Universal Chart | AI/ML processing engine |
| 4 | Config Server | Universal Chart | Configuration management |
| 5 | Customer Data | Universal Chart | Customer data APIs |
| 6 | RBAC Backend | `zora-ai-comserv-rbac-app` | Authentication API (OIDC) |
| 7 | RBAC Backend UI | `zora-ai-comserv-rbac-app` | RBAC backend for admin UI |
| 8 | RBAC Frontend | `zora-ai-comserv-rbac-ui` | RBAC admin interface |
| 9 | RBAC API Proxy | HTTPRoute | Routes /api/* for cookies |
| 10 | PostgreSQL | `zora-ai-postgres` | Database (in-cluster) |
| 11 | Redis | `zora-ai-redis` | In-memory data store |
| 12 | Agent Skills | `zora-ai-jobs` | Skills initialization job |
| 13 | Postgres Init DB | `zora-ai-jobs` | Database initialization |
| 14 | Postgres Backup | `zora-ai-jobs` | Database backup job |
| 15 | Postgres Idle Cleaner | `zora-ai-jobs` | Idle connection cleanup |
| 16 | Langfuse | Custom | LLM observability |

## DNS Endpoints

| Service | URL |
|---------|-----|
| Frontend | `https://zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| Backend API | `https://zora-ai-backend.zoraaigcp-dev.eng.deloitte.com` |
| RBAC Admin UI | `https://rbac-zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| RBAC API | `https://rbac-api-zora-ai.zoraaigcp-dev.eng.deloitte.com` |
| Config Server | `https://zora-ai-configuration-server.zoraaigcp-dev.eng.deloitte.com` |

---

# Appendix C: Quick Reference Commands

```bash
# Check deployment status
kubectl get pods -n zora-ai-dev

# View ArgoCD applications
kubectl get applications -n argocd | grep zora

# Check External Secrets
kubectl get externalsecrets -n zora-ai-dev

# View logs for a service
kubectl logs -f deployment/zora-ai-backend -n zora-ai-dev

# Check service endpoints
kubectl get svc -n zora-ai-dev

# Describe pod for troubleshooting
kubectl describe pod <pod-name> -n zora-ai-dev

# Check HTTPRoutes
kubectl get httproutes -n zora-ai-dev

# Check PostgreSQL status (in-cluster)
kubectl get pods -n zora-ai-dev | grep postgres

# Connect to PostgreSQL
kubectl exec -it zora-ai-postgres-0 -n zora-ai-dev -- psql -U postgres
```

---

## Support

For deployment issues or questions, contact:
- **Platform Team:** Cloud Operations
- **Repository:** [aiq-zora-ai-deployment](https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment)

---

*Document maintained by Zora AI DevOps Team*
