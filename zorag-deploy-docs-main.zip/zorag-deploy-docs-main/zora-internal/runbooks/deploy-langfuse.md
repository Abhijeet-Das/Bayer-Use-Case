# Runbook: Deploy Langfuse to a New Cluster

End-to-end procedure to deploy a per-cluster Langfuse v3 instance for LLM observability.

**Decision (May 2026):** Each cluster gets its own Langfuse instance to avoid cross-environment noise and keep customer data isolated. Inside each Langfuse, projects can still be used to slice by app/workflow.

**Reference implementations:**
- `dev2` — `argocd/dev2/langfuse.yaml`, values: `kubernetes/azure/dev2/langfuse/langfuse-values-azure.yaml`, host: `zoraai-langfuse.dev02.zoraai.deloitteinnovation.us`
- `exxon-dev` — `argocd/exxon/dev/langfuse.yaml`, host: `zoraai-langfuse.dev.exxonmobile.zoraai.eng.deloitte.com`

---

## Architecture

The `zora-ai-langfuse` chart deploys Langfuse v3:

| Component   | Notes                                                            |
| ----------- | ---------------------------------------------------------------- |
| `web`       | Next.js UI + API, port 3000, behind nginx-internal Ingress       |
| `worker`    | Async trace ingestion, port 3030                                 |
| PostgreSQL  | Metadata (StatefulSet, `managed-premium` PV)                     |
| ClickHouse  | Trace storage (StatefulSet, `managed-premium` PV)                |
| Redis       | Queue / cache (StatefulSet, `managed-premium` PV)                |
| Azure Blob  | Event/media/export uploads (external — keys come from Doppler)   |

Secrets flow: **Doppler → ExternalSecret → `langfuse-zora-ai-langfuse-secret-service` Secret → web/worker env**.

The chart uses `find: regexp: .*` on its `ExternalSecret`, so it pulls **every** key from its Doppler config. Each cluster therefore needs its own Doppler config with cluster-specific values (especially `NEXTAUTH_URL` and blob storage prefixes).

---

## Doppler Config Naming Convention

| Tier  | Doppler root | Pattern                       | Examples                                                                                          |
| ----- | ------------ | ----------------------------- | ------------------------------------------------------------------------------------------------- |
| dev   | `dev`        | `dev_langfuse_<cluster>`      | `dev_langfuse_dev03`, `dev_langfuse_qa`, `dev_langfuse_lab`, `dev_langfuse_demo`, `dev_langfuse_nvidia_qa`, `dev_langfuse_advise`, `dev_langfuse_sut_qa` |
| prod  | `prd`        | `prd_langfuse_<cluster>`      | `prd_langfuse_colgate`, `prd_langfuse_exxon`, `prd_langfuse_sut_ppd`                              |

All Langfuse configs live in the `pllm-inference` Doppler project. The existing `dev_langfuse` config (no suffix) belongs to dev2 — when convenient, rename to `dev_langfuse_dev02` for consistency.

### Per-cluster keys (22 total)

| Key                                       | Per-cluster? | Notes                                                  |
| ----------------------------------------- | ------------ | ------------------------------------------------------ |
| `NEXTAUTH_URL`                            | **Yes**      | Must match the cluster's Langfuse hostname             |
| `NEXTAUTH_SECRET`                         | **Yes**      | `openssl rand -base64 32`                              |
| `SALT`                                    | **Yes**      | `openssl rand -base64 32`                              |
| `ENCRYPTION_KEY`                          | **Yes**      | `openssl rand -hex 32`                                 |
| `DATABASE_URL`                            | Yes          | In-cluster postgres — same DNS, different password OK  |
| `CLICKHOUSE_PASSWORD`                     | Yes          | New random per cluster                                 |
| `REDIS_AUTH`                              | Yes          | New random per cluster                                 |
| `LANGFUSE_S3_EVENT_UPLOAD_ENDPOINT`       | Yes          | Blob storage URL — see "Blob Storage" below            |
| `LANGFUSE_S3_EVENT_UPLOAD_ACCESS_KEY_ID`  | Yes          | Storage account name                                   |
| `LANGFUSE_S3_EVENT_UPLOAD_SECRET_ACCESS_KEY` | Yes       | Storage account key                                    |
| `LANGFUSE_S3_MEDIA_UPLOAD_*` (3 keys)     | Yes          | Same shape as above                                    |
| `LANGFUSE_S3_BATCH_EXPORT_*` (4 keys)     | Yes          | Same shape, plus `_EXTERNAL_ENDPOINT`                  |
| `LANGFUSE_INIT_USER_EMAIL`                | Shared OK    | Bootstrap admin user                                   |
| `LANGFUSE_INIT_USER_NAME`                 | Shared OK    |                                                        |
| `LANGFUSE_INIT_USER_PASSWORD`             | **Yes**      | Different per cluster                                  |
| `LANGFUSE_INIT_PROJECT_PUBLIC_KEY`        | **Yes**      | `pk-lf-...`                                            |
| `LANGFUSE_INIT_PROJECT_SECRET_KEY`        | **Yes**      | `sk-lf-...`                                            |

### Blob Storage strategy

Two options, choose per cluster:

1. **Dedicated storage account per cluster** — cleanest isolation, more setup.
2. **Shared storage account, per-cluster containers** — reuse one account (e.g. `zoraailangfusestorage`) but use container names like `langfuse-events-dev03`, `langfuse-media-dev03`, `langfuse-exports-dev03`. Set the `bucket` fields in the values file accordingly.

For internal dev clusters (dev3, dev4, qa, lab, perf, demo): option 2 is fine.
For customer clusters (colgate, exxon): option 1 — separate storage account in the customer's subscription.

---

## Per-Cluster Procedure

### 1. Create the Doppler config

1. In Doppler UI → project `pllm-inference` → next to `dev_langfuse` → **"…" → Duplicate Config**.
2. Name suffix: type just the suffix, e.g. `langfuse_dev03` (the `dev_` / `prd_` prefix is added automatically based on the parent root).
3. Open the new config and rotate:
   - `NEXTAUTH_URL` → `https://zoraai-langfuse.<env>.<domain>`
   - `NEXTAUTH_SECRET`, `SALT` → `openssl rand -base64 32`
   - `ENCRYPTION_KEY` → `openssl rand -hex 32`
   - `DATABASE_URL` password, `CLICKHOUSE_PASSWORD`, `REDIS_AUTH` → new randoms
   - `LANGFUSE_S3_*` endpoints + keys → cluster's storage account or per-cluster containers
   - `LANGFUSE_INIT_USER_PASSWORD`, `LANGFUSE_INIT_PROJECT_PUBLIC_KEY`, `LANGFUSE_INIT_PROJECT_SECRET_KEY` → new randoms
4. **Access tab → Generate Service Token** (read-only). Copy the `dp.st...` value.

### 2. Add the cluster's Langfuse service token to `ci_zora_ai`

**No kubectl required** — the chart bootstraps the per-namespace Doppler token Secret via the cluster-wide `doppler-zora-ai` ClusterSecretStore (which already exists in every cluster and reads `pllm-inference/ci_zora_ai`).

1. In Doppler → `pllm-inference` → `ci_zora_ai` → **Add Secret**:
   - Key: `LANGFUSE_DOPPLER_TOKEN_<ENV>` (e.g. `LANGFUSE_DOPPLER_TOKEN_QA`, `LANGFUSE_DOPPLER_TOKEN_SUT_QA1`)
   - Value: the `dp.st.<langfuse_<env>>.XXXX` service token from step 1.
2. Save. External Secrets in every cluster will pick this up on next refresh.

> The chart template `templates/doppler-token-bootstrap.yaml` creates an
> `ExternalSecret` (sync-wave `-10`) that materialises a Secret named
> `doppler-token-secret` (key: `dopplerToken`) in the `zora-ai-langfuse`
> namespace, which the chart's own `SecretStore` then uses to read all 22
> Langfuse keys from the per-cluster config.

### 3. Add chart values for the cluster

For new clusters scaffolded by `scripts/scaffold-langfuse-azure.ps1` /
`scripts/scaffold-langfuse-aws-gcp.ps1` this file already exists. To add a
brand-new cluster, follow the pattern in those scripts or copy an existing
file (`kubernetes/azure/dev3/langfuse/langfuse-values-azure.yaml` for Azure,
`kubernetes/aws/values/dev/sut/langfuse/langfuse-values-aws.yaml` for AWS).

**Required overrides per cluster:**
- `dopplerBootstrap.remoteKey` → `LANGFUSE_DOPPLER_TOKEN_<ENV>` (matches the Doppler key from step 2)
- `ingress.hosts[0].host` (Azure/GCP) **or** `httpRoute.host` (AWS) → cluster's Langfuse FQDN
- `ingress.tls[0].secretName` → `zoraai-langfuse-<env>-tls-secret` (Azure only)
- `storage.*.region` → cluster's region

Keep `dopplerBootstrap.enabled: true`.

### 4. Add the ArgoCD Application

Create `argocd/<env>/langfuse.yaml`. Use dev2 as the template — only `valueFiles` path changes:

```yaml
apiVersion: argoproj.io/v1alpha1
kind: Application
metadata:
  name: zora-ai-langfuse
  namespace: argocd
spec:
  project: default
  source:
    repoURL: https://github.com/Deloitte-US-Innovation-Technology/aiq-zora-ai-deployment
    targetRevision: main
    path: kubernetes/charts/zora-ai-langfuse
    helm:
      valueFiles:
        - ../../<cloud>/<env>/langfuse/langfuse-values-azure.yaml
  destination:
    server: https://kubernetes.default.svc
    namespace: zora-ai-langfuse
  syncPolicy:
    automated:
      prune: false
      selfHeal: true
    syncOptions:
      - CreateNamespace=true
```

### 5. Validate locally before pushing

```bash
helm lint kubernetes/charts/zora-ai-langfuse \
  -f kubernetes/<cloud>/<env>/langfuse/langfuse-values-azure.yaml
helm template langfuse kubernetes/charts/zora-ai-langfuse \
  -f kubernetes/<cloud>/<env>/langfuse/langfuse-values-azure.yaml | less
```

### 6. Commit and push

```bash
git add argocd/<env>/langfuse.yaml kubernetes/<cloud>/<env>/langfuse/
git commit -m "feat(<env>): add langfuse argocd app and values"
git pull --rebase origin main && git push origin main
```

### 7. DNS

Point the FQDN at the cluster's nginx-internal Ingress IP:

```bash
kubectl -n zora-ai-langfuse get ingress
```

See [update-loadbalancer-dns.md](update-loadbalancer-dns.md) for the Azure DNS A-record procedure.

### 8. Verify

1. **ArgoCD UI** — `zora-ai-langfuse` app should sync to `Synced + Healthy`.
2. **Pods** — `kubectl -n zora-ai-langfuse get pods` — web, worker, postgres, redis, clickhouse all `Running`.
3. **UI** — open the FQDN in a browser, sign in with `LANGFUSE_INIT_USER_EMAIL` / `LANGFUSE_INIT_USER_PASSWORD`.
4. **Send a test trace** from a local Python script using `LANGFUSE_PUBLIC_KEY` / `LANGFUSE_SECRET_KEY` / `LANGFUSE_HOST`.

---

## Wiring LiteLLM to push traces (separate follow-up)

Once Langfuse is up in a cluster, enable the in-cluster LiteLLM proxy to push traces:

1. In `kubernetes/<cloud>/<env>/litellm/configmap.yaml`, under `litellm_settings`, add:
   ```yaml
   success_callback: ["langfuse"]
   failure_callback: ["langfuse"]
   ```
2. In `kubernetes/<cloud>/<env>/litellm/deployment.yaml`, add to the proxy container env:
   ```yaml
   - name: LANGFUSE_HOST
     value: "http://langfuse-zora-ai-langfuse-web.zora-ai-langfuse.svc.cluster.local:3000"
   - name: LANGFUSE_PUBLIC_KEY
     valueFrom:
       secretKeyRef:
         name: litellm-creds
         key: LANGFUSE_PUBLIC_KEY
   - name: LANGFUSE_SECRET_KEY
     valueFrom:
       secretKeyRef:
         name: litellm-creds
         key: LANGFUSE_SECRET_KEY
   ```
3. Add `LANGFUSE_PUBLIC_KEY` and `LANGFUSE_SECRET_KEY` to the `litellm-creds` ExternalSecret (in `kubernetes/<cloud>/external-secrets-v1/`). Source these from the per-cluster Langfuse Doppler config (the `LANGFUSE_INIT_PROJECT_PUBLIC_KEY` / `_SECRET_KEY` values, or generate fresh project keys in the Langfuse UI).

Using the **in-cluster** hostname for `LANGFUSE_HOST` keeps trace traffic on the cluster network (no Ingress round-trip).

---

## Deployment status

| Cluster        | Manifests committed | Doppler config              | Doppler token key in `ci_zora_ai`         |
| -------------- | ------------------- | --------------------------- | ----------------------------------------- |
| dev2           | ✅                  | `dev_langfuse`              | (legacy — manual `doppler-token-secret`)  |
| dev3           | ✅                  | `dev_langfuse_dev03`        | `LANGFUSE_DOPPLER_TOKEN_DEV03`            |
| dev5           | ✅                  | `dev_langfuse_dev05`        | `LANGFUSE_DOPPLER_TOKEN_DEV05`            |
| qa             | ✅                  | `dev_langfuse_qa`           | `LANGFUSE_DOPPLER_TOKEN_QA`               |
| lab            | ✅                  | `dev_langfuse_lab`          | `LANGFUSE_DOPPLER_TOKEN_LAB`              |
| perf           | ✅                  | `dev_langfuse_perf`         | `LANGFUSE_DOPPLER_TOKEN_PERF`             |
| demo (eus)     | ✅                  | `dev_langfuse_demo`         | `LANGFUSE_DOPPLER_TOKEN_DEMO`             |
| demo-wus       | ✅                  | `dev_langfuse_demo_wus`     | `LANGFUSE_DOPPLER_TOKEN_DEMO_WUS`         |
| nvidia/dev2    | ✅                  | `dev_langfuse_nvidia_dev02` | `LANGFUSE_DOPPLER_TOKEN_NVIDIA_DEV02`     |
| nvidia/qa      | ✅                  | `dev_langfuse_nvidia_qa`    | `LANGFUSE_DOPPLER_TOKEN_NVIDIA_QA`        |
| exxon/dev      | ✅                  | (set by Suresh)             | (legacy — manual `doppler-token-secret`)  |
| exxon/prod     | ✅                  | `prd_langfuse_exxon`        | `LANGFUSE_DOPPLER_TOKEN_EXXON_PROD`       |
| colgate        | ✅                  | `dev_langfuse_colgate`      | `LANGFUSE_DOPPLER_TOKEN_COLGATE`          |
| colgate-prod   | ✅                  | `prd_langfuse_colgate`      | `LANGFUSE_DOPPLER_TOKEN_COLGATE_PROD`     |
| aws/dev/sut    | ✅                  | `dev_langfuse_sut_dev`      | `LANGFUSE_DOPPLER_TOKEN_SUT_DEV`          |
| aws/qa/sut     | ✅                  | `dev_langfuse_sut_qa`       | `LANGFUSE_DOPPLER_TOKEN_SUT_QA`           |
| aws/qa1/sut    | ✅                  | `dev_langfuse_sut_qa1`      | `LANGFUSE_DOPPLER_TOKEN_SUT_QA1`          |
| aws/ppd/sut    | ✅                  | `prd_langfuse_sut_ppd`      | `LANGFUSE_DOPPLER_TOKEN_SUT_PPD`          |
| aws/dev-advise | ✅                  | `dev_langfuse_advise`       | `LANGFUSE_DOPPLER_TOKEN_ADVISE`           |
| gcp/dev        | ✅                  | `dev_langfuse_gcp`          | `LANGFUSE_DOPPLER_TOKEN_GCP`              |

"Manifests committed" only means the ArgoCD app + values file exist in this repo. Each cluster still needs the Doppler work (clone config, rotate keys, add token to `ci_zora_ai`) and a DNS A record before its Langfuse will actually come up.
