# RBAC User Role Assignment Runbook

Assign roles to users in the comserv-rbac system to grant access to Zora AI frontend and application modules.

## Overview

**comserv-rbac** is the centralized RBAC (Role-Based Access Control) service managing authentication and authorization for the Zora AI platform. Users authenticate via Azure AD OIDC, and the RBAC service issues JWT tokens based on their assigned roles.

### Two-Layer Authorization Model

Authorization works in two layers. Both are required for full access:

```
Layer 1: Authentication (base RBAC role)
  User logs in via SSO → RBAC issues JWT → Backend calls RBAC GET /user
  → If user has no role → 403 "no RBAC-END-USER role detected"
  → If user has RBAC-END-USER or RBAC-ROOT → authentication succeeds

Layer 2: Feature Authorization (application-specific roles)
  User clicks "Activate Digital Workers" or creates a conversation
  → Backend calls RBAC GET /user/isAuthorized?action=Zora:WorkspaceCreate
  → RBAC checks if user's roles include a policy with that action
  → If no matching policy → 403 "Not authorized to access service"
  → If policy found → access granted
```

**Layer 1** roles (RBAC-ROOT, RBAC-END-USER) only contain `RBAC:*` actions (RBAC system administration). They do NOT grant `Zora:*` actions.

**Layer 2** roles (operational_finance, senior_finance_leadership, etc.) contain `Zora:*` actions (WorkspaceCreate, ConversationCreate, PerformancePulse, EditConfiguration).

**Key concepts:**
- **Users** - Authenticated via Azure AD OIDC (auto-created on first login if `ALLOW_AUTO_USER_CREATION: "true"`)
- **Roles** - Collections of permissions scoped to specific applications
- **Policies** - Define allowed actions on application resources (RBAC:* or Zora:* actions)
- **Role-Policy mappings** - Roles grant permissions via associated policies
- **Principal-Role assignments** - Users (principals) are assigned roles via the `principalrole` table
- **Applications** - Protected modules (RBAC, Platform Base, CFO Insights, Expense Management, Collections, Payments)

**Database:** `rbac_db` on `zora-ai-postgres2:5432`

**Key tables:**
- `users` - User records (username = email, stored as JSONB)
- `role` - Role definitions (name, key, application_id)
- `policy` - Policy definitions (allowed actions per application)
- `rolepolicy` - Maps roles to policies
- `principalrole` - Maps users to roles (entity_id = user.id, principal_type=1)
- `application` - Application definitions (RBAC, CFO Insights, Expense Management, etc.)
- `applicationrole` - Maps roles to applications for the RBAC admin UI

## Prerequisites

- `kubectl` access to the target cluster (admin context)
- User must exist in `users` table — either auto-created on first SSO login, or pre-inserted manually (see [Procedure 0](#0-pre-create-users-before-first-sso-login))
- Know the user's email address (used as username)
- Know which roles to assign (see Role Definitions below)

## Role Definitions

### Platform Roles (Application ID: 1 - RBAC)

#### RBAC-ROOT (role_id: 1)
**Description:** RBAC system administrator role  
**Application:** RBAC (app_id: 1)  
**Use case:** Platform administrators, DevOps engineers, commonly assigned as default role via `DEFAULT_ROLE_KEY: RBAC-ROOT`  
**Permissions (RBAC administration only):**
- Full CRUD on applications, policies, roles, users, organizations
- Assign/revoke roles
- Manage external users via Deloitte CIAM
- View and manage user groups
- Configure allowed origins

**Policy:** `RBAC-Policy` (policy_id: 1)

**Important:** RBAC-ROOT only grants `RBAC:*` permissions (RBAC system administration). It does **NOT** grant `Zora:*` permissions (application features like workspace/conversation creation). Users need additional application-specific roles (operational_finance, senior_finance_leadership, etc.) to access Zora AI features.

**DEFAULT_ROLE_KEY configuration:**
`DEFAULT_ROLE_KEY` is set as an environment variable in the RBAC backend values files:
- `kubernetes/azure/<env>/values-zora-ai-rbac-backend.yaml` → `deployment.env.DEFAULT_ROLE_KEY`
- All deployed environments (dev2, dev3, qa, demo, lab, perf, colgate, nvidia/dev2, nvidia/qa): `RBAC-ROOT`
- Local development (comserv-rbac `.env`): `RBAC-END-USER` (see `aiq-zora-ai-frontend/docs/LOCAL-DEVELOPMENT.md`)
- dev4: No RBAC deployed

In deployed environments, users are auto-assigned RBAC-ROOT on first SSO login, which gives them authentication + RBAC admin capabilities. They still need application-specific roles for Zora feature access.

#### RBAC-END-USER (role_id: 2)
**Description:** Read-only access to RBAC configuration, minimum role for authentication  
**Application:** RBAC (app_id: 1)  
**Use case:** Users who need to view permission structure without modifying, minimal base role  
**Permissions (read-only RBAC access):**
- View policies, roles, role-policy mappings
- View users, user groups, organizations
- **Cannot:** Create, update, or delete any RBAC resources

**Policy:** `RBAC-End-User-Policy` (policy_id: 2)

**Important:** RBAC-END-USER is the minimum role required for authentication. When the Zora backend calls RBAC `GET /user` to validate a token, RBAC returns 403 if the user has no role — the backend surfaces this as `"no RBAC-END-USER role detected"` (see `aiq-zora-ai-backend/app/api/dependencies.py`, `get_current_user()`). Like RBAC-ROOT, it only grants `RBAC:View*` permissions and does NOT grant `Zora:*` permissions. Users need additional application-specific roles to access Zora AI features.

**Source:** `aiq-zora-ai-frontend/docs/LOCAL-DEVELOPMENT.md`: *"`DEFAULT_ROLE_KEY` must be `'RBAC-END-USER'` — this is the role the backend checks for."*

### Finance Module Roles

#### senior_finance_leadership (role_id: 3)
**Description:** Executive-level access to CFO Insights  
**Application:** CFO Insights (app_id: 3)  
**Permissions:**
- Create workspaces
- Create conversations
- Access Performance Pulse feature

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2) - View RBAC settings
- `CFO Insights Module Access Policy` (policy_id: 3) - CFO features

#### operational_finance (role_id: 4)
**Description:** Expense Specialist - operational finance team members  
**Application:** Expense Management Advisor (app_id: 4)  
**Use case:** Users querying travel & entertainment (T&E) expense data  
**Permissions:**
- Create workspaces
- Create conversations
- Query expense data (T&E, travel by region, cost analysis)

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2)
- `Expense Management Advisor Module Access Policy` (policy_id: 4)

#### financial_reporting_analyst (role_id: 5)
**Description:** Analyst with access to both CFO Insights and Expense Management  
**Applications:** CFO Insights (app_id: 3) + Expense Management (app_id: 4)  
**Use case:** Cross-functional financial analysts  
**Permissions:**
- All permissions from CFO Insights module
- All permissions from Expense Management module

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2)
- `CFO Insights Module Access Policy` (policy_id: 3)
- `Expense Management Advisor Module Access Policy` (policy_id: 4)

#### collections_manager (role_id: 6)
**Description:** Collections advisory module access  
**Application:** Collections Advisor (app_id: 5)  
**Permissions:**
- Create workspaces

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2)
- `Collections Advisor Module Access Policy` (policy_id: 5)

#### payments_manager (role_id: 7)
**Description:** Payments advisory module access  
**Application:** Payments Advisor (app_id: 6)  
**Permissions:**
- Create workspaces

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2)
- `Payments Advisor Module Access Policy` (policy_id: 6)

#### forward_deployment_engineer (role_id: 8)
**Description:** FDE with configuration editing capabilities across all applications  
**Application:** All applications (app_id: "*")  
**Permissions:**
- Edit configuration across all modules

**Policies:**
- `RBAC-End-User-Policy` (policy_id: 2)
- `Forward Deployment Engineer Policy` (policy_id: 7)

## Common Role Combinations

**Role architecture:** Users need a **base RBAC role** (for authentication) + **application-specific roles** (for feature access).

**Base RBAC roles (choose one):**
- `RBAC-ROOT` (role_id: 1) - RBAC administration + authentication (most common, auto-assigned in most envs)
- `RBAC-END-USER` (role_id: 2) - Read-only RBAC + authentication (minimal)

**Application roles** grant Zora:* permissions for specific modules:
- `operational_finance` (role_id: 4) - Expense Management queries
- `senior_finance_leadership` (role_id: 3) - CFO Insights
- `financial_reporting_analyst` (role_id: 5) - CFO Insights + Expense Management
- `collections_manager` (role_id: 6) - Collections Advisor
- `payments_manager` (role_id: 7) - Payments Advisor
- `forward_deployment_engineer` (role_id: 8) - Configuration editing across all apps

**Typical combinations:**

**Expense Management user (T&E queries):**
- `RBAC-ROOT` + `operational_finance`

**CFO + Expense analyst:**
- `RBAC-ROOT` + `financial_reporting_analyst` (grants both CFO Insights and Expense Management)

**Frontend access only (no data queries):**
- `RBAC-END-USER` (can authenticate but cannot create workspaces/conversations)

**Full finance suite:**
- `RBAC-ROOT` + `senior_finance_leadership` + `operational_finance` + `financial_reporting_analyst`

**FDE with config access:**
- `RBAC-ROOT` + `forward_deployment_engineer`

## Procedures

### 0. Pre-create users before first SSO login

Users are normally auto-created on first SSO login (`ALLOW_AUTO_USER_CREATION: "true"`). You can pre-insert them to have roles ready the moment they log in.

**How it works:** The auth service checks if the username already exists before inserting. If a pre-created user logs in via SSO, the service finds the existing record and skips re-creation — their pre-assigned roles are immediately active.

**Insert user and assign roles in one shot:**

```bash
# Step 1: insert the user row
kubectl exec -n $NAMESPACE zora-ai-postgres-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO users (principal_type, resource)
VALUES (1, '{
  \"resourceType\": \"User\",
  \"username\": \"newuser@deloitte.com\",
  \"userAttributes\": {
    \"name\": \"Last, First\",
    \"email\": \"newuser@deloitte.com\"
  },
  \"details\": {},
  \"metadata\": {
    \"versionId\": 1,
    \"createdDate\": \"$(date -u +%Y-%m-%dT%H:%M:%S.000Z)\",
    \"updatedDate\": \"$(date -u +%Y-%m-%dT%H:%M:%S.000Z)\",
    \"createdBy\": \"admin\",
    \"updatedBy\": \"admin\"
  }
}')
RETURNING id, resource->>'\''username'\'' as email;
"

# Step 2: assign roles using the returned id (e.g. id=42)
USER_ID="42"
kubectl exec -n $NAMESPACE zora-ai-postgres-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
VALUES
  ($USER_ID, 1, 1, CURRENT_TIMESTAMP, 'admin'),  -- RBAC-ROOT
  ($USER_ID, 1, 4, CURRENT_TIMESTAMP, 'admin');   -- e.g. operational_finance
"
```

**Pre-create multiple users with identical roles (e.g. match an existing user):**

```bash
# Get role IDs from the reference user
kubectl exec -n $NAMESPACE zora-ai-postgres-0 -c postgres -- psql -U postgres -d rbac_db -c "
SELECT pr.role_id, r.resource->>'role_key' as role_key
FROM users u
JOIN principalrole pr ON u.id = pr.entity_id AND pr.principal_type = 1 AND pr.revoked_at IS NULL
JOIN role r ON pr.role_id = r.id
WHERE u.resource->>'username' = 'reference@deloitte.com'
ORDER BY pr.role_id;
"

# Insert both users at once, then bulk-assign roles with CROSS JOIN
kubectl exec -n $NAMESPACE zora-ai-postgres-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO users (principal_type, resource) VALUES
  (1, '{\"resourceType\":\"User\",\"username\":\"user1@deloitte.com\",\"userAttributes\":{\"name\":\"Last1, First1\",\"email\":\"user1@deloitte.com\"},\"details\":{},\"metadata\":{\"versionId\":1,\"createdDate\":\"2026-01-01T00:00:00.000Z\",\"updatedDate\":\"2026-01-01T00:00:00.000Z\",\"createdBy\":\"admin\",\"updatedBy\":\"admin\"}}'),
  (1, '{\"resourceType\":\"User\",\"username\":\"user2@deloitte.com\",\"userAttributes\":{\"name\":\"Last2, First2\",\"email\":\"user2@deloitte.com\"},\"details\":{},\"metadata\":{\"versionId\":1,\"createdDate\":\"2026-01-01T00:00:00.000Z\",\"updatedDate\":\"2026-01-01T00:00:00.000Z\",\"createdBy\":\"admin\",\"updatedBy\":\"admin\"}}')
RETURNING id, resource->>'username' as email;
"

# Bulk-assign roles — replace (10),(11) with returned IDs, and role IDs from the reference query above
kubectl exec -n $NAMESPACE zora-ai-postgres-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
SELECT u.id, 1, r.role_id, CURRENT_TIMESTAMP, 'admin'
FROM (VALUES (10), (11)) AS u(id)
CROSS JOIN (VALUES (1),(2),(3),(4),(5),(6),(7),(8),(11),(12),(13),(14),(15),(16),(17),(18)) AS r(role_id);
"
```

**Note:** The postgres pod name varies by cluster — use `zora-ai-postgres-0` (demo-wus, demo, lab) or `zora-ai-postgres2-0` (dev2, dev3, qa, perf). Check with `kubectl get pods -n $NAMESPACE | grep postgres`.

### 1. Connect to RBAC database

Set cluster context and environment:

```bash
CLUSTER="qa"  # or dev2, dev3, demo, lab, perf

# demo and lab use "eus" instead of "eus2" in the context name
if [[ "$CLUSTER" == "demo" || "$CLUSTER" == "lab" ]]; then
  CONTEXT="zoraai-${CLUSTER}-eus-internal-admin"
else
  CONTEXT="zoraai-${CLUSTER}-eus2-internal-admin"
fi

NAMESPACE="zora-ai-${CLUSTER}"

# Context examples:
# dev2/dev3/qa/perf: zoraai-${CLUSTER}-eus2-internal-admin
# demo/lab:          zoraai-${CLUSTER}-eus-internal-admin
```

### 2. Find user ID by email

```bash
kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
SELECT id, resource->>'username' as email, resource->>'name' as name
FROM users
WHERE resource->>'username' = 'user@deloitte.com';
"
```

**Note:** `username` field stores the email address.

### 3. Check current user roles

```bash
USER_ID="42"  # Replace with ID from step 2

kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
SELECT 
  u.id,
  u.resource->>'username' as email,
  r.id as role_id,
  r.resource->>'role_key' as role_key,
  r.resource->>'role_name' as role_name,
  pr.assigned_at
FROM users u
LEFT JOIN principalrole pr ON u.id = pr.entity_id 
  AND pr.principal_type = 1 
  AND pr.revoked_at IS NULL
LEFT JOIN role r ON pr.role_id = r.id
WHERE u.id = $USER_ID
ORDER BY r.resource->>'role_key';
"
```

### 4. Assign a role to a user

```bash
USER_ID="42"          # User to assign role to
ROLE_ID="4"           # Role to assign (e.g., 4 = operational_finance)

kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
VALUES ($USER_ID, 1, $ROLE_ID, CURRENT_TIMESTAMP, 'admin');
"
```

**Expected output:** `INSERT 0 1`

**principal_type values:**
- `1` = User
- `2` = User Group
- `3` = Organization

### 5. Verify role assignment

Run the query from step 3 again to confirm the role appears.

### 6. Assign multiple roles at once

```bash
USER_ID="42"

kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
VALUES 
  ($USER_ID, 1, 1, CURRENT_TIMESTAMP, 'admin'),  -- RBAC-ROOT
  ($USER_ID, 1, 4, CURRENT_TIMESTAMP, 'admin'),  -- operational_finance
  ($USER_ID, 1, 5, CURRENT_TIMESTAMP, 'admin');  -- financial_reporting_analyst
"
```

### 7. Remove a role from a user

**Soft delete (recommended):**
```bash
USER_ID="42"
ROLE_ID="4"

kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
UPDATE principalrole
SET revoked_at = CURRENT_TIMESTAMP
WHERE entity_id = $USER_ID 
  AND principal_type = 1 
  AND role_id = $ROLE_ID 
  AND revoked_at IS NULL;
"
```

**Hard delete (use with caution):**
```bash
kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
DELETE FROM principalrole
WHERE entity_id = $USER_ID 
  AND principal_type = 1 
  AND role_id = $ROLE_ID;
"
```

### 8. View all users and their roles (summary)

```bash
kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
SELECT 
  u.id,
  u.resource->>'username' as email,
  array_agg(r.resource->>'role_key' ORDER BY r.resource->>'role_key') as roles
FROM users u
LEFT JOIN principalrole pr ON u.id = pr.entity_id 
  AND pr.principal_type = 1 
  AND pr.revoked_at IS NULL
LEFT JOIN role r ON pr.role_id = r.id
GROUP BY u.id, u.resource->>'username'
ORDER BY u.resource->>'username';
"
```

## Example: Grant Expense Management Access

**Scenario:** User needs to query travel & entertainment expense data in QA.

**Required roles:**
- `RBAC-ROOT` or `RBAC-END-USER` (role_id: 1 or 2) - Base RBAC role for authentication (Layer 1). Auto-assigned via `DEFAULT_ROLE_KEY` in `values-zora-ai-rbac-backend.yaml`.
- `operational_finance` (role_id: 4) - Application role granting `Zora:WorkspaceCreate` and `Zora:ConversationCreate` for Expense Management app_id: 4 (Layer 2). Checked by backend via `require_authorization("Zora:ConversationCreate")` in `aiq-zora-ai-backend/app/api/v1/endpoints/conversation.py`.

**Steps:**

1. User logs in via SSO → auto-created in `users` table
2. Find user ID:
   ```bash
   kubectl exec -n zora-ai-qa zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
   SELECT id FROM users WHERE resource->>'username' = 'user-a@deloitte.com';
   "
   ```
   Output: `id = 42`

3. Assign roles:
   ```bash
   kubectl exec -n zora-ai-qa zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
   INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
   VALUES 
     (42, 1, 1, CURRENT_TIMESTAMP, 'admin'),
     (42, 1, 4, CURRENT_TIMESTAMP, 'admin');
   "
   ```

4. User logs out and back in → JWT includes new roles → can query expense data

## Example: Match Another User's Roles

**Scenario:** Grant User B the same roles as User A.

1. Find both user IDs and check User A's roles:
   ```bash
   kubectl exec -n zora-ai-qa zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
   SELECT 
     u.id,
     u.resource->>'username' as email,
     array_agg(r.id ORDER BY r.id) as role_ids,
     array_agg(r.resource->>'role_key' ORDER BY r.id) as role_keys
   FROM users u
   LEFT JOIN principalrole pr ON u.id = pr.entity_id 
     AND pr.principal_type = 1 
     AND pr.revoked_at IS NULL
   LEFT JOIN role r ON pr.role_id = r.id
   WHERE u.resource->>'username' IN ('user-a@deloitte.com', 'user-b@deloitte.com')
   GROUP BY u.id, u.resource->>'username';
   "
   ```
   
   Output shows User A (id: 42) has roles [1, 4, 5].

2. Assign missing roles to User B (id: 136):
   ```bash
   kubectl exec -n zora-ai-qa zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
   INSERT INTO principalrole (entity_id, principal_type, role_id, assigned_at, assigned_by)
   VALUES 
     (136, 1, 4, CURRENT_TIMESTAMP, 'admin'),  -- operational_finance
     (136, 1, 5, CURRENT_TIMESTAMP, 'admin');  -- financial_reporting_analyst
   "
   ```

## Troubleshooting

### User not found in database
**Symptom:** Query returns 0 rows for user email.

**Cause:** User hasn't logged in via SSO yet.

**Solution:** User must log in once to trigger auto-creation (if `ALLOW_AUTO_USER_CREATION: "true"`).

### Duplicate key error when assigning role
**Symptom:** `ERROR: duplicate key value violates unique constraint`

**Cause:** User already has that role assigned.

**Solution:** Check current roles (step 3). If `revoked_at IS NOT NULL`, the role was soft-deleted. Either hard-delete and re-insert, or update `revoked_at` to NULL:

```bash
kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
UPDATE principalrole
SET revoked_at = NULL
WHERE entity_id = $USER_ID 
  AND principal_type = 1 
  AND role_id = $ROLE_ID;
"
```

### User has role but still sees "No data available"
**Symptom:** User can access frontend but gets empty results or errors.

**Causes:**
1. JWT token doesn't include new roles (user didn't re-login after role assignment)
2. Backend service (e.g., EM2) has bugs in error handling (false error messages)
3. User needs additional application-specific roles

**Solution:**
1. User must log out and back in to get fresh JWT with updated roles
2. Check backend service logs for actual errors vs false positives
3. Verify user has the correct application-specific role (e.g., `operational_finance` for expense queries)

### Finding which role grants a specific permission
**Symptom:** Need to determine which role allows a user to perform action X.

**Solution:** Query role-policy mappings:

```bash
kubectl exec -n $NAMESPACE zora-ai-postgres2-0 -c postgres -- psql -U postgres -d rbac_db -c "
SELECT 
  r.id as role_id,
  r.resource->>'role_key' as role_key,
  r.resource->>'role_name' as role_name,
  p.id as policy_id,
  p.resource->>'name' as policy_name,
  p.resource->'resource_action'->0->'action' as actions
FROM role r
JOIN rolepolicy rp ON r.id = rp.role_id
JOIN policy p ON rp.policy_id = p.id
WHERE p.resource->'resource_action'->0->'action'::text LIKE '%WorkspaceCreate%';
"
```

Replace `%WorkspaceCreate%` with the action you're searching for.

## Security Best Practices

1. **Principle of least privilege:** Assign only the minimum roles needed
2. **Regular audits:** Periodically review user role assignments
3. **Soft delete:** Use `revoked_at` instead of hard deletes for audit trail
4. **Document assignments:** Record `assigned_by` with your admin username/ticket number
5. **Test in lower environments:** Verify role combinations in dev2 before applying to qa/demo/prod
6. **JWT refresh:** Remind users to log out/in after role changes (tokens cache for 1 hour)

## Related Files

- **RBAC backend values (per env):** `kubernetes/azure/<env>/values-zora-ai-rbac-backend.yaml` — `DEFAULT_ROLE_KEY`, OIDC config
- **Role seed script (canonical):** `aiq-zora-ai-backend/scripts/rbac_seed.py` — defines all applications, policies, roles, role-policy mappings, and application-role mappings
- **Role seed script (engine docker):** `aiq-zora-ai-engine/docker/seed_rbac_data.py` — subset used for local Docker Compose
- **Backend authorization:** `aiq-zora-ai-backend/app/api/dependencies.py` — `require_authorization()`, `get_current_user()`, action-to-service mapping
- **Backend conversation endpoint:** `aiq-zora-ai-backend/app/api/v1/endpoints/conversation.py` — `Depends(require_authorization("Zora:ConversationCreate"))`
- **Backend workspace service:** `aiq-zora-ai-backend/app/services/workspace_service.py` — `action="Zora:WorkspaceCreate"`
- **RBAC service source:** `comserv-rbac/` repo — authentication middleware, role service, authorization logic
- **Frontend SSO integration:** `aiq-zora-ai-frontend/docs/RBAC_SSO_INTEGRATION.md`
- **Local dev setup (with role assignment):** `aiq-zora-ai-frontend/docs/LOCAL-DEVELOPMENT.md` — Step 7 documents role assignment via REST API and direct SQL
- **Database schema (DDL):** `comserv-rbac/services/prepopulateService.ts` — table creation SQL

## References

- **comserv-rbac documentation:** [Internal Confluence](https://confluence.tools.deloitteinnovation.us/)
- **RBAC service endpoints:** `https://rbac-api.<env>.zoraai.eng.deloitte.com/docs`
- **Azure AD tenant:** `36da45f1-dd2c-4d1f-af13-5abe46b99921`
