# Zora AI - Client Deployment Guide

Welcome to the Zora AI deployment guide. This document will walk you through deploying Zora AI in your SAP BTP Kyma environment step by step.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Connect to SAP BTP Cluster](#2-connect-to-sap-btp-cluster)
3. [Verify Cluster Connection](#3-verify-cluster-connection)
4. [Configure Secrets](#4-configure-secrets)
5. [Configure DNS/Ingress](#5-configure-dnsingress)
6. [Adjust Resource Limits (Optional)](#6-adjust-resource-limits-optional)
7. [Deploy Infrastructure](#7-deploy-infrastructure)
8. [Deploy Applications](#8-deploy-applications)
9. [Verify Deployment](#9-verify-deployment)
10. [Troubleshooting](#10-troubleshooting)

---

## 1. Prerequisites

Before starting, ensure you have:

- ✅ **Terminal access** (macOS Terminal, Windows PowerShell, or Linux Terminal)
- ✅ **kubectl** installed ([Installation Guide](https://kubernetes.io/docs/tasks/tools/))
- ✅ **Helm** installed ([Installation Guide](https://helm.sh/docs/intro/install/))
- ✅ **VPN client** installed (GlobalProtect)
- ✅ **SAP BTP credentials** (username and password provided by your admin)

---

## 2. Connect to SAP BTP Cluster

### Step 2.1: Connect to VPN

1. Open **GlobalProtect VPN** client
2. Enter the VPN address:
   ```
   gpvpn.deloitteinnovation.us
   ```
3. Enter your credentials and connect
4. Wait for successful connection (green icon)

### Step 2.2: Download Cluster Configuration

Open your terminal and run:

```bash
curl -o ~/kubeconfig-kyma.yaml "https://kyma-env-broker.cp.kyma.cloud.sap/kubeconfig/XXXXXXX-xxxx-481D-864F-xxxxxxxxx"
```

### Step 2.3: Set Kubernetes Configuration

```bash
export KUBECONFIG=~/kubeconfig-kyma.yaml
```

> 💡 **Tip**: Add this line to your `~/.bashrc` or `~/.zshrc` file to make it permanent.

---

## 3. Verify Cluster Connection

### Step 3.1: Test Connection

```bash
kubectl cluster-info
```

You will be prompted to enter your **username** and **password**. Use your SAP BTP credentials.

### Step 3.2: Verify Namespace

After successful login, check if services are running:

```bash
kubectl get pods -n zora-ai-cfo
```

**Expected output for a fresh installation**: No resources found (this is normal for first-time deployment)

**Expected output for existing installation**:
```
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-backend-5677769455-cqght                1/1     Running     0          4d
zora-ai-configuration-server-5ccfb97b6b-gsgz7   1/1     Running     0          4d
zora-ai-frontend-6486b46f5d-rdf5d               1/1     Running     0          4d
zora-ai-postgres-0                              2/2     Running     0          4d
...
```

---

## 4. Configure Secrets

Secrets contain sensitive information like API keys and passwords. You **must** configure these before deployment.

### Step 4.1: Locate the Secrets File

Navigate to the secrets folder:
```
sap/dev/secrets/zora-ai-secrets.yaml
```

### Step 4.2: Values to Change

Open `zora-ai-secrets.yaml` and update the following sections:

#### 🔐 LLM Model Configuration (Section 4: Engine Secrets)

```yaml
# 4. Engine Secrets (1 key: AZURE_LLM_API_KEY)
apiVersion: v1
kind: Secret
metadata:
  name: zora-ai-engine-secrets
type: Opaque
stringData:
  AZURE_LLM_API_KEY: "YOUR_AZURE_OPENAI_API_KEY_HERE"    # ← Change this
```

#### 🔐 OIDC/SSO Configuration (Section 5: RBAC Backend Secrets)

```yaml
# 5. RBAC Backend Secrets (OIDC secrets)
apiVersion: v1
kind: Secret
metadata:
  name: zora-ai-rbac-secrets
type: Opaque
stringData:
  OIDC_CLIENTSECRET: "YOUR_AZURE_AD_CLIENT_SECRET_HERE"  # ← Change this
```

#### 🔐 Database Passwords (Optional - Section 2)

If you want custom database passwords, update:
```yaml
# 2. Postgres Secrets
stringData:
  postgres-password: "YOUR_STRONG_PASSWORD"
  postgres-read-password: "YOUR_STRONG_PASSWORD"
  developer-password: "YOUR_STRONG_PASSWORD"
```

### Step 4.3: Deploy Secrets

```bash
kubectl apply -f sap/dev/secrets/zora-ai-secrets.yaml -n zora-ai-cfo
```

### Step 4.4: Verify Secrets

```bash
kubectl get secrets -n zora-ai-cfo
```

You should see secrets like `zora-ai-postgres-secrets`, `zora-ai-engine-secrets`, etc.

---

## 5. Configure DNS/Ingress

Before deploying applications, you need to configure your DNS names.

### ❓ First, Ask Your SAP Admin

Contact your SAP BTP administrator and ask:
> "What ingress method does our cluster use - **Ingress Gateway**, **HTTPRoute**, or **Istio**?"

### 📝 Files to Update

Based on their answer, update DNS names in these files:

#### File 1: Frontend (`sap/dev/values-zora-ai-frontend.yaml`)

Find and update:
```yaml
ingress:
  enabled: true    # Set to 'true' for Ingress, 'false' for HTTPRoute
  hosts:
    - host: YOUR-FRONTEND-DOMAIN.example.com    # ← Change this
  tls:
    - hosts:
        - YOUR-FRONTEND-DOMAIN.example.com      # ← Change this

httpRoute:
  enabled: false   # Set to 'true' for HTTPRoute, 'false' for Ingress
  host: YOUR-FRONTEND-DOMAIN.example.com        # ← Change this
```

#### File 2: RBAC Frontend (`sap/dev/values-zora-ai-rbac-frontend.yaml`)

Find and update:
```yaml
ingress:
  enabled: true
  host: YOUR-RBAC-DOMAIN.example.com            # ← Change this

env:
  REACT_APP_API_URL: https://YOUR-RBAC-DOMAIN.example.com/api    # ← Change this
  REACT_CC_PROD_DOMAIN: YOUR-RBAC-DOMAIN.example.com             # ← Change this
```

#### File 3: RBAC Backend (`sap/dev/values-zora-ai-rbac-backend.yaml`)

Find and update:
```yaml
env:
  ISSUER: https://YOUR-RBAC-API-DOMAIN.example.com               # ← Change this
  JWT_ISSUER: https://YOUR-RBAC-API-DOMAIN.example.com           # ← Change this
  LOCALHOST_ENDPOINT: https://YOUR-FRONTEND-DOMAIN.example.com/sso/callback
  ALLOWED_AUDIENCES: https://YOUR-RBAC-API-DOMAIN.example.com
  OIDC_CALLBACKURL: "https://YOUR-FRONTEND-DOMAIN.example.com/rbac/authentication/login/callback"

ingress:
  host: YOUR-RBAC-API-DOMAIN.example.com        # ← Change this
  tls:
    - hosts:
        - YOUR-RBAC-API-DOMAIN.example.com      # ← Change this
```

#### File 4: API Proxy (`sap/dev/rbac-api-proxy/ingress.yaml`)

Find and update:
```yaml
spec:
  tls:
    - hosts:
        - YOUR-RBAC-DOMAIN.example.com          # ← Change this
  rules:
    - host: YOUR-RBAC-DOMAIN.example.com        # ← Change this
```

---

## 6. Adjust Resource Limits (Optional)

The default resource limits in the values files are set conservatively (minimal CPU and memory). **You can increase these based on your environment's capacity and workload requirements.**

### Where to Find Resource Limits

Resource limits are defined in each service's values file under the `resources` section:

```yaml
resources:
  requests:
    memory: "256Mi"
    cpu: "100m"
  limits:
    memory: "512Mi"
    cpu: "500m"
```

### Recommended Adjustments

For production environments with higher workloads, consider increasing resources in these values files:

| Service | Values File | Recommended Memory Limit |
|---------|-------------|-------------------------|
| AI Engine | `values-zora-ai-engine.yaml` | 2Gi - 4Gi |
| Backend | `values-zora-ai-backend.yaml` | 1Gi - 2Gi |
| PostgreSQL | `values-zora-ai-postgres.yaml` | 2Gi - 4Gi |
| Redis | `values-zora-ai-redis.yaml` | 1Gi - 2Gi |
| Frontend | `values-zora-ai-frontend.yaml` | 512Mi - 1Gi |

> 💡 **Tip**: Monitor your pods after deployment using `kubectl top pods -n zora-ai-cfo` to understand actual resource usage and adjust accordingly.

---

## 7. Deploy Infrastructure

Deploy services in this order. Wait for each to be ready before proceeding.

### Step 6.1: PostgreSQL Database

```bash
helm upgrade --install zora-ai-postgres charts/zora-ai-postgres \
  -f sap/dev/values-zora-ai-postgres.yaml \
  -n zora-ai-cfo
```

**Wait for database to be ready:**
```bash
kubectl get pods -n zora-ai-cfo -w
```
Wait until `zora-ai-postgres-0` shows `2/2 Running`

### Step 6.2: Redis Cache

```bash
helm upgrade --install zora-ai-redis charts/zora-ai-redis \
  -f sap/dev/values-zora-ai-redis.yaml \
  -n zora-ai-cfo
```

**Wait for Redis to be ready:**
```bash
kubectl get pods -n zora-ai-cfo | grep redis
```
Wait until all Redis pods show `Running`

### Step 6.3: Initialize Database

```bash
helm upgrade --install zora-ai-postgres-init-db charts/zora-ai-jobs \
  -f sap/dev/values-zora-ai-postgres-init-db.yaml \
  -n zora-ai-cfo
```

### Step 6.4: Load Agent Skills

```bash
helm upgrade --install zora-agent-skills charts/zora-ai-jobs \
  -f sap/dev/values-zora-agent-skills.yaml \
  -n zora-ai-cfo
```

---

## 8. Deploy Applications

Deploy applications in this order:

### Step 7.1: Configuration Server

```bash
helm upgrade --install zora-ai-configuration-server charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-configuration-server.yaml \
  -n zora-ai-cfo
```

### Step 7.2: Customer Data Server

```bash
helm upgrade --install zora-ai-customer-data-server charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-customer-data-server.yaml \
  -n zora-ai-cfo
```

### Step 7.3: AI Engine

```bash
helm upgrade --install zora-ai-engine charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-engine.yaml \
  -n zora-ai-cfo
```

### Step 7.4: Backend API

```bash
helm upgrade --install zora-ai-backend charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-backend.yaml \
  -n zora-ai-cfo
```

### Step 7.5: Frontend

```bash
helm upgrade --install zora-ai-frontend charts/zora-ai-universal-chart \
  -f sap/dev/values-zora-ai-frontend.yaml \
  -n zora-ai-cfo
```

### Step 7.6: RBAC Services

```bash
# RBAC Backend
helm upgrade --install zora-ai-rbac-app charts/zora-ai-rbac-app \
  -f sap/dev/values-zora-ai-rbac-backend.yaml \
  -n zora-ai-cfo

# RBAC Backend UI
helm upgrade --install zora-ai-rbac-app-ui charts/zora-ai-rbac-app \
  -f sap/dev/values-zora-ai-rbac-backend-ui.yaml \
  -n zora-ai-cfo

# RBAC Frontend
helm upgrade --install zora-ai-rbac-ui charts/zora-ai-rbac-ui \
  -f sap/dev/values-zora-ai-rbac-frontend.yaml \
  -n zora-ai-cfo
```

### Step 7.7: Deploy API Proxy

```bash
kubectl apply -f sap/dev/rbac-api-proxy/ingress.yaml -n zora-ai-cfo
```

### Step 7.8: Backup Job (Optional)

```bash
helm upgrade --install zora-ai-postgres-backup charts/zora-ai-jobs \
  -f sap/dev/values-zora-ai-postgres-backup.yaml \
  -n zora-ai-cfo
```

---

## 9. Verify Deployment

### Check All Pods

```bash
kubectl get pods -n zora-ai-cfo
```

**Expected output** - All pods should show `Running` or `Completed`:
```
NAME                                            READY   STATUS      RESTARTS   AGE
zora-ai-backend-xxxxx                           1/1     Running     0          5m
zora-ai-configuration-server-xxxxx              1/1     Running     0          10m
zora-ai-customer-data-server-xxxxx              1/1     Running     0          9m
zora-ai-engine-xxxxx                            1/1     Running     0          8m
zora-ai-frontend-xxxxx                          1/1     Running     0          6m
zora-ai-postgres-0                              2/2     Running     0          15m
zora-ai-rbac-app-xxxxx                          1/1     Running     0          4m
zora-ai-rbac-app-ui-xxxxx                       1/1     Running     0          3m
zora-ai-rbac-ui-xxxxx                           1/1     Running     0          2m
zora-ai-redis-0                                 2/2     Running     0          14m
zora-ai-redis-1                                 2/2     Running     0          13m
```

### Access Your Application

Open your browser and navigate to your configured frontend URL:
- **Main Application**: `https://YOUR-FRONTEND-DOMAIN.example.com`
- **RBAC Management**: `https://YOUR-RBAC-DOMAIN.example.com`

---

## 10. Troubleshooting

### Pod Not Starting?

Check pod events:
```bash
kubectl describe pod <pod-name> -n zora-ai-cfo
```

### Check Logs

```bash
kubectl logs <pod-name> -n zora-ai-cfo --tail=100
```

### Restart a Deployment

```bash
kubectl rollout restart deployment <deployment-name> -n zora-ai-cfo
```

### Delete and Redeploy

```bash
helm uninstall <release-name> -n zora-ai-cfo
helm upgrade --install <release-name> <chart> -f <values-file> -n zora-ai-cfo
```

### Common Issues

| Issue | Solution |
|-------|----------|
| Pod stuck in `Pending` | Check if secrets are deployed: `kubectl get secrets -n zora-ai-cfo` |
| Pod in `CrashLoopBackOff` | Check logs: `kubectl logs <pod-name> -n zora-ai-cfo` |
| Cannot connect to database | Ensure PostgreSQL pod is running and secrets are correct |
| SSO not working | Verify OIDC settings and callback URLs match your DNS |

---

## Quick Reference - Deployment Order

| # | Component | Command |
|---|-----------|---------|
| 1 | Secrets | `kubectl apply -f sap/dev/secrets/zora-ai-secrets.yaml -n zora-ai-cfo` |
| 2 | PostgreSQL | `helm upgrade --install zora-ai-postgres charts/zora-ai-postgres -f sap/dev/values-zora-ai-postgres.yaml -n zora-ai-cfo` |
| 3 | Redis | `helm upgrade --install zora-ai-redis charts/zora-ai-redis -f sap/dev/values-zora-ai-redis.yaml -n zora-ai-cfo` |
| 4 | Init DB | `helm upgrade --install zora-ai-postgres-init-db charts/zora-ai-jobs -f sap/dev/values-zora-ai-postgres-init-db.yaml -n zora-ai-cfo` |
| 5 | Agent Skills | `helm upgrade --install zora-agent-skills charts/zora-ai-jobs -f sap/dev/values-zora-agent-skills.yaml -n zora-ai-cfo` |
| 6 | Config Server | `helm upgrade --install zora-ai-configuration-server charts/zora-ai-universal-chart -f sap/dev/values-zora-ai-configuration-server.yaml -n zora-ai-cfo` |
| 7 | Customer Data | `helm upgrade --install zora-ai-customer-data-server charts/zora-ai-universal-chart -f sap/dev/values-zora-ai-customer-data-server.yaml -n zora-ai-cfo` |
| 8 | Engine | `helm upgrade --install zora-ai-engine charts/zora-ai-universal-chart -f sap/dev/values-zora-ai-engine.yaml -n zora-ai-cfo` |
| 9 | Backend | `helm upgrade --install zora-ai-backend charts/zora-ai-universal-chart -f sap/dev/values-zora-ai-backend.yaml -n zora-ai-cfo` |
| 10 | Frontend | `helm upgrade --install zora-ai-frontend charts/zora-ai-universal-chart -f sap/dev/values-zora-ai-frontend.yaml -n zora-ai-cfo` |
| 11 | RBAC Backend | `helm upgrade --install zora-ai-rbac-app charts/zora-ai-rbac-app -f sap/dev/values-zora-ai-rbac-backend.yaml -n zora-ai-cfo` |
| 12 | RBAC Backend UI | `helm upgrade --install zora-ai-rbac-app-ui charts/zora-ai-rbac-app -f sap/dev/values-zora-ai-rbac-backend-ui.yaml -n zora-ai-cfo` |
| 13 | RBAC Frontend | `helm upgrade --install zora-ai-rbac-ui charts/zora-ai-rbac-ui -f sap/dev/values-zora-ai-rbac-frontend.yaml -n zora-ai-cfo` |
| 14 | API Proxy | `kubectl apply -f sap/dev/rbac-api-proxy/ingress.yaml -n zora-ai-cfo` |
| 15 | Backup (optional) | `helm upgrade --install zora-ai-postgres-backup charts/zora-ai-jobs -f sap/dev/values-zora-ai-postgres-backup.yaml -n zora-ai-cfo` |

---

## Need Help?

Contact your deployment support team if you encounter any issues not covered in this guide.

---

*Document Version: 1.0 | Last Updated: May 2026*
