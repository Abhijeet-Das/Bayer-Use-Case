# Runbook: Update LoadBalancer IP and DNS for Postgres / Redis

Use this runbook whenever a Postgres or Redis Kubernetes service needs to be (re-)created and the Azure DNS A record must point to the new IP. This happens during:

- Initial provisioning of a new environment
- Migration from legacy Postgres to `zora-ai-postgres2` (see [postgres-migration-plan.md](postgres-migration-plan.md))
- Disaster-recovery re-creation of a service that lost its static IP reservation

> **DNS records are managed manually.** `external-dns` only manages ingress records. Postgres and Redis use static `loadBalancerIP` + hand-crafted DNS A records.

---

## Background — Why a Two-Phase Deploy

Azure's internal Load Balancer assigns an IP from the subnet's available pool when the service is first created. You can *request* a specific IP via `loadBalancerIP`, but if you do this before you know which IP is free, the request may fail or grab an IP already in use elsewhere.

The safe workflow is:

1. Deploy the service **without** `loadBalancerIP` → Azure picks a free IP automatically.
2. Record that IP.
3. Redeploy the service **with** `loadBalancerIP: "<that IP>"` → Azure pins it. From this point the IP is static as long as the service exists.
4. Update the Azure DNS A record to match.

---

## Variables (set per environment)

```bash
# Kubectl context for the target cluster
CTX=zoraai-dev03-eus2-internal-admin

# Namespace
NS=zora-ai-dev03

# Azure subscription, DNS zone, and resource group — per environment:
#
# Env   | Subscription ID                      | DNS Zone                          | Resource Group
# -------|--------------------------------------|-----------------------------------|------------------------------------
# dev02  | 118ef975-05a3-457c-b030-e4339fc17e63 | dev02.zoraai.deloitteinnovation.us | zoraai-dev02-eus2-common-services
# dev03  | 118ef975-05a3-457c-b030-e4339fc17e63 | dev03.zoraai.eng.deloitte.com      | zoraaidev03-eus2-common-services
# dev04  | 118ef975-05a3-457c-b030-e4339fc17e63 | dev04.zoraai.eng.deloitte.com      | zoraaidev04-eus2-common-services
# qa     | 118ef975-05a3-457c-b030-e4339fc17e63 | qa.zoraai.eng.deloitte.com         | zoraaiqa-eus2-common-services
# demo   | 1290e250-22da-4641-af7b-a4d52c4030ec | demo.zoraai.eng.deloitte.com       | zoraaidemo-eus-common-services
# perf   | 1290e250-22da-4641-af7b-a4d52c4030ec | perf.zoraai.eng.deloitte.com       | zoraaiperf-eus-common-services
# lab    | b226af89-5b86-4295-8f37-d2e48ccf43b2 | lab.zoraai.eng.deloitte.com        | zoraailab-eus-common-services
AZ_SUB="118ef975-05a3-457c-b030-e4339fc17e63"
AZ_DNS_ZONE="dev03.zoraai.eng.deloitte.com"
AZ_RG="zoraaidev03-eus2-common-services"

# Service name in Kubernetes (e.g. zora-ai-postgres2, zora-ai-redis-master)
K8S_SVC=zora-ai-postgres2

# DNS record name relative to the zone (see reference table below)
# dev03 postgres → zora-ai-postgres, redis → zora-ai-redis
DNS_RECORD_NAME=zora-ai-postgres
```

---

## Step 1 — Deploy service without `loadBalancerIP`

In the relevant values file, ensure the service block does **not** have `loadBalancerIP`:

**Postgres (`values-zora-ai-postgres2.yaml`):**
```yaml
service:
  type: LoadBalancer
  port: 5432
  targetPort: 5432
  # loadBalancerIP: ""    ← omit or comment out entirely
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
```

**Redis — CloudPirates chart (`values-zora-ai-redis2.yaml`, used in dev03 redis2, qa, perf):**
```yaml
service:
  type: LoadBalancer
  # loadBalancerIP: ""    ← omit or comment out entirely
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
```

Commit and push. Wait for ArgoCD to sync and the service to receive an IP (typically 1–3 minutes):

```bash
kubectl --context $CTX -n $NS get svc $K8S_SVC -w
# Wait until EXTERNAL-IP column shows an IP (not <pending>)
```

---

## Step 2 — Record the assigned IP

```bash
ASSIGNED_IP=$(kubectl --context $CTX -n $NS get svc $K8S_SVC \
  -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
echo "Assigned IP: $ASSIGNED_IP"
```

Note this IP — you will use it in Steps 3 and 4.

---

## Step 3 — Pin the IP in the values file and redeploy

Update the values file to include `loadBalancerIP` with the value from Step 2.

**Postgres:**
```yaml
service:
  type: LoadBalancer
  port: 5432
  targetPort: 5432
  loadBalancerIP: "10.x.x.x"          # ← IP from Step 2
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
```

**Redis — CloudPirates chart (`values-zora-ai-redis2.yaml`):**
```yaml
service:
  type: LoadBalancer
  loadBalancerIP: "10.x.x.x"          # ← IP from Step 2
  annotations:
    service.beta.kubernetes.io/azure-load-balancer-internal: "true"
```

Commit and push. ArgoCD will apply the change. Kubernetes sends a `PUT` to the Azure LB controller which pins the IP reservation. The service IP does **not** change (Azure keeps the same allocation if it's already assigned to this service).

Verify nothing changed:
```bash
kubectl --context $CTX -n $NS get svc $K8S_SVC
# EXTERNAL-IP should still show the same IP
```

---

## Step 4 — Update the Azure DNS A record

Identify the current record and update it. Use `az network dns record-set a` commands:

```bash
# Show the existing A record (confirm name and current IP)
az network dns record-set a show \
  --subscription "$AZ_SUB" \
  --resource-group "$AZ_RG" \
  --zone-name "$AZ_DNS_ZONE" \
  --name "$DNS_RECORD_NAME"
```

If the record exists and has the **old** IP:
```bash
# Remove the old IP
OLD_IP="10.x.x.x"   # whatever was there before
az network dns record-set a remove-record \
  --subscription "$AZ_SUB" \
  --resource-group "$AZ_RG" \
  --zone-name "$AZ_DNS_ZONE" \
  --record-set-name "$DNS_RECORD_NAME" \
  --ipv4-address "$OLD_IP"

# Add the new IP
az network dns record-set a add-record \
  --subscription "$AZ_SUB" \
  --resource-group "$AZ_RG" \
  --zone-name "$AZ_DNS_ZONE" \
  --record-set-name "$DNS_RECORD_NAME" \
  --ipv4-address "$ASSIGNED_IP"
```

If the record does **not** exist yet (new environment):
```bash
az network dns record-set a add-record \
  --subscription "$AZ_SUB" \
  --resource-group "$AZ_RG" \
  --zone-name "$AZ_DNS_ZONE" \
  --record-set-name "$DNS_RECORD_NAME" \
  --ipv4-address "$ASSIGNED_IP" \
  --ttl 300
```

Verify:
```bash
az network dns record-set a show \
  --subscription "$AZ_SUB" \
  --resource-group "$AZ_RG" \
  --zone-name "$AZ_DNS_ZONE" \
  --name "$DNS_RECORD_NAME" \
  --query "ARecords[].ipv4Address" -o tsv
# Should print: 10.x.x.x  (the new IP)
```

> **TTL note:** Azure DNS records default to TTL 3600s (1 hour). For infra records like postgres/redis that are rarely updated, this is fine. If you anticipate needing to change the IP again soon (e.g. during an iterative migration), lower the TTL to 60–300s *before* the change, wait for the current TTL to expire, then update the IP. After the change stabilises, raise TTL back to 3600s. In-cluster apps are not affected by TTL (they use k8s DNS, not Azure DNS), but cross-cluster clients are.
>
> To update TTL without changing the IP:
> ```bash
> az network dns record-set a update \
>   --subscription "$AZ_SUB" \
>   --resource-group "$AZ_RG" \
>   --zone-name "$AZ_DNS_ZONE" \
>   --name "$DNS_RECORD_NAME" \
>   --set ttl=3600
> ```

---

## Step 5 — Verify end-to-end connectivity

**From inside the cluster** (use a debug pod or exec into a running pod):
```bash
# Postgres
kubectl --context $CTX -n $NS run -it --rm debug \
  --image=postgres:17 --restart=Never -- \
  psql -h zora-ai-postgres2 -U postgres -c "SELECT version();"

# Redis
kubectl --context $CTX -n $NS run -it --rm debug \
  --image=redis:7 --restart=Never -- \
  redis-cli -h zora-ai-redis-master -a '<password>' ping
```

**From another cluster** (cross-cluster access uses the DNS record):
```bash
# Substitute the full DNS name for the target cluster
psql -h zora-ai-postgres2.$AZ_DNS_ZONE -U postgres -c "SELECT version();"
```

**Check apps are healthy** after any service disruption:
```bash
kubectl --context $CTX -n $NS get pods
kubectl --context $CTX -n $NS logs deploy/zora-ai-backend --tail=50 | grep -i error
```

---

## Current Static IPs (reference)

These are the IPs pinned in the values files as of the last update. Update this table whenever IPs change.

| Env | K8s Service | DNS Zone | DNS Record name | IP |
|-----|-------------|----------|-----------------|----|
| dev03 | `zora-ai-postgres2` | `dev03.zoraai.eng.deloitte.com` | `zora-ai-postgres` | `10.185.58.7` |
| dev03 | `zora-ai-postgres2` | `dev03.zoraai.eng.deloitte.com` | `zora-ai-synthetic-db` | `10.185.58.7` |
| dev03 | `zora-ai-redis2-master` | `dev03.zoraai.eng.deloitte.com` | `zora-ai-redis` | `10.185.58.16` |
| dev02 | `zora-ai-postgres2` | `dev02.zoraai.deloitteinnovation.us` | `zora-ai-postgres2` | `10.107.142.55` |
| dev02 | `zora-ai-redis2-master` | `dev02.zoraai.deloitteinnovation.us` | `zora-ai-redis` | `10.107.142.48` |
| demo  | `zora-ai-redis2-master` | `demo.zoraai.eng.deloitte.com` | `zora-ai-redis` | `10.185.252.10` |
| demo  | `zora-ai-synthetic-db` | `demo.zoraai.eng.deloitte.com` | `zora-ai-synthetic-db` | `10.185.252.18` |
| qa    | `zora-ai-postgres2` | `qa.zoraai.eng.deloitte.com` | `zora-ai-postgres` | `10.185.65.27` |
| qa    | `zora-ai-postgres2` | `qa.zoraai.eng.deloitte.com` | `zora-ai-synthetic-db` | `10.185.65.27` |
| qa    | `zora-ai-redis2-master` | `qa.zoraai.eng.deloitte.com` | `zora-ai-redis` | `10.185.65.15` |
| perf  | `zora-ai-postgres2` | `perf.zoraai.eng.deloitte.com` | `zora-ai-synthetic-db` | `10.185.252.144` |
| perf  | `zora-ai-redis2-master` | `perf.zoraai.eng.deloitte.com` | `zora-ai-redis` | `10.185.252.146` |

---

## Related Runbooks

- **[postgres-migration-plan.md](postgres-migration-plan.md)** — Full step-by-step guide for migrating apps from the legacy `postgresql-service` to `zora-ai-postgres2`. When running the QA migration, follow that runbook first, then return here after Step 7 (apps verified healthy) to pin `loadBalancerIP` in the values file and update the DNS A record.
