# Connecting to AWS EKS Clusters

Quick guide to get `kubectl` access to the Zora AI EKS clusters (SUT dev/qa) from any developer machine.

## Clusters

| Cluster | Region | Account | Namespace |
|---|---|---|---|
| `zoraai-sut-eus` (dev) | `us-east-1` | `618246140645` | `zora-ai-sut` |
| `zoraai-qa-sut-eus` (qa) | `us-east-1` | `618246140645` | `zora-ai-sut` |

The API endpoint is **private**, so you must be connected to the Deloitte VPN (`gpvpn.deloitteinnovation.us`) to reach it.

## Required tools

- **AWS CLI v2**: talks to AWS APIs
- **kubectl**: talks to Kubernetes
- **saml2aws**: gets temp AWS credentials via Okta SSO (Deloitte uses Okta, not AWS Identity Center, so plain `aws configure sso` does not apply)

## Check what you already have

Run these first. Skip the install step for any tool that prints a version.

```bash
aws --version            # AWS CLI v2.x, anything 2.x is fine
kubectl version --client # kubectl v1.x, anything 1.28+ is fine
saml2aws --version       # any recent version is fine
```

PowerShell users on Windows: same commands work.

If a tool is missing or shows v1, install it from the matching section below. Most developers already have `kubectl` and possibly `aws` from other projects, so usually only `saml2aws` needs to be installed.

Install paths differ by OS. Pick the section that matches your machine.

## Install (pick your path)

### macOS

```bash
brew install awscli kubectl
brew install --cask saml2aws       # or: brew tap versent/homebrew-taps && brew install saml2aws
```

Verify:
```bash
aws --version && kubectl version --client && saml2aws --version
```

### Linux

```bash
sudo apt update && sudo apt install -y unzip curl

# AWS CLI
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip && sudo ./aws/install && rm -rf aws awscliv2.zip

# kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
sudo install -o root -g root -m 0755 kubectl /usr/local/bin/kubectl && rm kubectl

# saml2aws
SAML2AWS_VERSION=$(curl -s https://api.github.com/repos/Versent/saml2aws/releases/latest | grep tag_name | cut -d'"' -f4 | sed 's/v//')
curl -L "https://github.com/Versent/saml2aws/releases/download/v${SAML2AWS_VERSION}/saml2aws_${SAML2AWS_VERSION}_linux_amd64.tar.gz" -o saml2aws.tar.gz
tar -xzf saml2aws.tar.gz -C /tmp && sudo mv /tmp/saml2aws /usr/local/bin/ && sudo chmod +x /usr/local/bin/saml2aws && rm saml2aws.tar.gz
```

### Windows, Option A: native PowerShell (no WSL needed)

If `winget` is allowed:
```powershell
winget install Amazon.AWSCLI
winget install Kubernetes.kubectl
winget install Versent.saml2aws
```

If `winget` / `choco` are blocked by IT policy, do a manual download (no admin needed):

1. **AWS CLI**: https://awscli.amazonaws.com/AWSCLIV2.msi → run installer
2. **kubectl**: https://kubernetes.io/releases → grab the latest stable Windows `kubectl.exe` → save to `C:\Users\<you>\bin\kubectl.exe`
3. **saml2aws**: https://github.com/Versent/saml2aws/releases/latest → download `saml2aws_*_windows_amd64.zip` → extract `saml2aws.exe` to `C:\Users\<you>\bin\`
4. Add `C:\Users\<you>\bin` to your user PATH:
   ```powershell
   [Environment]::SetEnvironmentVariable(
     "Path",
     [Environment]::GetEnvironmentVariable("Path", "User") + ";C:\Users\$env:USERNAME\bin",
     "User"
   )
   ```
5. **Restart PowerShell**, verify:
   ```powershell
   aws --version
   kubectl version --client
   saml2aws --version
   ```

### Windows, Option B: WSL (Ubuntu)

Use this if Windows-native installs are blocked or you prefer Linux tooling. This is the path most people on locked-down corporate Windows end up using.

#### B.1. Install WSL (one-time)

Open PowerShell **as administrator** and run:

```powershell
wsl --install
```

Reboot when prompted. After reboot, Ubuntu finishes setting up automatically and asks you to create a Linux username + password (this is local to WSL, unrelated to Deloitte credentials).

If WSL is already installed, just open it:

```powershell
wsl
```

#### B.2. Verify VPN reaches WSL

Before installing anything, make sure your Windows VPN routes propagate to WSL. Connect to the Deloitte VPN, then inside WSL run:

```bash
curl -v -k --max-time 5 https://415985EDDD7250FC8CA22B5344D6828F.gr7.us-east-1.eks.amazonaws.com 2>&1 | head -10
```

You want to see `Connected to ... (10.x.x.x) port 443`. If you see `Connection timed out` or `Could not resolve host`, fix this **before continuing** (see the WSL VPN gotcha below).

#### B.3. Install the tools

Inside WSL, run the **Linux** install steps from the section above (apt + AWS CLI + kubectl + saml2aws).

#### B.4. Continue with the common configuration

Skip down to "[One-time configuration (all OS)](#one-time-configuration-all-os)" and run those steps inside WSL.

> **WSL VPN gotcha:** WSL2 sometimes does not inherit Windows VPN routes. If step B.2 above times out, or `kubectl` later times out trying to reach a `10.x.x.x` IP, create `C:\Users\<you>\.wslconfig` with:
> ```ini
> [wsl2]
> networkingMode=mirrored
> ```
> Then in PowerShell:
> ```powershell
> wsl --shutdown
> wsl
> ```
> Re-test step B.2. Mirrored networking requires Windows 11 22H2 or later. On older Windows, you may need `wsl-vpnkit` or to fall back to Option A.

## One-time configuration (all OS)

### 1. Get your Okta AWS tile URL

1. Open https://deloittecms.digitalidentityservice.com/app/UserHome
2. Right-click the **"ZoraAISUTTaxHosted deloprix"** tile (the one with the AWS logo) → **Copy link address**
3. URL format: `https://deloittecms.digitalidentityservice.com/home/amazon_aws/<id>/272`

> If right-click is disabled: F12 (DevTools) → Network tab → click the tile → first request URL.

### 2. Configure saml2aws

```bash
saml2aws configure --profile zoraai-sut-dev
```

| Prompt | Answer |
|---|---|
| Provider | `Okta` |
| MFA | `Auto` |
| AWS Profile | press Enter (uses `zoraai-sut-dev`) |
| URL | *(paste from step 1)* |
| Username | `<your-email>@deloitte.co.il` |
| Password | leave empty |
| Session duration | press Enter for `3600` |

### 3. First login + wire kubectl

```bash
# Connect to Deloitte VPN first (gpvpn.deloitteinnovation.us)

saml2aws login --profile zoraai-sut-dev
# Enter Deloitte password + approve MFA push
# Select role: ZORAAISUTTAXHOSTEDSA-ADMIN-DEV

# Activate the profile (mac/Linux)
export AWS_PROFILE=zoraai-sut-dev
# Or on Windows PowerShell:
# $env:AWS_PROFILE = "zoraai-sut-dev"

aws sts get-caller-identity                                          # verify
aws eks update-kubeconfig --name zoraai-sut-eus --region us-east-1
kubectl get pods -n zora-ai-sut
```

For the QA cluster:
```bash
aws eks update-kubeconfig --name zoraai-qa-sut-eus --region us-east-1
```

Make the profile sticky:
```bash
# bash
echo 'export AWS_PROFILE=zoraai-sut-dev' >> ~/.bashrc
# zsh (macOS default)
echo 'export AWS_PROFILE=zoraai-sut-dev' >> ~/.zshrc
# PowerShell
'$env:AWS_PROFILE = "zoraai-sut-dev"' | Out-File -Append $PROFILE
```

## Daily flow

```bash
# 1. Connect to Deloitte VPN (gpvpn.deloitteinnovation.us)
# 2. Refresh creds (~hourly when token expires)
saml2aws login --profile zoraai-sut-dev

# 3. Use kubectl
kubectl get pods -n zora-ai-sut
kubectl logs -n zora-ai-sut <pod-name>
```

## Switching between clusters

```bash
kubectl config get-contexts
kubectl config use-context arn:aws:eks:us-east-1:618246140645:cluster/zoraai-sut-eus
kubectl config use-context arn:aws:eks:us-east-1:618246140645:cluster/zoraai-qa-sut-eus
```

## Alternative: deloitte-okta-cli

If you prefer not to use `saml2aws`, the internal `deloitte-okta-cli` tool also works. It is shorter to set up but pulls from an internal PyPI index, pins `urllib3==1.26.5`, and issues 1-hour sessions, so use a dedicated Python venv to avoid breaking other projects.

**One-time install:**

```bash
python -m venv ~/.venvs/okta && source ~/.venvs/okta/bin/activate   # PowerShell: .\.venvs\okta\Scripts\Activate.ps1
pip install urllib3==1.26.5
python -m pip install --upgrade deloitte-okta-cli --extra-index-url=https://pypi.deloittecloud.co.uk/beta
```

**Login (re-run every hour, while on VPN):**

```bash
# SUT clusters (dev + qa)
okta-cli -u deloittecms.digitalidentityservice.com ZoraAISUTTaxHostedSaaS-deloprix --enter-username

# Advise clusters
okta-cli -u deloittecms.digitalidentityservice.com ZoraAdviseXPerformIntegration-delomjrz --enter-username
```

**Verify and configure kubectl:**

```bash
aws sts get-caller-identity
aws eks list-clusters --region us-east-1
aws eks update-kubeconfig --name <cluster-name> --region us-east-1
kubectl get ns
```

## Troubleshooting

| Symptom | Fix |
|---|---|
| `kubectl` → `i/o timeout` to a `10.x` IP | Connect to Deloitte VPN (`gpvpn.deloitteinnovation.us`) |
| `kubectl` → `Unauthorized` / `forbidden` at cluster scope | Your access policy is namespace-scoped, always use `-n zora-ai-sut` |
| `aws sts get-caller-identity` → expired token | Re-run `saml2aws login --profile zoraai-sut-dev` |
| `saml2aws login` → "could not find role" | Wrong Okta URL, re-copy the AWS tile link |
| WSL can't reach `10.x` but Windows can | Use mirrored networking (see WSL note above) |
| Windows `winget` blocked | Use the manual download path under Windows Option A |
| `command not found: saml2aws` after install | Restart your shell so PATH refreshes |
| macOS: "saml2aws cannot be opened because the developer cannot be verified" | System Settings → Privacy & Security → click "Allow Anyway" for saml2aws |

## Fallback: AWS CloudShell (no setup, no VPN, limited)

For quick AWS API exploration without local setup:

1. AWS console → click the terminal icon in the top bar (`>_`)
2. Pre-authenticated; has `aws` and `kubectl` installed

**Limitation:** CloudShell runs in an AWS-managed VPC with no peering to ours, so it **cannot reach the cluster's private API endpoint**. Useful only for `aws` CLI queries (not `kubectl`).
